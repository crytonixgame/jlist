package com.blazehealth.tracker.utils;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
//import com.airbnb.lottie.LottieAnimationView;
//import com.blankj.molihuan.utilcode.util.ToastUtils;
import com.blazehealth.tracker.BuildConfig;
//import com.blazehealth.tracker.activity.CrashHandler;
import com.blazehealth.tracker.activity.MainActivity;
///import com.blazehealth.tracker.libhelper.FileHelper;
///import com.blazehealth.tracker.libhelper.Loader;
//import com.craiyon.loader.overlay.MenuFloatingView;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import com.blazehealth.tracker.R;

//import org.jdeferred.android.AndroidDeferredManager;

///import com.blazehealth.tracker.libhelper.ApkEnv;

import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class ActivityCompat extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        myTools m = new myTools(newBase);
        String savedLang = m.getSt("myLang", "mapLang", "en"); // Get saved language
        super.attachBaseContext(updateLocale(newBase, savedLang));
    }

    private Context updateLocale(Context context, String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);

        return context.createConfigurationContext(config);
    }
    private static ActivityCompat activityCompat;
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    public static int PERMISSION_REQUEST_STORAGE = 100;
    public static int REQUEST_MANAGE_UNKNOWN_APP_SOURCES = 200;
    public boolean isLogin = false;
    public FPrefs prefs;
    private BottomSheetDialog bottomSheetDialog;
    public static String gamename;
    public static String name;
    public static int version;
    public static String url;
    private static ExecutorService executorService = Executors.newSingleThreadExecutor();
   
    public static ActivityCompat getActivityCompat() {
        return activityCompat;
    }

    protected static void requestPermissions(MainActivity mainActivity, String[] strings, int requestPermissions) {
    }

    public FPrefs getPref() {
        return FPrefs.with(this);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        activityCompat = this;
        super.onCreate(savedInstanceState);
//        Thread.setDefaultUncaughtExceptionHandler(new CrashHandler(this));
        setNavBar(R.color.background);

        prefs = getPref();

        ManageFiles();
    }
    
    public void setNavBar(int color){
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(ContextCompat.getColor(this,color));
    }
    
    public void restartApp(String clazz) {
        Intent lauchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        lauchIntent.addFlags(335577088);
        lauchIntent.putExtra("restartApp", clazz);
        startActivity(lauchIntent);
        Runtime.getRuntime().exit(0);
    }
    
    /*public void toast(CharSequence msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(R.drawable.ic_tumn);
        //_toast.setGravity(Gravity.BOTTOM, Gravity.CENTER, Gravity.CENTER);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        //_toast.setBgResource(R.drawable.button_coming);
        _toast.show(msg);
        //Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }*/
    
    /*public static void toastImage(int id, String msg) {
        ToastUtils _toast = ToastUtils.make();
        _toast.setBgColor(android.R.color.white);
        _toast.setLeftIcon(id);
        _toast.setTextColor(android.R.color.black);
        _toast.setNotUseSystemToast();
        _toast.show(msg);
    }*/
    
    public void RestartAppp() {
        PackageManager pm = getPackageManager();
        Intent intent = pm.getLaunchIntentForPackage(getPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
        finish();
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(0);
    }

    public void ShowRestartApp() {
        showBottomSheetDialog(
                getResources().getDrawable(R.drawable.ic_check),
                "Download Success: Restart Loader",
                "The loader has been downloaded successfully. Please restart the loader now.",
                false,
                v -> {
                    MainActivity.get().doShowProgress(true);
                    RestartAppp();
                    dismissBottomSheetDialog();
                },
                null);
    }
    
    public void takeFilePermissions() {
        new MaterialAlertDialogBuilder(this)
            .setCancelable(false)
            .setTitle(R.string.file_access_title)
            .setMessage(R.string.file_access_message)
            .setPositiveButton(
                R.string.grant_permission,
                (d, w) -> {
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Intent intent = new Intent();
                    intent.setAction(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                  } else {
                    androidx.core.app.ActivityCompat.requestPermissions(
                        this,
                        new String[] {
                          Manifest.permission.READ_EXTERNAL_STORAGE,
                          Manifest.permission.MANAGE_EXTERNAL_STORAGE
                        },
                        1);
                  }
                })
            .setNegativeButton(
                R.string.exit,
                (d, w) -> {
                  finish();
                  System.exit(0);
                })
            .show();
    }
    
    public boolean isPermissionGaranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
          return Environment.isExternalStorageManager();
        } else {
          return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }
    
    public void InstllUnknownApp() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!getPackageManager().canRequestPackageInstalls()) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage("Please allow Install Unknown App Source");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_MANAGE_UNKNOWN_APP_SOURCES);
                    }
                });
                builder.setCancelable(false);
                builder.show();
            } else {
                if (!isPermissionGaranted()) {
                    takeFilePermissions();
                }
            }
        }
    }
    
    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage("Please allow permision floating");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                    }
                });
                builder.setCancelable(false);
                builder.show();
            } else {
                InstllUnknownApp();
            }
        }
    }
    
    public void ManageFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                androidx.core.app.ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST_STORAGE);
            } else {
                OverlayPermision();
            }
        }
    }
    
   /* protected AndroidDeferredManager defer() {
        return UiKit.defer();
    }*/
    
    private long backPressedTime = 0; 
    
    @Override
    public void onBackPressed() {
        if (isLogin) {
            long t = System.currentTimeMillis();
            if (t - backPressedTime > 2000) {    // 2 secs
                backPressedTime = t;
                //toast("Press back again to exit");
            } else {
                super.onBackPressed();
            }
        }
    }
    
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        } else {
            showSystemUI();
        }
    }
    
    private void hideSystemUI() {
      
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }



    public void launch(AlertDialog dialog, String pkg) {
        dialog.dismiss();
       // ApkEnv.getInstance().launchApk(pkg);
    }


    public void launchSplash(String pkg) {
        try {
            View view = getLayoutInflater().inflate(R.layout.launcher, null);
            CardView cv = view.findViewById(R.id.cv_lauch);
            TextView txt = view.findViewById(R.id.start_client);

            MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
            builder.setCancelable(false)
                    .setView(view)
                    .setBackground(this.getResources().getDrawable(R.drawable.background_trans));

            AlertDialog dialog = builder.create();
            dialog.show();

            launch(dialog, pkg);

        } catch (Exception err) {
            FLog.error(err.getCause().getMessage());
        }
    }




    public void showBottomSheetDialogUninstall(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener confirmListener) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_layout);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);

        MaterialButton confirm = bottomSheetDialog.findViewById(R.id.btn);
        confirm.setText(R.string.uninstall); // Button text changed to "Uninstall"
        if (confirmListener != null) {
            confirm.setOnClickListener(confirmListener);
        }

        MaterialButton cancel = bottomSheetDialog.findViewById(R.id.btn_cancle);
        cancel.setOnClickListener(v -> bottomSheetDialog.dismiss()); // Cancel button dismisses the dialog

        bottomSheetDialog.show();
    }


    public void showBottomSheetDialog(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_dialog_layout);
        
        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);
        
        MaterialButton download = bottomSheetDialog.findViewById(R.id.btn);
        download.setText(R.string.recording_on);
        if (listener != null) {
            download.setOnClickListener(listener);
        }
        
        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        cancle.setText(R.string.recording_off);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }
        
        bottomSheetDialog.show();
    }

    public void showBottomSheetDialog2(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener,View.OnClickListener updates, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_update);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);

        MaterialButton download = bottomSheetDialog.findViewById(R.id.btn);
        if (listener != null) {
            download.setOnClickListener(listener);
        }

        MaterialButton updatess = bottomSheetDialog.findViewById(R.id.updateee);
        if (updates != null) {
            updatess.setOnClickListener(updates);
        }


        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }

        bottomSheetDialog.show();
    }

    public void showBottomSheetDialog3(Drawable icon, String title, String msg, boolean cancelable, View.OnClickListener listener,View.OnClickListener updates, View.OnClickListener listenerCancle) {
        if (BuildConfig.VERSION_CODE == 200) {
            return;
        }
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setCancelable(cancelable);
        bottomSheetDialog.setContentView(R.layout.bottom_logout);

        ImageView img = bottomSheetDialog.findViewById(R.id.icon);
        if (icon != null) {
            img.setImageDrawable(icon);
        }
        TextView title_tv = bottomSheetDialog.findViewById(R.id.title);
        title_tv.setText(title);
        TextView msg_tv = bottomSheetDialog.findViewById(R.id.msg);
        msg_tv.setText(msg);


        MaterialButton updatess = bottomSheetDialog.findViewById(R.id.updateee);
        if (updates != null) {
            updatess.setOnClickListener(updates);
        }


        MaterialButton cancle = bottomSheetDialog.findViewById(R.id.btn_cancle);
        if (listenerCancle != null) {
            cancle.setOnClickListener(listenerCancle);
        } else {
            cancle.setVisibility(View.GONE);
        }

        bottomSheetDialog.show();
    }

    public void dismissBottomSheetDialog() {
        try {
        	if (bottomSheetDialog.isShowing()) {
                bottomSheetDialog.dismiss();
                bottomSheetDialog = null;
            }
        } catch(Exception err) {
        	FLog.error(err.getMessage());
        }
    }
    
}
