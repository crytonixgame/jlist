.class public Lcom/vbox/app/dispatcher/AppServiceDispatcher;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final TAG:Ljava/lang/String; = "AppServiceDispatcher"

.field private static final sServiceDispatcher:Lcom/vbox/app/dispatcher/AppServiceDispatcher;


# instance fields
.field private final mHandler:Landroid/os/Handler;

.field private final mService:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/content/Intent$FilterComparison;",
            "Lcom/vbox/entity/ServiceRecord;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;

    invoke-direct {v0}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;-><init>()V

    sput-object v0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->sServiceDispatcher:Lcom/vbox/app/dispatcher/AppServiceDispatcher;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getHandler()Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mHandler:Landroid/os/Handler;

    return-void
.end method

.method private findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;
    .registers 4

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    new-instance v1, Landroid/content/Intent$FilterComparison;

    invoke-direct {v1, p1}, Landroid/content/Intent$FilterComparison;-><init>(Landroid/content/Intent;)V

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/ServiceRecord;

    return-object p1
.end method

.method public static get()Lcom/vbox/app/dispatcher/AppServiceDispatcher;
    .registers 1

    sget-object v0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->sServiceDispatcher:Lcom/vbox/app/dispatcher/AppServiceDispatcher;

    return-object v0
.end method

.method private getOrCreateService(Lcom/vbox/proxy/record/ProxyServiceRecord;)Landroid/app/Service;
    .registers 7

    const/4 v0, 0x0

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    iget-object v1, p1, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    iget-object v2, p1, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceInfo:Landroid/content/pm/ServiceInfo;

    iget-object p1, p1, Lcom/vbox/proxy/record/ProxyServiceRecord;->mToken:Landroid/os/IBinder;

    if-eqz v1, :cond_4

    if-nez v2, :cond_1

    goto :goto_0

    :cond_1
    invoke-direct {p0, v1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v4

    if-eqz v4, :cond_2

    invoke-virtual {v3}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object p1

    return-object p1

    :cond_2
    :try_start_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v3

    invoke-virtual {v3, v2, p1}, Lcom/vbox/app/BActivityThread;->createService(Landroid/content/pm/ServiceInfo;Landroid/os/IBinder;)Landroid/app/Service;

    move-result-object p1

    if-nez p1, :cond_3

    return-object v0

    :cond_3
    new-instance v2, Lcom/vbox/entity/ServiceRecord;

    invoke-direct {v2}, Lcom/vbox/entity/ServiceRecord;-><init>()V

    invoke-virtual {v2, p1}, Lcom/vbox/entity/ServiceRecord;->setService(Landroid/app/Service;)V

    iget-object v3, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    new-instance v4, Landroid/content/Intent$FilterComparison;

    invoke-direct {v4, v1}, Landroid/content/Intent$FilterComparison;-><init>(Landroid/content/Intent;)V

    invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    const-string v1, "AppServiceDispatcher"

    const-string v2, "createService crash"

    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_4
    :goto_0
    return-object v0
.end method

.method static synthetic lambda$stopService$0(Landroid/app/Service;)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Landroid/app/Service;->onDestroy()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    const-string v0, "AppServiceDispatcher"

    const-string v1, "stopService crash"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 6

    invoke-static {p1}, Lcom/vbox/proxy/record/ProxyServiceRecord;->create(Landroid/content/Intent;)Lcom/vbox/proxy/record/ProxyServiceRecord;

    move-result-object p1

    iget-object v0, p1, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    iget-object v1, p1, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceInfo:Landroid/content/pm/ServiceInfo;

    const/4 v2, 0x0

    if-eqz v0, :cond_5

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-direct {p0, p1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->getOrCreateService(Lcom/vbox/proxy/record/ProxyServiceRecord;)Landroid/app/Service;

    move-result-object p1

    if-nez p1, :cond_1

    return-object v2

    :cond_1
    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    invoke-direct {p0, v0}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v1

    if-nez v1, :cond_2

    return-object v2

    :cond_2
    :try_start_0
    invoke-virtual {v1, v0}, Lcom/vbox/entity/ServiceRecord;->incrementAndGetBindCount(Landroid/content/Intent;)I

    invoke-virtual {v1, v0}, Lcom/vbox/entity/ServiceRecord;->hasBinder(Landroid/content/Intent;)Z

    move-result v3

    if-eqz v3, :cond_4

    invoke-virtual {v1}, Lcom/vbox/entity/ServiceRecord;->isRebind()Z

    move-result v3

    if-eqz v3, :cond_3

    invoke-virtual {p1, v0}, Landroid/app/Service;->onRebind(Landroid/content/Intent;)V

    const/4 p1, 0x0

    invoke-virtual {v1, p1}, Lcom/vbox/entity/ServiceRecord;->setRebind(Z)V

    :cond_3
    invoke-virtual {v1, v0}, Lcom/vbox/entity/ServiceRecord;->getBinder(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    return-object p1

    :cond_4
    invoke-virtual {p1, v0}, Landroid/app/Service;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    invoke-virtual {v1, v0, p1}, Lcom/vbox/entity/ServiceRecord;->addBinder(Landroid/content/Intent;Landroid/os/IBinder;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    const-string v0, "AppServiceDispatcher"

    const-string v1, "onBind crash"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_5
    :goto_0
    return-object v2
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 6

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/entity/ServiceRecord;

    :try_start_0
    invoke-virtual {v1}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/app/Service;->onConfigurationChanged(Landroid/content/res/Configuration;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    const-string v2, "AppServiceDispatcher"

    const-string v3, "onConfigurationChanged crash"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_1
    return-void
.end method

.method public onDestroy()V
    .registers 5

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/entity/ServiceRecord;

    :try_start_0
    invoke-virtual {v1}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/app/Service;->onDestroy()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    const-string v2, "AppServiceDispatcher"

    const-string v3, "onDestroy crash"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    return-void
.end method

.method public onLowMemory()V
    .registers 5

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/entity/ServiceRecord;

    :try_start_0
    invoke-virtual {v1}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroid/app/Service;->onLowMemory()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    const-string v2, "AppServiceDispatcher"

    const-string v3, "onLowMemory crash"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_1
    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 8

    invoke-static {p1}, Lcom/vbox/proxy/record/ProxyServiceRecord;->create(Landroid/content/Intent;)Lcom/vbox/proxy/record/ProxyServiceRecord;

    move-result-object p3

    iget-object v0, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    const/4 v1, 0x2

    if-eqz v0, :cond_3

    iget-object v0, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceInfo:Landroid/content/pm/ServiceInfo;

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    invoke-direct {p0, p3}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->getOrCreateService(Lcom/vbox/proxy/record/ProxyServiceRecord;)Landroid/app/Service;

    move-result-object v0

    if-nez v0, :cond_1

    return v1

    :cond_1
    iget-object v2, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    invoke-direct {p0, v2}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v2

    if-nez v2, :cond_2

    return v1

    :cond_2
    :try_start_0
    iget v3, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mStartId:I

    invoke-virtual {v2, v3}, Lcom/vbox/entity/ServiceRecord;->setStartId(I)V

    iget-object v2, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    iget v3, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mStartId:I

    invoke-virtual {v0, v2, p2, v3}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    move-result p2

    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v0

    iget p3, p3, Lcom/vbox/proxy/record/ProxyServiceRecord;->mUserId:I

    invoke-virtual {v0, p1, p3}, Lcom/vbox/fake/frameworks/BActivityManager;->onStartCommand(Landroid/content/Intent;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return p2

    :catchall_0
    move-exception p1

    const-string p2, "AppServiceDispatcher"

    const-string p3, "onStartCommand crash"

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    :goto_0
    return v1
.end method

.method public onTrimMemory(I)V
    .registers 6

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/entity/ServiceRecord;

    :try_start_0
    invoke-virtual {v1}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1, p1}, Landroid/app/Service;->onTrimMemory(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    const-string v2, "AppServiceDispatcher"

    const-string v3, "onTrimMemory crash"

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_0

    :cond_1
    return-void
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .registers 11

    const-string v0, "onUnbind crash"

    const-string v1, "AppServiceDispatcher"

    invoke-static {p1}, Lcom/vbox/proxy/record/ProxyServiceRecord;->create(Landroid/content/Intent;)Lcom/vbox/proxy/record/ProxyServiceRecord;

    move-result-object v2

    iget-object v3, v2, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceIntent:Landroid/content/Intent;

    const/4 v4, 0x0

    if-eqz v3, :cond_7

    iget-object v5, v2, Lcom/vbox/proxy/record/ProxyServiceRecord;->mServiceInfo:Landroid/content/pm/ServiceInfo;

    if-nez v5, :cond_0

    goto :goto_3

    :cond_0
    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v5

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v6

    invoke-virtual {v5, p1, v6}, Lcom/vbox/fake/frameworks/BActivityManager;->onServiceUnbind(Landroid/content/Intent;I)Lcom/vbox/entity/UnbindRecord;

    move-result-object v5

    if-nez v5, :cond_1

    return v4

    :cond_1
    invoke-direct {p0, v2}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->getOrCreateService(Lcom/vbox/proxy/record/ProxyServiceRecord;)Landroid/app/Service;

    move-result-object v2

    if-nez v2, :cond_2

    return v4

    :cond_2
    invoke-virtual {v2}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    invoke-direct {p0, v3}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v6

    if-nez v6, :cond_3

    return v4

    :cond_3
    invoke-virtual {v5}, Lcom/vbox/entity/UnbindRecord;->getStartId()I

    move-result v5

    const/4 v7, 0x1

    if-nez v5, :cond_4

    move v5, v7

    goto :goto_0

    :cond_4
    move v5, v4

    :goto_0
    if-nez v5, :cond_5

    invoke-virtual {v6, v3}, Lcom/vbox/entity/ServiceRecord;->decreaseConnectionCount(Landroid/content/Intent;)Z

    move-result v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz v8, :cond_7

    :cond_5
    :try_start_1
    invoke-virtual {v2, v3}, Landroid/app/Service;->onUnbind(Landroid/content/Intent;)Z

    move-result v8
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v8

    :try_start_2
    invoke-static {v1, v0, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    move v8, v4

    :goto_1
    if-eqz v5, :cond_6

    :try_start_3
    invoke-virtual {v2}, Landroid/app/Service;->onDestroy()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v2

    :try_start_4
    const-string v5, "onDestroy during unbind crash"

    invoke-static {v1, v5, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_2
    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v2

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v5

    invoke-virtual {v2, p1, v5}, Lcom/vbox/fake/frameworks/BActivityManager;->onServiceDestroy(Landroid/content/Intent;I)V

    iget-object p1, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    new-instance v2, Landroid/content/Intent$FilterComparison;

    invoke-direct {v2, v3}, Landroid/content/Intent$FilterComparison;-><init>(Landroid/content/Intent;)V

    invoke-interface {p1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    invoke-virtual {v6, v7}, Lcom/vbox/entity/ServiceRecord;->setRebind(Z)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    return v8

    :catchall_2
    move-exception p1

    invoke-static {v1, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_7
    :goto_3
    return v4
.end method

.method public peekService(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3

    invoke-direct {p0, p1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    invoke-virtual {v0, p1}, Lcom/vbox/entity/ServiceRecord;->getBinder(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    return-object p1
.end method

.method public stopService(Landroid/content/Intent;)V
    .registers 5

    if-nez p1, :cond_0

    return-void

    :cond_0
    invoke-direct {p0, p1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->findRecord(Landroid/content/Intent;)Lcom/vbox/entity/ServiceRecord;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    :cond_1
    invoke-virtual {v0}, Lcom/vbox/entity/ServiceRecord;->getService()Landroid/app/Service;

    move-result-object v1

    if-nez v1, :cond_2

    return-void

    :cond_2
    invoke-virtual {v0}, Lcom/vbox/entity/ServiceRecord;->getStartId()I

    move-result v0

    if-lez v0, :cond_3

    const/4 v0, 0x1

    goto :goto_0

    :cond_3
    const/4 v0, 0x0

    :goto_0
    if-eqz v0, :cond_4

    :try_start_0
    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mHandler:Landroid/os/Handler;

    new-instance v2, Lcom/vbox/app/dispatcher/AppServiceDispatcher$$ExternalSyntheticLambda0;

    invoke-direct {v2, v1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher$$ExternalSyntheticLambda0;-><init>(Landroid/app/Service;)V

    invoke-virtual {v0, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v1

    invoke-virtual {v0, p1, v1}, Lcom/vbox/fake/frameworks/BActivityManager;->onServiceDestroy(Landroid/content/Intent;I)V

    iget-object v0, p0, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->mService:Ljava/util/Map;

    new-instance v1, Landroid/content/Intent$FilterComparison;

    invoke-direct {v1, p1}, Landroid/content/Intent$FilterComparison;-><init>(Landroid/content/Intent;)V

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p1

    const-string v0, "AppServiceDispatcher"

    const-string v1, "stopService crash outer"

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_4
    :goto_1
    return-void
.end method
