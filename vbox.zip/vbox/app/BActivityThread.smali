.class public Lcom/vbox/app/BActivityThread;
.super Lcom/vbox/core/IBActivityThread$Stub;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/app/BActivityThread$AppBindData;
    }
.end annotation


# static fields
.field static final synthetic $assertionsDisabled:Z = false

.field public static final TAG:Ljava/lang/String; = "BActivityThread"

.field private static final mConfigLock:Ljava/lang/Object;

.field private static volatile sBActivityThread:Lcom/vbox/app/BActivityThread;


# instance fields
.field private mAppConfig:Lcom/vbox/entity/AppConfig;

.field private mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

.field private final mH:Landroid/os/Handler;

.field private mInitialApplication:Landroid/app/Application;

.field private final mProviders:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/content/pm/ProviderInfo;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lcom/vbox/app/BActivityThread;->mConfigLock:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lcom/vbox/core/IBActivityThread$Stub;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vbox/app/BActivityThread;->mProviders:Ljava/util/List;

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getHandler()Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, Lcom/vbox/app/BActivityThread;->mH:Landroid/os/Handler;

    return-void
.end method

.method public static synthetic access$000()Ljava/lang/Object;
    .registers 1

    sget-object v0, Lcom/vbox/app/BActivityThread;->mConfigLock:Ljava/lang/Object;

    return-object v0
.end method

.method public static synthetic access$102(Lcom/vbox/app/BActivityThread;Lcom/vbox/entity/AppConfig;)Lcom/vbox/entity/AppConfig;
    .registers 2

    iput-object p1, p0, Lcom/vbox/app/BActivityThread;->mAppConfig:Lcom/vbox/entity/AppConfig;

    return-object p1
.end method

.method public static createPackageContext(Landroid/content/pm/ApplicationInfo;)Landroid/content/Context;
    .registers 3

    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v1, 0x3

    invoke-virtual {v0, p0, v1}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p0

    :catch_0
    move-exception p0

    const-string v0, "BActivityThread"

    const-string v1, "error"

    invoke-static {v0, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 p0, 0x0

    return-object p0
.end method

.method public static currentActivityThread()Lcom/vbox/app/BActivityThread;
    .registers 2

    sget-object v0, Lcom/vbox/app/BActivityThread;->sBActivityThread:Lcom/vbox/app/BActivityThread;

    if-nez v0, :cond_1

    const-class v0, Lcom/vbox/app/BActivityThread;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/vbox/app/BActivityThread;->sBActivityThread:Lcom/vbox/app/BActivityThread;

    if-nez v1, :cond_0

    new-instance v1, Lcom/vbox/app/BActivityThread;

    invoke-direct {v1}, Lcom/vbox/app/BActivityThread;-><init>()V

    sput-object v1, Lcom/vbox/app/BActivityThread;->sBActivityThread:Lcom/vbox/app/BActivityThread;

    :cond_0
    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1

    :cond_1
    :goto_0
    sget-object v0, Lcom/vbox/app/BActivityThread;->sBActivityThread:Lcom/vbox/app/BActivityThread;

    return-object v0
.end method

.method public static getActivityByToken(Landroid/os/IBinder;)Landroid/app/Activity;
    .registers 2

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityThreadContext;->mActivities()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {p0}, Lblack/android/app/BRActivityThreadActivityClientRecord;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadActivityClientRecordContext;

    move-result-object p0

    invoke-interface {p0}, Lblack/android/app/ActivityThreadActivityClientRecordContext;->activity()Landroid/app/Activity;

    move-result-object p0

    return-object p0
.end method

.method public static getAppConfig()Lcom/vbox/entity/AppConfig;
    .registers 2

    sget-object v0, Lcom/vbox/app/BActivityThread;->mConfigLock:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v1

    iget-object v1, v1, Lcom/vbox/app/BActivityThread;->mAppConfig:Lcom/vbox/entity/AppConfig;

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1
.end method

.method public static getAppPackageName()Ljava/lang/String;
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/entity/AppConfig;->packageName:Ljava/lang/String;

    return-object v0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    if-eqz v0, :cond_1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public static getAppPid()I
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, -0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget v0, v0, Lcom/vbox/entity/AppConfig;->bpid:I

    :goto_0
    return v0
.end method

.method public static getAppProcessName()Ljava/lang/String;
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    return-object v0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    if-eqz v0, :cond_1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    iget-object v0, v0, Lcom/vbox/app/BActivityThread$AppBindData;->processName:Ljava/lang/String;

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method public static getApplication()Landroid/app/Application;
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    return-object v0
.end method

.method public static getBAppId()I
    .registers 1

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostUid()I

    move-result v0

    invoke-static {v0}, Lcom/vbox/core/system/user/BUserHandle;->getAppId(I)I

    move-result v0

    return v0
.end method

.method public static getBUid()I
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-nez v0, :cond_0

    const/16 v0, 0x2710

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget v0, v0, Lcom/vbox/entity/AppConfig;->buid:I

    :goto_0
    return v0
.end method

.method public static getCallingBUid()I
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostUid()I

    move-result v0

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget v0, v0, Lcom/vbox/entity/AppConfig;->callingBUid:I

    :goto_0
    return v0
.end method

.method public static getProviders()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/content/pm/ProviderInfo;",
            ">;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/app/BActivityThread;->currentActivityThread()Lcom/vbox/app/BActivityThread;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/app/BActivityThread;->mProviders:Ljava/util/List;

    return-object v0
.end method

.method public static getUid()I
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, -0x1

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget v0, v0, Lcom/vbox/entity/AppConfig;->uid:I

    :goto_0
    return v0
.end method

.method public static getUserId()I
    .registers 1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget v0, v0, Lcom/vbox/entity/AppConfig;->userId:I

    :goto_0
    return v0
.end method

.method public static installProvider(Ljava/lang/Object;Landroid/content/Context;Landroid/content/pm/ProviderInfo;Ljava/lang/Object;)V
    .registers 12

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-string v1, "installProvider"

    invoke-static {v0, v1}, Lcom/vbox/utils/Reflector;->findMethodByFirstName(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Method;

    move-result-object v0

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    move-object v2, p1

    move-object v3, p3

    move-object v4, p2

    move-object v6, v7

    filled-new-array/range {v2 .. v7}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method private installProviders(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Landroid/content/pm/ProviderInfo;",
            ">;)V"
        }
    .end annotation

    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v0

    :try_start_0
    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_0
    :goto_0
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/pm/ProviderInfo;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->processName:Ljava/lang/String;

    invoke-virtual {p2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->processName:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    iget-boolean v3, v2, Landroid/content/pm/ProviderInfo;->multiprocess:Z

    if-eqz v3, :cond_0

    :cond_1
    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v3

    const/4 v4, 0x0

    invoke-static {v3, p1, v2, v4}, Lcom/vbox/app/BActivityThread;->installProvider(Ljava/lang/Object;Landroid/content/Context;Landroid/content/pm/ProviderInfo;Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v2

    goto :goto_0

    :cond_2
    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    invoke-static {}, Lcom/vbox/fake/delegate/ContentProviderDelegate;->init()V

    return-void

    :catchall_1
    move-exception p1

    invoke-static {v0, v1}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    invoke-static {}, Lcom/vbox/fake/delegate/ContentProviderDelegate;->init()V

    throw p1
.end method

.method public static isThreadInit()Z
    .registers 1

    sget-object v0, Lcom/vbox/app/BActivityThread;->sBActivityThread:Lcom/vbox/app/BActivityThread;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method static synthetic lambda$finishActivity$1(Landroid/os/IBinder;)V
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityThreadContext;->mActivities()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Lcom/vbox/app/BActivityThread;->getActivityByToken(Landroid/os/IBinder;)Landroid/app/Activity;

    move-result-object v0

    :goto_0
    invoke-virtual {v0}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/app/Activity;->getParent()Landroid/app/Activity;

    move-result-object v0

    goto :goto_0

    :cond_1
    invoke-static {v0}, Lblack/android/app/BRActivity;->get(Ljava/lang/Object;)Lblack/android/app/ActivityContext;

    move-result-object v1

    invoke-interface {v1}, Lblack/android/app/ActivityContext;->mResultCode()Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-static {v0}, Lblack/android/app/BRActivity;->get(Ljava/lang/Object;)Lblack/android/app/ActivityContext;

    move-result-object v2

    invoke-interface {v2}, Lblack/android/app/ActivityContext;->mResultData()Landroid/content/Intent;

    move-result-object v2

    invoke-static {p0, v1, v2}, Lcom/vbox/utils/compat/ActivityManagerCompat;->finishActivity(Landroid/os/IBinder;ILandroid/content/Intent;)Z

    invoke-static {v0}, Lblack/android/app/BRActivity;->get(Ljava/lang/Object;)Lblack/android/app/ActivityContext;

    move-result-object p0

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-interface {p0, v0}, Lblack/android/app/ActivityContext;->_set_mFinished(Ljava/lang/Object;)V

    return-void
.end method

.method static synthetic lambda$handleNewIntent$2(Landroid/content/Intent;Landroid/os/IBinder;)V
    .registers 6

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isLollipop_MR1()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lblack/com/android/internal/content/BRReferrerIntent;->get()Lblack/com/android/internal/content/ReferrerIntentStatic;

    move-result-object v0

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, p0, v1}, Lblack/com/android/internal/content/ReferrerIntentStatic;->_new(Landroid/content/Intent;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v1

    const/4 v2, 0x0

    invoke-interface {v1, v2, v2}, Lblack/android/app/ActivityThreadContext;->_check_performNewIntents(Landroid/os/IBinder;Ljava/util/List;)Ljava/lang/reflect/Method;

    move-result-object v1

    if-eqz v1, :cond_1

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v0

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {v0, p1, p0}, Lblack/android/app/ActivityThreadContext;->performNewIntents(Landroid/os/IBinder;Ljava/util/List;)Ljava/lang/Void;

    goto :goto_0

    :cond_1
    invoke-static {v0}, Lblack/android/app/BRActivityThreadNMR1;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadNMR1Context;

    move-result-object v1

    const/4 v3, 0x0

    invoke-interface {v1, v2, v2, v3}, Lblack/android/app/ActivityThreadNMR1Context;->_check_performNewIntents(Landroid/os/IBinder;Ljava/util/List;Z)Ljava/lang/reflect/Method;

    move-result-object v1

    if-eqz v1, :cond_2

    invoke-static {v0}, Lblack/android/app/BRActivityThreadNMR1;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadNMR1Context;

    move-result-object v0

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v1, 0x1

    invoke-interface {v0, p1, p0, v1}, Lblack/android/app/ActivityThreadNMR1Context;->performNewIntents(Landroid/os/IBinder;Ljava/util/List;Z)Ljava/lang/Void;

    goto :goto_0

    :cond_2
    invoke-static {v0}, Lblack/android/app/BRActivityThreadQ;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadQContext;

    move-result-object v1

    invoke-interface {v1, v2, v2}, Lblack/android/app/ActivityThreadQContext;->_check_handleNewIntent(Landroid/os/IBinder;Ljava/util/List;)Ljava/lang/reflect/Method;

    move-result-object v1

    if-eqz v1, :cond_3

    invoke-static {v0}, Lblack/android/app/BRActivityThreadQ;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadQContext;

    move-result-object v0

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    invoke-interface {v0, p1, p0}, Lblack/android/app/ActivityThreadQContext;->handleNewIntent(Landroid/os/IBinder;Ljava/util/List;)Ljava/lang/Void;

    :cond_3
    :goto_0
    return-void
.end method

.method private onAfterApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;)V
    .registers 7

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getAppLifecycleCallbacks()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/app/configuration/AppLifecycleCallback;

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v2

    invoke-virtual {v1, p1, p2, p3, v2}, Lcom/vbox/app/configuration/AppLifecycleCallback;->afterApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;I)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private onBeforeApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;)V
    .registers 7

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getAppLifecycleCallbacks()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/app/configuration/AppLifecycleCallback;

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v2

    invoke-virtual {v1, p1, p2, p3, v2}, Lcom/vbox/app/configuration/AppLifecycleCallback;->beforeApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;I)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private onBeforeCreateApplication(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V
    .registers 7

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getAppLifecycleCallbacks()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/app/configuration/AppLifecycleCallback;

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v2

    invoke-virtual {v1, p1, p2, p3, v2}, Lcom/vbox/app/configuration/AppLifecycleCallback;->beforeCreateApplication(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;I)V

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;
    .registers 6

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v0

    iget-object v0, v0, Lcom/vbox/entity/AppConfig;->packageName:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v1

    iget-object v1, v1, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    invoke-virtual {p0, v0, v1}, Lcom/vbox/app/BActivityThread;->bindApplication(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    iget-object p1, p1, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const-string v0, ";"

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    array-length v0, p1

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_2

    aget-object v2, p1, v1

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    invoke-virtual {v3, v2}, Landroid/content/ContentResolver;->acquireContentProviderClient(Ljava/lang/String;)Landroid/content/ContentProviderClient;

    move-result-object v2

    invoke-static {v2}, Lblack/android/content/BRContentProviderClient;->get(Ljava/lang/Object;)Lblack/android/content/ContentProviderClientContext;

    move-result-object v2

    invoke-interface {v2}, Lblack/android/content/ContentProviderClientContext;->mContentProvider()Landroid/os/IInterface;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-interface {v2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    return-object p1

    :cond_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_2
    const/4 p1, 0x0

    return-object p1
.end method

.method public bindApplication()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppProcessName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v0, v1}, Lcom/vbox/app/BActivityThread;->bindApplication(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public bindApplication(Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .line 2
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    if-eq v0, v1, :cond_0

    new-instance v0, Landroid/os/ConditionVariable;

    invoke-direct {v0}, Landroid/os/ConditionVariable;-><init>()V

    iget-object v1, p0, Lcom/vbox/app/BActivityThread;->mH:Landroid/os/Handler;

    new-instance v2, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0, p1, p2, v0}, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda2;-><init>(Lcom/vbox/app/BActivityThread;Ljava/lang/String;Ljava/lang/String;Landroid/os/ConditionVariable;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    invoke-virtual {v0}, Landroid/os/ConditionVariable;->block()V

    goto :goto_0

    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/vbox/app/BActivityThread;->handleBindApplication(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    return-void
.end method

.method public createJobService(Landroid/content/pm/ServiceInfo;)Landroid/app/job/JobService;
    .registers 13

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    iget-object v1, p1, Landroid/content/pm/ServiceInfo;->processName:Ljava/lang/String;

    invoke-virtual {p0, v0, v1}, Lcom/vbox/app/BActivityThread;->bindApplication(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    iget-object v0, v0, Lcom/vbox/app/BActivityThread$AppBindData;->info:Ljava/lang/Object;

    invoke-static {v0}, Lblack/android/app/BRLoadedApk;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/LoadedApkContext;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    iget-object v1, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/job/JobService;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    const/4 v3, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lblack/android/app/BRContextImpl;->get(Ljava/lang/Object;)Lblack/android/app/ContextImplContext;

    move-result-object v2

    invoke-interface {v2, v0}, Lblack/android/app/ContextImplContext;->setOuterContext(Landroid/content/Context;)Ljava/lang/Void;

    invoke-static {v0}, Lblack/android/app/BRService;->get(Ljava/lang/Object;)Lblack/android/app/ServiceContext;

    move-result-object v4

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v6

    iget-object v7, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->getActivityThread()Landroid/os/IBinder;

    move-result-object v8

    iget-object v9, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-static {}, Lblack/android/app/BRActivityManagerNative;->get()Lblack/android/app/ActivityManagerNativeStatic;

    move-result-object v2

    invoke-interface {v2}, Lblack/android/app/ActivityManagerNativeStatic;->getDefault()Landroid/os/IInterface;

    move-result-object v10

    move-object v5, v1

    invoke-interface/range {v4 .. v10}, Lblack/android/app/ServiceContext;->attach(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;Landroid/os/IBinder;Landroid/app/Application;Ljava/lang/Object;)Ljava/lang/Void;

    invoke-static {v1}, Lcom/vbox/utils/compat/ContextCompat;->fix(Landroid/content/Context;)V

    invoke-virtual {v0}, Landroid/app/job/JobService;->onCreate()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/job/JobService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    const-string v1, "BActivityThread"

    const-string v2, "error"

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v1, Ljava/lang/RuntimeException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unable to create JobService "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v1
.end method

.method public createService(Landroid/content/pm/ServiceInfo;Landroid/os/IBinder;)Landroid/app/Service;
    .registers 14

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    iget-object v1, p1, Landroid/content/pm/ServiceInfo;->processName:Ljava/lang/String;

    invoke-virtual {p0, v0, v1}, Lcom/vbox/app/BActivityThread;->bindApplication(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :try_start_0
    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    iget-object v0, v0, Lcom/vbox/app/BActivityThread$AppBindData;->info:Ljava/lang/Object;

    invoke-static {v0}, Lblack/android/app/BRLoadedApk;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/LoadedApkContext;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    iget-object v1, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/Service;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p1, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    const/4 v3, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lblack/android/app/BRContextImpl;->get(Ljava/lang/Object;)Lblack/android/app/ContextImplContext;

    move-result-object v2

    invoke-interface {v2, v0}, Lblack/android/app/ContextImplContext;->setOuterContext(Landroid/content/Context;)Ljava/lang/Void;

    invoke-static {v0}, Lblack/android/app/BRService;->get(Ljava/lang/Object;)Lblack/android/app/ServiceContext;

    move-result-object v4

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v6

    iget-object v7, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    iget-object v9, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-static {}, Lblack/android/app/BRActivityManagerNative;->get()Lblack/android/app/ActivityManagerNativeStatic;

    move-result-object v2

    invoke-interface {v2}, Lblack/android/app/ActivityManagerNativeStatic;->getDefault()Landroid/os/IInterface;

    move-result-object v10

    move-object v5, v1

    move-object v8, p2

    invoke-interface/range {v4 .. v10}, Lblack/android/app/ServiceContext;->attach(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/String;Landroid/os/IBinder;Landroid/app/Application;Ljava/lang/Object;)Ljava/lang/Void;

    invoke-static {v1}, Lcom/vbox/utils/compat/ContextCompat;->fix(Landroid/content/Context;)V

    invoke-virtual {v0}, Landroid/app/Service;->onCreate()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception p2

    const-string v0, "BActivityThread"

    const-string v1, "error"

    invoke-static {v0, v1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to create service "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public finishActivity(Landroid/os/IBinder;)V
    .registers 4

    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mH:Landroid/os/Handler;

    new-instance v1, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda1;

    invoke-direct {v1, p1}, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda1;-><init>(Landroid/os/IBinder;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public getActivityThread()Landroid/os/IBinder;
    .registers 2

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityThreadContext;->getApplicationThread()Landroid/os/IBinder;

    move-result-object v0

    return-object v0
.end method

.method public getPackageInfo()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    iget-object v0, v0, Lcom/vbox/app/BActivityThread$AppBindData;->info:Ljava/lang/Object;

    return-object v0
.end method

.method public declared-synchronized handleBindApplication(Ljava/lang/String;Ljava/lang/String;)V
    .registers 11

    monitor-enter p0

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz v0, :cond_0

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    invoke-static {}, Lcom/vbox/core/CrashHandler;->create()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    :goto_0
    :try_start_2
    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v1

    const/16 v2, 0x8

    invoke-virtual {v0, p1, v2, v1}, Lcom/vbox/fake/frameworks/BPackageManager;->getPackageInfo(Ljava/lang/String;II)Landroid/content/pm/PackageInfo;

    move-result-object v0

    iget-object v1, v0, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v2, v0, Landroid/content/pm/PackageInfo;->providers:[Landroid/content/pm/ProviderInfo;

    const/4 v3, 0x0

    if-nez v2, :cond_1

    new-array v2, v3, [Landroid/content/pm/ProviderInfo;

    iput-object v2, v0, Landroid/content/pm/PackageInfo;->providers:[Landroid/content/pm/ProviderInfo;

    :cond_1
    iget-object v2, p0, Lcom/vbox/app/BActivityThread;->mProviders:Ljava/util/List;

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->providers:[Landroid/content/pm/ProviderInfo;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityThreadContext;->mBoundApplication()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v1}, Lcom/vbox/app/BActivityThread;->createPackageContext(Landroid/content/pm/ApplicationInfo;)Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lblack/android/app/BRContextImpl;->get(Ljava/lang/Object;)Lblack/android/app/ContextImplContext;

    move-result-object v4

    invoke-interface {v4}, Lblack/android/app/ContextImplContext;->mPackageInfo()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Lblack/android/app/BRLoadedApk;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkContext;

    move-result-object v5

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v5, v6}, Lblack/android/app/LoadedApkContext;->_set_mSecurityViolation(Ljava/lang/Object;)V

    invoke-static {v4}, Lblack/android/app/BRLoadedApk;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkContext;

    move-result-object v5

    invoke-interface {v5, v1}, Lblack/android/app/LoadedApkContext;->_set_mApplicationInfo(Ljava/lang/Object;)V

    iget v5, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/16 v6, 0x9

    if-ge v5, v6, :cond_2

    new-instance v6, Landroid/os/StrictMode$ThreadPolicy$Builder;

    invoke-static {}, Landroid/os/StrictMode;->getThreadPolicy()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v7

    invoke-direct {v6, v7}, Landroid/os/StrictMode$ThreadPolicy$Builder;-><init>(Landroid/os/StrictMode$ThreadPolicy;)V

    invoke-virtual {v6}, Landroid/os/StrictMode$ThreadPolicy$Builder;->permitNetwork()Landroid/os/StrictMode$ThreadPolicy$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroid/os/StrictMode$ThreadPolicy$Builder;->build()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v6

    invoke-static {v6}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    :cond_2
    const/16 v6, 0x18

    if-ge v5, v6, :cond_3

    invoke-static {}, Lcom/vbox/utils/compat/StrictModeCompat;->disableDeathOnFileUriExposure()Z

    :cond_3
    invoke-static {p2, v1}, Lcom/vbox/core/env/VirtualRuntime;->setupRuntime(Ljava/lang/String;Landroid/content/pm/ApplicationInfo;)V

    invoke-static {}, Lblack/dalvik/system/BRVMRuntime;->get()Lblack/dalvik/system/VMRuntimeStatic;

    move-result-object v5

    invoke-interface {v5}, Lblack/dalvik/system/VMRuntimeStatic;->getRuntime()Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Lblack/dalvik/system/BRVMRuntime;->get(Ljava/lang/Object;)Lblack/dalvik/system/VMRuntimeContext;

    move-result-object v5

    iget v6, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    invoke-interface {v5, v6}, Lblack/dalvik/system/VMRuntimeContext;->setTargetSdkVersion(I)Ljava/lang/Void;

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isS()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-static {}, Lblack/android/graphics/BRCompatibility;->get()Lblack/android/graphics/CompatibilityStatic;

    move-result-object v5

    iget v6, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    invoke-interface {v5, v6}, Lblack/android/graphics/CompatibilityStatic;->setTargetSdkVersion(I)Ljava/lang/Void;

    :cond_4
    if-eqz v2, :cond_6

    invoke-static {}, Lcom/vbox/core/VCore;->get()Lcom/vbox/core/VCore;

    move-result-object v5

    invoke-virtual {v5, v2}, Lcom/vbox/core/VCore;->enableRedirect(Landroid/content/Context;)V

    new-instance v5, Lcom/vbox/app/BActivityThread$AppBindData;

    invoke-direct {v5}, Lcom/vbox/app/BActivityThread$AppBindData;-><init>()V

    iput-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->appInfo:Landroid/content/pm/ApplicationInfo;

    iput-object p2, v5, Lcom/vbox/app/BActivityThread$AppBindData;->processName:Ljava/lang/String;

    iput-object v4, v5, Lcom/vbox/app/BActivityThread$AppBindData;->info:Ljava/lang/Object;

    iget-object v1, p0, Lcom/vbox/app/BActivityThread;->mProviders:Ljava/util/List;

    iput-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->providers:Ljava/util/List;

    invoke-static {v0}, Lblack/android/app/BRActivityThreadAppBindData;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadAppBindDataContext;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    iget-object v6, v5, Lcom/vbox/app/BActivityThread$AppBindData;->appInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v6, v6, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const-class v7, Landroid/app/Instrumentation;

    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v1, v6, v7}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-interface {v0, v1}, Lblack/android/app/ActivityThreadAppBindDataContext;->_set_instrumentationName(Ljava/lang/Object;)V

    iget-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->appInfo:Landroid/content/pm/ApplicationInfo;

    invoke-interface {v0, v1}, Lblack/android/app/ActivityThreadAppBindDataContext;->_set_appInfo(Ljava/lang/Object;)V

    iget-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->info:Ljava/lang/Object;

    invoke-interface {v0, v1}, Lblack/android/app/ActivityThreadAppBindDataContext;->_set_info(Ljava/lang/Object;)V

    iget-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->processName:Ljava/lang/String;

    invoke-interface {v0, v1}, Lblack/android/app/ActivityThreadAppBindDataContext;->_set_processName(Ljava/lang/Object;)V

    iget-object v1, v5, Lcom/vbox/app/BActivityThread$AppBindData;->providers:Ljava/util/List;

    invoke-interface {v0, v1}, Lblack/android/app/ActivityThreadAppBindDataContext;->_set_providers(Ljava/lang/Object;)V

    iput-object v5, p0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    invoke-static {}, Lblack/android/security/net/config/BRNetworkSecurityConfigProvider;->getRealClass()Ljava/lang/Class;

    move-result-object v0

    if-eqz v0, :cond_5

    const-string v0, "AndroidNSSP"

    invoke-static {v0}, Ljava/security/Security;->removeProvider(Ljava/lang/String;)V

    invoke-static {}, Lblack/android/security/net/config/BRNetworkSecurityConfigProvider;->get()Lblack/android/security/net/config/NetworkSecurityConfigProviderStatic;

    move-result-object v0

    invoke-interface {v0, v2}, Lblack/android/security/net/config/NetworkSecurityConfigProviderStatic;->install(Landroid/content/Context;)Ljava/lang/Void;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_5
    :try_start_3
    invoke-direct {p0, p1, p2, v2}, Lcom/vbox/app/BActivityThread;->onBeforeCreateApplication(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)V

    invoke-static {v4}, Lblack/android/app/BRLoadedApk;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkContext;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v3, v1}, Lblack/android/app/LoadedApkContext;->makeApplication(ZLandroid/app/Instrumentation;)Landroid/app/Application;

    move-result-object v0

    invoke-static {v0}, Lcom/vbox/utils/compat/ContextCompat;->fix(Landroid/content/Context;)V

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v1

    invoke-interface {v1}, Lblack/android/app/ActivityThreadContext;->getSystemContext()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/Context;

    invoke-static {v1}, Lcom/vbox/utils/compat/ContextCompat;->fix(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-static {}, Lcom/vbox/VBoxCore;->mainThread()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lblack/android/app/BRActivityThread;->get(Ljava/lang/Object;)Lblack/android/app/ActivityThreadContext;

    move-result-object v1

    iget-object v2, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-interface {v1, v2}, Lblack/android/app/ActivityThreadContext;->_set_mInitialApplication(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    iget-object v2, v5, Lcom/vbox/app/BActivityThread$AppBindData;->processName:Ljava/lang/String;

    iget-object v3, v5, Lcom/vbox/app/BActivityThread$AppBindData;->providers:Ljava/util/List;

    invoke-direct {p0, v1, v2, v3}, Lcom/vbox/app/BActivityThread;->installProviders(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)V

    invoke-direct {p0, p1, p2, v0}, Lcom/vbox/app/BActivityThread;->onBeforeApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;)V

    invoke-static {}, Lcom/vbox/fake/delegate/AppInstrumentation;->get()Lcom/vbox/fake/delegate/AppInstrumentation;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/fake/delegate/AppInstrumentation;->callApplicationOnCreate(Landroid/app/Application;)V

    invoke-direct {p0, p1, p2, v0}, Lcom/vbox/app/BActivityThread;->onAfterApplicationOnCreate(Ljava/lang/String;Ljava/lang/String;Landroid/app/Application;)V

    invoke-static {}, Lcom/vbox/fake/hook/HookManager;->get()Lcom/vbox/fake/hook/HookManager;

    move-result-object p1

    const-class p2, Lcom/vbox/fake/service/HCallbackStub;

    invoke-virtual {p1, p2}, Lcom/vbox/fake/hook/HookManager;->checkEnv(Ljava/lang/Class;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    monitor-exit p0

    return-void

    :catch_0
    move-exception p1

    :try_start_4
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Ljava/lang/RuntimeException;

    const-string v0, "Unable to makeApplication"

    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2

    :cond_6
    new-instance p1, Ljava/lang/AssertionError;

    invoke-direct {p1}, Ljava/lang/AssertionError;-><init>()V

    throw p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public handleNewIntent(Landroid/os/IBinder;Landroid/content/Intent;)V
    .registers 5

    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mH:Landroid/os/Handler;

    new-instance v1, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda3;

    invoke-direct {v1, p2, p1}, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda3;-><init>(Landroid/content/Intent;Landroid/os/IBinder;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public initProcess(Lcom/vbox/entity/AppConfig;)V
    .registers 6

    const-string v0, "reject init process: "

    sget-object v1, Lcom/vbox/app/BActivityThread;->mConfigLock:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object v2, p0, Lcom/vbox/app/BActivityThread;->mAppConfig:Lcom/vbox/entity/AppConfig;

    if-eqz v2, :cond_1

    iget-object v2, v2, Lcom/vbox/entity/AppConfig;->packageName:Ljava/lang/String;

    iget-object v3, p1, Lcom/vbox/entity/AppConfig;->packageName:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    new-instance v2, Ljava/lang/RuntimeException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, ", this process is : "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mAppConfig:Lcom/vbox/entity/AppConfig;

    iget-object v0, v0, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_1
    :goto_0
    iput-object p1, p0, Lcom/vbox/app/BActivityThread;->mAppConfig:Lcom/vbox/entity/AppConfig;

    invoke-virtual {p0}, Lcom/vbox/core/IBActivityThread$Stub;->asBinder()Landroid/os/IBinder;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    new-instance v0, Lcom/vbox/app/BActivityThread$1;

    invoke-direct {v0, p0, p1}, Lcom/vbox/app/BActivityThread$1;-><init>(Lcom/vbox/app/BActivityThread;Landroid/os/IBinder;)V

    const/4 v2, 0x0

    invoke-interface {p1, v0, v2}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catch_0
    move-exception p1

    :try_start_2
    const-string v0, "BActivityThread"

    const-string v2, "error"

    invoke-static {v0, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw p1
.end method

.method public isInit()Z
    .registers 2

    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mBoundApplication:Lcom/vbox/app/BActivityThread$AppBindData;

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method synthetic lambda$bindApplication$0$com-vbox-app-BActivityThread(Ljava/lang/String;Ljava/lang/String;Landroid/os/ConditionVariable;)V
    .registers 4

    .line 0
    invoke-virtual {p0, p1, p2}, Lcom/vbox/app/BActivityThread;->handleBindApplication(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p3}, Landroid/os/ConditionVariable;->open()V

    return-void
.end method

.method synthetic lambda$scheduleReceiver$3$com-vbox-app-BActivityThread(Lcom/vbox/entity/am/ReceiverData;)V
    .registers 6

    .line 0
    :try_start_0
    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mInitialApplication:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    iget-object v2, p1, Lcom/vbox/entity/am/ReceiverData;->intent:Landroid/content/Intent;

    invoke-virtual {v2, v1}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    iget-object v2, p1, Lcom/vbox/entity/am/ReceiverData;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, v2, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/BroadcastReceiver;

    invoke-static {v1}, Lblack/android/content/BRBroadcastReceiver;->get(Ljava/lang/Object;)Lblack/android/content/BroadcastReceiverContext;

    move-result-object v2

    iget-object v3, p1, Lcom/vbox/entity/am/ReceiverData;->data:Lcom/vbox/entity/am/PendingResultData;

    invoke-virtual {v3}, Lcom/vbox/entity/am/PendingResultData;->build()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object v3

    invoke-interface {v2, v3}, Lblack/android/content/BroadcastReceiverContext;->setPendingResult(Ljava/lang/Object;)Ljava/lang/Void;

    iget-object v2, p1, Lcom/vbox/entity/am/ReceiverData;->intent:Landroid/content/Intent;

    invoke-virtual {v1, v0, v2}, Landroid/content/BroadcastReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V

    invoke-static {v1}, Lblack/android/content/BRBroadcastReceiver;->get(Ljava/lang/Object;)Lblack/android/content/BroadcastReceiverContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/content/BroadcastReceiverContext;->getPendingResult()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v0

    iget-object v1, p1, Lcom/vbox/entity/am/ReceiverData;->data:Lcom/vbox/entity/am/PendingResultData;

    invoke-virtual {v0, v1}, Lcom/vbox/fake/frameworks/BActivityManager;->finishBroadcast(Lcom/vbox/entity/am/PendingResultData;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    const-string v1, "error"

    const-string v2, "BActivityThread"

    invoke-static {v2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error receiving broadcast "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Lcom/vbox/entity/am/ReceiverData;->intent:Landroid/content/Intent;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/vbox/utils/Slog;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method

.method public peekService(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 3

    invoke-static {}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->get()Lcom/vbox/app/dispatcher/AppServiceDispatcher;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->peekService(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    return-object p1
.end method

.method public restartJobService(Ljava/lang/String;)V
    .registers 2

    return-void
.end method

.method public scheduleReceiver(Lcom/vbox/entity/am/ReceiverData;)V
    .registers 4

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->isInit()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Lcom/vbox/app/BActivityThread;->bindApplication()V

    :cond_0
    iget-object v0, p0, Lcom/vbox/app/BActivityThread;->mH:Landroid/os/Handler;

    new-instance v1, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1}, Lcom/vbox/app/BActivityThread$$ExternalSyntheticLambda0;-><init>(Lcom/vbox/app/BActivityThread;Lcom/vbox/entity/am/ReceiverData;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public stopService(Landroid/content/Intent;)V
    .registers 3

    invoke-static {}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->get()Lcom/vbox/app/dispatcher/AppServiceDispatcher;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/app/dispatcher/AppServiceDispatcher;->stopService(Landroid/content/Intent;)V

    return-void
.end method
