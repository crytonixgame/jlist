.class public Lcom/vbox/app/RequestPermissionsActivity;
.super Landroid/app/Activity;
.source "SourceFile"


# static fields
.field private static final REQUEST_PERMISSION_CODE:I = 0x3e4


# instance fields
.field private mCallBack:Lcom/vbox/core/system/am/IRequestPermissionsResult;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method public static request(Landroid/content/Context;[Ljava/lang/String;Lcom/vbox/core/system/am/IRequestPermissionsResult;)V
    .registers 6

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/vbox/app/RequestPermissionsActivity;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const-string v1, "permissions"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p1

    const-string p2, "callback"

    invoke-static {v0, p2, p1}, Lcom/vbox/utils/compat/BundleCompat;->putBinder(Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;)V

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .registers 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-nez p1, :cond_0

    return-void

    :cond_0
    const-string v0, "permissions"

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const-string v1, "callback"

    invoke-static {p1, v1}, Lcom/vbox/utils/compat/BundleCompat;->getBinder(Landroid/content/Intent;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object p1

    if-eqz p1, :cond_2

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    invoke-static {p1}, Lcom/vbox/core/system/am/IRequestPermissionsResult$Stub;->asInterface(Landroid/os/IBinder;)Lcom/vbox/core/system/am/IRequestPermissionsResult;

    move-result-object p1

    iput-object p1, p0, Lcom/vbox/app/RequestPermissionsActivity;->mCallBack:Lcom/vbox/core/system/am/IRequestPermissionsResult;

    const/16 p1, 0x3e4

    invoke-virtual {p0, v0, p1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

    :cond_2
    :goto_0
    return-void
.end method

.method public onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 5

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    iget-object v0, p0, Lcom/vbox/app/RequestPermissionsActivity;->mCallBack:Lcom/vbox/core/system/am/IRequestPermissionsResult;

    if-eqz v0, :cond_0

    :try_start_0
    invoke-interface {v0, p1, p2, p3}, Lcom/vbox/core/system/am/IRequestPermissionsResult;->onResult(I[Ljava/lang/String;[I)Z

    move-result p1

    if-nez p1, :cond_0

    new-instance p1, Lcom/vbox/app/RequestPermissionsActivity$1;

    invoke-direct {p1, p0}, Lcom/vbox/app/RequestPermissionsActivity$1;-><init>(Lcom/vbox/app/RequestPermissionsActivity;)V

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    return-void
.end method
