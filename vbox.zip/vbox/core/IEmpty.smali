.class public interface abstract Lcom/vbox/core/IEmpty;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/IEmpty$Stub;,
        Lcom/vbox/core/IEmpty$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.IEmpty"
