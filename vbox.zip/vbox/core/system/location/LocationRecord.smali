.class public Lcom/vbox/core/system/location/LocationRecord;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public packageName:Ljava/lang/String;

.field public userId:I


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vbox/core/system/location/LocationRecord;->packageName:Ljava/lang/String;

    iput p2, p0, Lcom/vbox/core/system/location/LocationRecord;->userId:I

    return-void
.end method
