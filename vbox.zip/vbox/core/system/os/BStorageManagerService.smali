.class public Lcom/vbox/core/system/os/BStorageManagerService;
.super Lcom/vbox/core/system/os/IBStorageManagerService$Stub;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/ISystemService;


# static fields
.field private static final sService:Lcom/vbox/core/system/os/BStorageManagerService;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/core/system/os/BStorageManagerService;

    invoke-direct {v0}, Lcom/vbox/core/system/os/BStorageManagerService;-><init>()V

    sput-object v0, Lcom/vbox/core/system/os/BStorageManagerService;->sService:Lcom/vbox/core/system/os/BStorageManagerService;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/core/system/os/IBStorageManagerService$Stub;-><init>()V

    return-void
.end method

.method public static get()Lcom/vbox/core/system/os/BStorageManagerService;
    .registers 1

    sget-object v0, Lcom/vbox/core/system/os/BStorageManagerService;->sService:Lcom/vbox/core/system/os/BStorageManagerService;

    return-object v0
.end method


# virtual methods
.method public getUriForFile(Ljava/lang/String;)Landroid/net/Uri;
    .registers 5

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {}, Lcom/vbox/proxy/ProxyManifest;->getProxyFileProvider()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/io/File;

    invoke-direct {v2, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-static {v0, v1, v2}, Lcom/vbox/fake/provider/FileProvider;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p1

    return-object p1
.end method

.method public getVolumeList(ILjava/lang/String;II)[Landroid/os/storage/StorageVolume;
    .registers 8

    invoke-static {}, Lblack/android/os/storage/BRStorageManager;->get()Lblack/android/os/storage/StorageManagerStatic;

    move-result-object p1

    const/4 p2, 0x0

    invoke-interface {p1, p2, p2}, Lblack/android/os/storage/StorageManagerStatic;->getVolumeList(II)[Landroid/os/storage/StorageVolume;

    move-result-object p1

    const/4 p3, 0x0

    if-nez p1, :cond_0

    return-object p3

    :cond_0
    :try_start_0
    invoke-static {}, Lblack/android/os/storage/BRStorageManager;->get()Lblack/android/os/storage/StorageManagerStatic;

    move-result-object p1

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result p4

    invoke-static {p4}, Lcom/vbox/core/system/user/BUserHandle;->getUserId(I)I

    move-result p4

    invoke-interface {p1, p4, p2}, Lblack/android/os/storage/StorageManagerStatic;->getVolumeList(II)[Landroid/os/storage/StorageVolume;

    move-result-object p1

    if-nez p1, :cond_1

    return-object p3

    :cond_1
    array-length p4, p1

    :goto_0
    if-ge p2, p4, :cond_3

    aget-object v0, p1, p2

    invoke-static {v0}, Lblack/android/os/storage/BRStorageVolume;->get(Ljava/lang/Object;)Lblack/android/os/storage/StorageVolumeContext;

    move-result-object v1

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    invoke-interface {v1, v2}, Lblack/android/os/storage/StorageVolumeContext;->_set_mPath(Ljava/lang/Object;)V

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isPie()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-static {v0}, Lblack/android/os/storage/BRStorageVolume;->get(Ljava/lang/Object;)Lblack/android/os/storage/StorageVolumeContext;

    move-result-object v0

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-interface {v0, v1}, Lblack/android/os/storage/StorageVolumeContext;->_set_mInternalPath(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_2
    add-int/lit8 p2, p2, 0x1

    goto :goto_0

    :cond_3
    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    return-object p3
.end method

.method public systemReady()V
    .registers 1

    return-void
.end method
