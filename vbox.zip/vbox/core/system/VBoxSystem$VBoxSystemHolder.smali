.class final Lcom/vbox/core/system/VBoxSystem$VBoxSystemHolder;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/VBoxSystem;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "VBoxSystemHolder"
.end annotation


# static fields
.field static final VBoxSystem:Lcom/vbox/core/system/VBoxSystem;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/core/system/VBoxSystem;

    invoke-direct {v0}, Lcom/vbox/core/system/VBoxSystem;-><init>()V

    sput-object v0, Lcom/vbox/core/system/VBoxSystem$VBoxSystemHolder;->VBoxSystem:Lcom/vbox/core/system/VBoxSystem;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
