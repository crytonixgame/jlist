.class public interface abstract Lcom/vbox/core/system/pm/IBPackageInstallerService;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/pm/IBPackageInstallerService$_Parcel;,
        Lcom/vbox/core/system/pm/IBPackageInstallerService$Stub;,
        Lcom/vbox/core/system/pm/IBPackageInstallerService$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.system.pm.IBPackageInstallerService"


# virtual methods
.method public abstract clearPackage(Lcom/vbox/core/system/pm/BPackageSettings;I)I
.end method

.method public abstract installPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;I)I
.end method

.method public abstract uninstallPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;ZI)I
.end method

.method public abstract updatePackage(Lcom/vbox/core/system/pm/BPackageSettings;)I
.end method
