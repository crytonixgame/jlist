.class public Lcom/vbox/core/system/pm/BPackageInstallerService;
.super Lcom/vbox/core/system/pm/IBPackageInstallerService$Stub;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/ISystemService;


# static fields
.field public static final TAG:Ljava/lang/String; = "BPackageInstallerService"

.field private static final sService:Lcom/vbox/core/system/pm/BPackageInstallerService;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/core/system/pm/BPackageInstallerService;

    invoke-direct {v0}, Lcom/vbox/core/system/pm/BPackageInstallerService;-><init>()V

    sput-object v0, Lcom/vbox/core/system/pm/BPackageInstallerService;->sService:Lcom/vbox/core/system/pm/BPackageInstallerService;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/core/system/pm/IBPackageInstallerService$Stub;-><init>()V

    return-void
.end method

.method public static get()Lcom/vbox/core/system/pm/BPackageInstallerService;
    .registers 1

    sget-object v0, Lcom/vbox/core/system/pm/BPackageInstallerService;->sService:Lcom/vbox/core/system/pm/BPackageInstallerService;

    return-object v0
.end method


# virtual methods
.method public clearPackage(Lcom/vbox/core/system/pm/BPackageSettings;I)I
    .registers 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/vbox/core/system/pm/installer/RemoveUserExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/RemoveUserExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/vbox/core/system/pm/installer/CreateUserExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CreateUserExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p1, Lcom/vbox/core/system/pm/BPackageSettings;->installOption:Lcom/vbox/entity/pm/InstallOption;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/pm/installer/Executor;

    invoke-interface {v2, p1, v1, p2}, Lcom/vbox/core/system/pm/installer/Executor;->exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "uninstallPackageAsUser: "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " exec: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "BPackageInstallerService"

    invoke-static {v4, v2}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v3, :cond_0

    return v3

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public installPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;I)I
    .registers 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/vbox/core/system/pm/installer/CreateUserExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CreateUserExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/vbox/core/system/pm/installer/CreatePackageExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CreatePackageExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/vbox/core/system/pm/installer/CopyExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CopyExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p1, Lcom/vbox/core/system/pm/BPackageSettings;->installOption:Lcom/vbox/entity/pm/InstallOption;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/pm/installer/Executor;

    invoke-interface {v2, p1, v1, p2}, Lcom/vbox/core/system/pm/installer/Executor;->exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "installPackageAsUser: "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, " exec: "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v4, "BPackageInstallerService"

    invoke-static {v4, v2}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v3, :cond_0

    return v3

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public systemReady()V
    .registers 1

    return-void
.end method

.method public uninstallPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;ZI)I
    .registers 9

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    if-eqz p2, :cond_0

    new-instance p2, Lcom/vbox/core/system/pm/installer/RemoveAppExecutor;

    invoke-direct {p2}, Lcom/vbox/core/system/pm/installer/RemoveAppExecutor;-><init>()V

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    new-instance p2, Lcom/vbox/core/system/pm/installer/RemoveUserExecutor;

    invoke-direct {p2}, Lcom/vbox/core/system/pm/installer/RemoveUserExecutor;-><init>()V

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p2, p1, Lcom/vbox/core/system/pm/BPackageSettings;->installOption:Lcom/vbox/entity/pm/InstallOption;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/pm/installer/Executor;

    invoke-interface {v1, p1, p2, p3}, Lcom/vbox/core/system/pm/installer/Executor;->exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "uninstallPackageAsUser: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " exec: "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "BPackageInstallerService"

    invoke-static {v3, v1}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v2, :cond_1

    return v2

    :cond_2
    const/4 p1, 0x0

    return p1
.end method

.method public updatePackage(Lcom/vbox/core/system/pm/BPackageSettings;)I
    .registers 6

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    new-instance v1, Lcom/vbox/core/system/pm/installer/CreatePackageExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CreatePackageExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    new-instance v1, Lcom/vbox/core/system/pm/installer/CopyExecutor;

    invoke-direct {v1}, Lcom/vbox/core/system/pm/installer/CopyExecutor;-><init>()V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v1, p1, Lcom/vbox/core/system/pm/BPackageSettings;->installOption:Lcom/vbox/entity/pm/InstallOption;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/pm/installer/Executor;

    const/4 v3, -0x1

    invoke-interface {v2, p1, v1, v3}, Lcom/vbox/core/system/pm/installer/Executor;->exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I

    move-result v2

    if-eqz v2, :cond_0

    return v2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method
