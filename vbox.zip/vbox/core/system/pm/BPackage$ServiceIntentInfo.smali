.class public Lcom/vbox/core/system/pm/BPackage$ServiceIntentInfo;
.super Lcom/vbox/core/system/pm/BPackage$IntentInfo;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/pm/BPackage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ServiceIntentInfo"
.end annotation


# instance fields
.field public service:Lcom/vbox/core/system/pm/BPackage$Service;


# direct methods
.method public constructor <init>(Landroid/content/pm/PackageParser$IntentInfo;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lcom/vbox/core/system/pm/BPackage$IntentInfo;-><init>(Landroid/content/pm/PackageParser$IntentInfo;)V

    return-void
.end method

.method public constructor <init>(Lcom/vbox/core/system/pm/BPackage$IntentInfo;)V
    .registers 2

    .line 2
    invoke-direct {p0, p1}, Lcom/vbox/core/system/pm/BPackage$IntentInfo;-><init>(Lcom/vbox/core/system/pm/BPackage$IntentInfo;)V

    return-void
.end method
