.class public interface abstract Lcom/vbox/core/system/pm/installer/Executor;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final TAG:Ljava/lang/String; = "InstallExecutor"


# virtual methods
.method public abstract exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I
.end method
