.class public Lcom/vbox/core/system/pm/installer/RemoveAppExecutor;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/pm/installer/Executor;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public exec(Lcom/vbox/core/system/pm/BPackageSettings;Lcom/vbox/entity/pm/InstallOption;I)I
    .registers 4

    iget-object p1, p1, Lcom/vbox/core/system/pm/BPackageSettings;->pkg:Lcom/vbox/core/system/pm/BPackage;

    iget-object p1, p1, Lcom/vbox/core/system/pm/BPackage;->packageName:Ljava/lang/String;

    invoke-static {p1}, Lcom/vbox/core/env/BEnvironment;->getAppDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    invoke-static {p1}, Lcom/vbox/utils/FileUtils;->deleteDir(Ljava/io/File;)I

    const/4 p1, 0x0

    return p1
.end method
