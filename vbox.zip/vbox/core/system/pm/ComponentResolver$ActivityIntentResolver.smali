.class final Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;
.super Lcom/vbox/core/system/pm/IntentResolver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/pm/ComponentResolver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "ActivityIntentResolver"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/vbox/core/system/pm/IntentResolver<",
        "Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;",
        "Landroid/content/pm/ResolveInfo;",
        ">;"
    }
.end annotation


# instance fields
.field private final mActivities:Landroid/util/ArrayMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/ArrayMap<",
            "Landroid/content/ComponentName;",
            "Lcom/vbox/core/system/pm/BPackage$Activity;",
            ">;"
        }
    .end annotation
.end field

.field private mFlags:I


# direct methods
.method private constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lcom/vbox/core/system/pm/IntentResolver;-><init>()V

    new-instance v0, Landroid/util/ArrayMap;

    invoke-direct {v0}, Landroid/util/ArrayMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mActivities:Landroid/util/ArrayMap;

    return-void
.end method

.method public synthetic constructor <init>(Lcom/vbox/core/system/pm/ComponentResolver$1;)V
    .registers 2

    .line 2
    invoke-direct {p0}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;-><init>()V

    return-void
.end method

.method public static synthetic access$300(Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->removeActivity(Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic access$400(Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;Ljava/util/List;)V
    .registers 4

    invoke-direct {p0, p1, p2, p3}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->addActivity(Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;Ljava/util/List;)V

    return-void
.end method

.method public static synthetic access$500(Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;)Landroid/util/ArrayMap;
    .registers 1

    iget-object p0, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mActivities:Landroid/util/ArrayMap;

    return-object p0
.end method

.method private addActivity(Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;Ljava/util/List;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/vbox/core/system/pm/BPackage$Activity;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;",
            ">;)V"
        }
    .end annotation

    iget-object v0, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mActivities:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Lcom/vbox/core/system/pm/BPackage$Component;->getComponentName()Landroid/content/ComponentName;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Landroid/util/ArrayMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p1, Lcom/vbox/core/system/pm/BPackage$Component;->intents:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_1

    iget-object v2, p1, Lcom/vbox/core/system/pm/BPackage$Component;->intents:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    if-eqz p3, :cond_0

    const-string v3, "activity"

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {p3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    invoke-virtual {p0, v2}, Lcom/vbox/core/system/pm/IntentResolver;->addFilter(Lcom/vbox/core/system/pm/BPackage$IntentInfo;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method

.method private removeActivity(Lcom/vbox/core/system/pm/BPackage$Activity;Ljava/lang/String;)V
    .registers 5

    iget-object p2, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mActivities:Landroid/util/ArrayMap;

    invoke-virtual {p1}, Lcom/vbox/core/system/pm/BPackage$Component;->getComponentName()Landroid/content/ComponentName;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/util/ArrayMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p2, p1, Lcom/vbox/core/system/pm/BPackage$Component;->intents:Ljava/util/ArrayList;

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v0, 0x0

    :goto_0
    if-ge v0, p2, :cond_0

    iget-object v1, p1, Lcom/vbox/core/system/pm/BPackage$Component;->intents:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    invoke-virtual {p0, v1}, Lcom/vbox/core/system/pm/IntentResolver;->removeFilter(Lcom/vbox/core/system/pm/BPackage$IntentInfo;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public isPackageForFilter(Ljava/lang/String;Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;)Z
    .registers 3

    .line 1
    iget-object p2, p2, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;->activity:Lcom/vbox/core/system/pm/BPackage$Activity;

    iget-object p2, p2, Lcom/vbox/core/system/pm/BPackage$Component;->owner:Lcom/vbox/core/system/pm/BPackage;

    iget-object p2, p2, Lcom/vbox/core/system/pm/BPackage;->packageName:Ljava/lang/String;

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    return p1
.end method

.method public bridge synthetic isPackageForFilter(Ljava/lang/String;Lcom/vbox/core/system/pm/BPackage$IntentInfo;)Z
    .registers 3

    .line 2
    check-cast p2, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    invoke-virtual {p0, p1, p2}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->isPackageForFilter(Ljava/lang/String;Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;)Z

    move-result p1

    return p1
.end method

.method public newArray(I)[Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;
    .registers 2

    .line 1
    new-array p1, p1, [Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Lcom/vbox/core/system/pm/BPackage$IntentInfo;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->newArray(I)[Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    move-result-object p1

    return-object p1
.end method

.method public newResult(Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;II)Landroid/content/pm/ResolveInfo;
    .registers 7

    .line 1
    iget-object v0, p1, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;->activity:Lcom/vbox/core/system/pm/BPackage$Activity;

    iget-object v1, v0, Lcom/vbox/core/system/pm/BPackage$Component;->owner:Lcom/vbox/core/system/pm/BPackage;

    iget-object v1, v1, Lcom/vbox/core/system/pm/BPackage;->mExtras:Lcom/vbox/core/system/pm/BPackageSettings;

    if-nez v1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iget v2, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mFlags:I

    invoke-virtual {v1, p3}, Lcom/vbox/core/system/pm/BPackageSettings;->readUserState(I)Lcom/vbox/core/system/pm/BPackageUserState;

    move-result-object v1

    invoke-static {v0, v2, v1, p3}, Lcom/vbox/core/system/pm/PackageManagerCompat;->generateActivityInfo(Lcom/vbox/core/system/pm/BPackage$Activity;ILcom/vbox/core/system/pm/BPackageUserState;I)Landroid/content/pm/ActivityInfo;

    move-result-object p3

    new-instance v1, Landroid/content/pm/ResolveInfo;

    invoke-direct {v1}, Landroid/content/pm/ResolveInfo;-><init>()V

    iput-object p3, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget p3, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mFlags:I

    and-int/lit8 p3, p3, 0x40

    if-eqz p3, :cond_1

    iget-object p3, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->intentFilter:Landroid/content/IntentFilter;

    iput-object p3, v1, Landroid/content/pm/ResolveInfo;->filter:Landroid/content/IntentFilter;

    :cond_1
    iget-object p3, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->intentFilter:Landroid/content/IntentFilter;

    invoke-virtual {p3}, Landroid/content/IntentFilter;->getPriority()I

    move-result p3

    iput p3, v1, Landroid/content/pm/ResolveInfo;->priority:I

    iget-object p3, v0, Lcom/vbox/core/system/pm/BPackage$Component;->owner:Lcom/vbox/core/system/pm/BPackage;

    iget p3, p3, Lcom/vbox/core/system/pm/BPackage;->mPreferredOrder:I

    iput p3, v1, Landroid/content/pm/ResolveInfo;->preferredOrder:I

    iput p2, v1, Landroid/content/pm/ResolveInfo;->match:I

    iget-boolean p2, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->hasDefault:Z

    iput-boolean p2, v1, Landroid/content/pm/ResolveInfo;->isDefault:Z

    iget p2, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->labelRes:I

    iput p2, v1, Landroid/content/pm/ResolveInfo;->labelRes:I

    iget-object p2, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->nonLocalizedLabel:Ljava/lang/String;

    iput-object p2, v1, Landroid/content/pm/ResolveInfo;->nonLocalizedLabel:Ljava/lang/CharSequence;

    iget p1, p1, Lcom/vbox/core/system/pm/BPackage$IntentInfo;->icon:I

    iput p1, v1, Landroid/content/pm/ResolveInfo;->icon:I

    return-object v1
.end method

.method public bridge synthetic newResult(Lcom/vbox/core/system/pm/BPackage$IntentInfo;II)Ljava/lang/Object;
    .registers 4

    .line 2
    check-cast p1, Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    invoke-virtual {p0, p1, p2, p3}, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->newResult(Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;II)Landroid/content/pm/ResolveInfo;

    move-result-object p1

    return-object p1
.end method

.method public queryIntent(Landroid/content/Intent;Ljava/lang/String;II)Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            "Ljava/lang/String;",
            "II)",
            "Ljava/util/List<",
            "Landroid/content/pm/ResolveInfo;",
            ">;"
        }
    .end annotation

    .line 1
    iput p3, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mFlags:I

    const/high16 v0, 0x10000

    and-int/2addr p3, v0

    if-eqz p3, :cond_0

    const/4 p3, 0x1

    goto :goto_0

    :cond_0
    const/4 p3, 0x0

    :goto_0
    invoke-super {p0, p1, p2, p3, p4}, Lcom/vbox/core/system/pm/IntentResolver;->queryIntent(Landroid/content/Intent;Ljava/lang/String;ZI)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public queryIntent(Landroid/content/Intent;Ljava/lang/String;ZI)Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            "Ljava/lang/String;",
            "ZI)",
            "Ljava/util/List<",
            "Landroid/content/pm/ResolveInfo;",
            ">;"
        }
    .end annotation

    .line 2
    if-eqz p3, :cond_0

    const/high16 v0, 0x10000

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iput v0, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mFlags:I

    invoke-super {p0, p1, p2, p3, p4}, Lcom/vbox/core/system/pm/IntentResolver;->queryIntent(Landroid/content/Intent;Ljava/lang/String;ZI)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public queryIntentForPackage(Landroid/content/Intent;Ljava/lang/String;ILjava/util/List;I)Ljava/util/List;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            "Ljava/lang/String;",
            "I",
            "Ljava/util/List<",
            "Lcom/vbox/core/system/pm/BPackage$Activity;",
            ">;I)",
            "Ljava/util/List<",
            "Landroid/content/pm/ResolveInfo;",
            ">;"
        }
    .end annotation

    if-nez p4, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    iput p3, p0, Lcom/vbox/core/system/pm/ComponentResolver$ActivityIntentResolver;->mFlags:I

    const/high16 v0, 0x10000

    and-int/2addr p3, v0

    const/4 v0, 0x0

    if-eqz p3, :cond_1

    const/4 p3, 0x1

    move v4, p3

    goto :goto_0

    :cond_1
    move v4, v0

    :goto_0
    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result p3

    new-instance v5, Ljava/util/ArrayList;

    invoke-direct {v5, p3}, Ljava/util/ArrayList;-><init>(I)V

    :goto_1
    if-ge v0, p3, :cond_3

    invoke-interface {p4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/pm/BPackage$Activity;

    iget-object v1, v1, Lcom/vbox/core/system/pm/BPackage$Component;->intents:Ljava/util/ArrayList;

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_2

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    new-array v2, v2, [Lcom/vbox/core/system/pm/BPackage$ActivityIntentInfo;

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_3
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p5

    invoke-super/range {v1 .. v6}, Lcom/vbox/core/system/pm/IntentResolver;->queryIntentFromList(Landroid/content/Intent;Ljava/lang/String;ZLjava/util/ArrayList;I)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method
