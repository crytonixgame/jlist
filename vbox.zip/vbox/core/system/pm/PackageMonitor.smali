.class public interface abstract Lcom/vbox/core/system/pm/PackageMonitor;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract onPackageInstalled(Ljava/lang/String;I)V
.end method

.method public abstract onPackageUninstalled(Ljava/lang/String;ZI)V
.end method
