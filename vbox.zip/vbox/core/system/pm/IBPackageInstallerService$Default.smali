.class public Lcom/vbox/core/system/pm/IBPackageInstallerService$Default;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/pm/IBPackageInstallerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/pm/IBPackageInstallerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public clearPackage(Lcom/vbox/core/system/pm/BPackageSettings;I)I
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public installPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;I)I
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public uninstallPackageAsUser(Lcom/vbox/core/system/pm/BPackageSettings;ZI)I
    .registers 4

    const/4 p1, 0x0

    return p1
.end method

.method public updatePackage(Lcom/vbox/core/system/pm/BPackageSettings;)I
    .registers 2

    const/4 p1, 0x0

    return p1
.end method
