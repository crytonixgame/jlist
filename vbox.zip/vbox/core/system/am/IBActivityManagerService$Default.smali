.class public Lcom/vbox/core/system/am/IBActivityManagerService$Default;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/am/IBActivityManagerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/am/IBActivityManagerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public asBinder()Landroid/os/IBinder;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public bindService(Landroid/content/Intent;Landroid/os/IBinder;Ljava/lang/String;I)Landroid/content/Intent;
    .registers 5

    const/4 p1, 0x0

    return-object p1
.end method

.method public checkPermission(Ljava/lang/String;IILjava/lang/String;)I
    .registers 5

    const/4 p1, 0x0

    return p1
.end method

.method public finishBroadcast(Lcom/vbox/entity/am/PendingResultData;)V
    .registers 2

    return-void
.end method

.method public getCallingActivity(Landroid/os/IBinder;I)Landroid/content/ComponentName;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getCallingPackage(Landroid/os/IBinder;I)Ljava/lang/String;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getIntentSender(Landroid/os/IBinder;Ljava/lang/String;II)V
    .registers 5

    return-void
.end method

.method public getPackageForIntentSender(Landroid/os/IBinder;I)Ljava/lang/String;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getRunningAppProcesses(Ljava/lang/String;I)Lcom/vbox/entity/am/RunningAppProcessInfo;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getRunningServices(Ljava/lang/String;I)Lcom/vbox/entity/am/RunningServiceInfo;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getUidForIntentSender(Landroid/os/IBinder;I)I
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public initProcess(Ljava/lang/String;Ljava/lang/String;I)Lcom/vbox/entity/AppConfig;
    .registers 4

    const/4 p1, 0x0

    return-object p1
.end method

.method public onActivityCreated(ILandroid/os/IBinder;Ljava/lang/String;)V
    .registers 4

    return-void
.end method

.method public onActivityDestroyed(Landroid/os/IBinder;)V
    .registers 2

    return-void
.end method

.method public onActivityResumed(Landroid/os/IBinder;)V
    .registers 2

    return-void
.end method

.method public onFinishActivity(Landroid/os/IBinder;)V
    .registers 2

    return-void
.end method

.method public onServiceDestroy(Landroid/content/Intent;I)V
    .registers 3

    return-void
.end method

.method public onServiceUnbind(Landroid/content/Intent;I)Lcom/vbox/entity/UnbindRecord;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public onStartCommand(Landroid/content/Intent;I)V
    .registers 3

    return-void
.end method

.method public peekService(Landroid/content/Intent;Ljava/lang/String;I)Landroid/os/IBinder;
    .registers 4

    const/4 p1, 0x0

    return-object p1
.end method

.method public restartProcess(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 4

    return-void
.end method

.method public scheduleBroadcastReceiver(Landroid/content/Intent;Lcom/vbox/entity/am/PendingResultData;I)V
    .registers 4

    return-void
.end method

.method public sendBroadcast(Landroid/content/Intent;Ljava/lang/String;I)Landroid/content/Intent;
    .registers 4

    const/4 p1, 0x0

    return-object p1
.end method

.method public startActivities(I[Landroid/content/Intent;[Ljava/lang/String;Landroid/os/IBinder;Landroid/os/Bundle;)I
    .registers 6

    const/4 p1, 0x0

    return p1
.end method

.method public startActivity(Landroid/content/Intent;I)V
    .registers 3

    return-void
.end method

.method public startActivityAms(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I
    .registers 9

    const/4 p1, 0x0

    return p1
.end method

.method public startService(Landroid/content/Intent;Ljava/lang/String;ZI)Landroid/content/ComponentName;
    .registers 5

    const/4 p1, 0x0

    return-object p1
.end method

.method public stopService(Landroid/content/Intent;Ljava/lang/String;I)I
    .registers 4

    const/4 p1, 0x0

    return p1
.end method

.method public stopServiceToken(Landroid/content/ComponentName;Landroid/os/IBinder;I)V
    .registers 4

    return-void
.end method

.method public unbindService(Landroid/os/IBinder;I)V
    .registers 3

    return-void
.end method
