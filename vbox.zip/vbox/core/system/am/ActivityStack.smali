.class public Lcom/vbox/core/system/am/ActivityStack;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final synthetic $assertionsDisabled:Z = false

.field public static final LAUNCH_TIME_OUT:I = 0x0

.field public static final TAG:Ljava/lang/String; = "ActivityStack"


# instance fields
.field private final mAms:Landroid/app/ActivityManager;

.field private final mHandler:Landroid/os/Handler;

.field private final mLaunchingActivities:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/vbox/core/system/am/ActivityRecord;",
            ">;"
        }
    .end annotation
.end field

.field private final mTasks:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/vbox/core/system/am/TaskRecord;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 0

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    new-instance v0, Lcom/vbox/core/system/am/ActivityStack$1;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/vbox/core/system/am/ActivityStack$1;-><init>(Lcom/vbox/core/system/am/ActivityStack;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mHandler:Landroid/os/Handler;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "activity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    iput-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mAms:Landroid/app/ActivityManager;

    return-void
.end method

.method public static synthetic access$000(Lcom/vbox/core/system/am/ActivityStack;)Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    return-object p0
.end method

.method private deliverNewIntentLocked(Lcom/vbox/core/system/am/ActivityRecord;Landroid/content/Intent;)V
    .registers 4

    :try_start_0
    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->processRecord:Lcom/vbox/core/system/ProcessRecord;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/ProcessRecord;

    iget-object v0, v0, Lcom/vbox/core/system/ProcessRecord;->bActivityThread:Lcom/vbox/core/IBActivityThread;

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->token:Landroid/os/IBinder;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/IBActivityThread;->handleNewIntent(Landroid/os/IBinder;Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method private findActivityRecordByComponentName(ILandroid/content/ComponentName;)Lcom/vbox/core/system/am/ActivityRecord;
    .registers 8

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/am/TaskRecord;

    iget v3, v2, Lcom/vbox/core/system/am/TaskRecord;->userId:I

    if-ne p1, v3, :cond_0

    iget-object v2, v2, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vbox/core/system/am/ActivityRecord;

    iget-object v4, v3, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {v4, p2}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    move-object v1, v3

    goto :goto_0

    :cond_2
    return-object v1
.end method

.method private findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;
    .registers 8

    const/4 v0, 0x0

    if-eqz p2, :cond_2

    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/am/TaskRecord;

    iget v3, v2, Lcom/vbox/core/system/am/TaskRecord;->userId:I

    if-ne p1, v3, :cond_0

    iget-object v2, v2, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vbox/core/system/am/ActivityRecord;

    iget-object v4, v3, Lcom/vbox/core/system/am/ActivityRecord;->token:Landroid/os/IBinder;

    if-ne v4, p2, :cond_1

    move-object v0, v3

    goto :goto_0

    :cond_2
    return-object v0
.end method

.method private findTaskRecordByTaskAffinityLocked(ILjava/lang/String;)Lcom/vbox/core/system/am/TaskRecord;
    .registers 7

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/am/TaskRecord;

    iget v3, v2, Lcom/vbox/core/system/am/TaskRecord;->userId:I

    if-ne p1, v3, :cond_0

    iget-object v3, v2, Lcom/vbox/core/system/am/TaskRecord;->taskAffinity:Ljava/lang/String;

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    monitor-exit v0

    return-object v2

    :cond_1
    monitor-exit v0

    const/4 p1, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method private finishAllActivity(I)V
    .registers 6

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/am/TaskRecord;

    iget-object v1, v1, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/am/ActivityRecord;

    iget v3, v2, Lcom/vbox/core/system/am/ActivityRecord;->userId:I

    if-ne v3, p1, :cond_1

    iget-boolean v3, v2, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    if-eqz v3, :cond_1

    :try_start_0
    iget-object v3, v2, Lcom/vbox/core/system/am/ActivityRecord;->processRecord:Lcom/vbox/core/system/ProcessRecord;

    if-eqz v3, :cond_2

    iget-object v3, v2, Lcom/vbox/core/system/am/ActivityRecord;->processRecord:Lcom/vbox/core/system/ProcessRecord;

    iget-object v3, v3, Lcom/vbox/core/system/ProcessRecord;->bActivityThread:Lcom/vbox/core/IBActivityThread;

    iget-object v2, v2, Lcom/vbox/core/system/am/ActivityRecord;->token:Landroid/os/IBinder;

    invoke-interface {v3, v2}, Lcom/vbox/core/IBActivityThread;->finishActivity(Landroid/os/IBinder;)V

    goto :goto_0

    :catch_0
    move-exception v2

    goto :goto_0

    :cond_2
    new-instance v2, Ljava/lang/AssertionError;

    invoke-direct {v2}, Ljava/lang/AssertionError;-><init>()V

    throw v2
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_3
    return-void
.end method

.method private getStartStubActivityIntentInner(Landroid/content/Intent;ILcom/vbox/proxy/record/ProxyActivityRecord;Landroid/content/pm/ActivityInfo;)Landroid/content/Intent;
    .registers 11

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v1, 0x0

    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v2

    iget-object v3, p4, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    invoke-static {v2, v3}, Lcom/vbox/core/system/pm/PackageManagerCompat;->getResources(Landroid/content/Context;Landroid/content/pm/ApplicationInfo;)Landroid/content/res/Resources;

    move-result-object v2

    iget v3, p4, Landroid/content/pm/ActivityInfo;->theme:I

    if-eqz v3, :cond_0

    goto :goto_0

    :cond_0
    iget-object v3, p4, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget v3, v3, Landroid/content/pm/ApplicationInfo;->theme:I

    :goto_0
    if-eqz v2, :cond_2

    invoke-virtual {v2}, Landroid/content/res/Resources;->newTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    invoke-static {}, Lblack/com/android/internal/BRRstyleable;->get()Lblack/com/android/internal/RstyleableStatic;

    move-result-object v4

    invoke-interface {v4}, Lblack/com/android/internal/RstyleableStatic;->Window()[I

    move-result-object v4

    invoke-virtual {v2, v3, v4}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object v1

    invoke-static {}, Lblack/com/android/internal/BRRstyleable;->get()Lblack/com/android/internal/RstyleableStatic;

    move-result-object v2

    invoke-interface {v2}, Lblack/com/android/internal/RstyleableStatic;->Window_windowIsTranslucent()Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v2

    if-eqz v2, :cond_1

    new-instance v3, Landroid/content/ComponentName;

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v4

    invoke-static {p2}, Lcom/vbox/proxy/ProxyManifest;->TransparentProxyActivity(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_1
    new-instance v3, Landroid/content/ComponentName;

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v4

    invoke-static {p2}, Lcom/vbox/proxy/ProxyManifest;->getProxyActivity(I)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    invoke-virtual {v0, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const-string v3, "ActivityStack"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p4

    const-string v4, ", windowIsTranslucent: "

    invoke-virtual {p4, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p4

    invoke-virtual {p4, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-static {v3, p4}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    :cond_2
    new-instance p4, Ljava/lang/AssertionError;

    invoke-direct {p4}, Ljava/lang/AssertionError;-><init>()V

    throw p4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p4

    :try_start_1
    invoke-virtual {p4}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p4, Landroid/content/ComponentName;

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v2

    invoke-static {p2}, Lcom/vbox/proxy/ProxyManifest;->getProxyActivity(I)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p4, v2, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, p4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    if-eqz v1, :cond_3

    :goto_2
    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_3
    iget-object p2, p3, Lcom/vbox/proxy/record/ProxyActivityRecord;->mActivityInfo:Landroid/content/pm/ActivityInfo;

    iget-object p4, p3, Lcom/vbox/proxy/record/ProxyActivityRecord;->mActivityRecord:Ljava/lang/String;

    iget p3, p3, Lcom/vbox/proxy/record/ProxyActivityRecord;->mUserId:I

    invoke-static {v0, p1, p2, p4, p3}, Lcom/vbox/proxy/record/ProxyActivityRecord;->saveStub(Landroid/content/Intent;Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Ljava/lang/String;I)V

    return-object v0

    :catchall_1
    move-exception p1

    if-eqz v1, :cond_4

    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    :cond_4
    throw p1
.end method

.method private realStartActivityLocked(Landroid/os/IInterface;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I
    .registers 21

    and-int/lit8 v0, p7, -0x3

    and-int/lit8 v0, v0, -0x9

    and-int/lit8 v9, v0, -0x5

    :try_start_0
    invoke-static {}, Lblack/android/app/BRActivityManagerNative;->get()Lblack/android/app/ActivityManagerNativeStatic;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityManagerNativeStatic;->getDefault()Landroid/os/IInterface;

    move-result-object v0

    invoke-static {v0}, Lblack/android/app/BRIActivityManager;->get(Ljava/lang/Object;)Lblack/android/app/IActivityManagerContext;

    move-result-object v1

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    move-object v2, p1

    move-object v4, p2

    move-object v5, p3

    move-object/from16 v6, p4

    move-object/from16 v7, p5

    move/from16 v8, p6

    move-object/from16 v11, p8

    invoke-interface/range {v1 .. v11}, Lblack/android/app/IActivityManagerContext;->startActivity(Ljava/lang/Object;Ljava/lang/String;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILjava/lang/Object;Landroid/os/Bundle;)Ljava/lang/Integer;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v0, 0x0

    return v0
.end method

.method private startActivityInNewTaskLocked(ILandroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)I
    .registers 6

    invoke-virtual {p0, p2, p3, p4, p1}, Lcom/vbox/core/system/am/ActivityStack;->newActivityRecord(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p4

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/vbox/core/system/am/ActivityStack;->startActivityProcess(ILandroid/content/Intent;Landroid/content/pm/ActivityInfo;Lcom/vbox/core/system/am/ActivityRecord;)Landroid/content/Intent;

    move-result-object p1

    const/high16 p2, 0x8000000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 p2, 0x80000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/high16 p2, 0x10000000

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p1, p5}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 p1, 0x0

    return p1
.end method

.method private startActivityInSourceTask(Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;ILcom/vbox/core/system/am/ActivityRecord;Landroid/content/pm/ActivityInfo;I)I
    .registers 22

    move-object v9, p0

    move-object v0, p1

    move-object v4, p3

    move/from16 v1, p8

    move-object/from16 v2, p10

    invoke-virtual {p0, p1, v2, p3, v1}, Lcom/vbox/core/system/am/ActivityStack;->newActivityRecord(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v3

    invoke-direct {p0, v1, p1, v2, v3}, Lcom/vbox/core/system/am/ActivityStack;->startActivityProcess(ILandroid/content/Intent;Landroid/content/pm/ActivityInfo;Lcom/vbox/core/system/am/ActivityRecord;)Landroid/content/Intent;

    move-result-object v2

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move/from16 v0, p11

    invoke-virtual {v2, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    if-nez v4, :cond_0

    const/high16 v0, 0x10000000

    invoke-virtual {v2, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :cond_0
    move-object/from16 v0, p9

    iget-object v0, v0, Lcom/vbox/core/system/am/ActivityRecord;->processRecord:Lcom/vbox/core/system/ProcessRecord;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/ProcessRecord;

    iget-object v1, v0, Lcom/vbox/core/system/ProcessRecord;->appThread:Landroid/os/IInterface;

    move-object v0, p0

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move v6, p5

    move/from16 v7, p6

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lcom/vbox/core/system/am/ActivityStack;->realStartActivityLocked(Landroid/os/IInterface;Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I

    move-result v0

    return v0
.end method

.method private startActivityProcess(ILandroid/content/Intent;Landroid/content/pm/ActivityInfo;Lcom/vbox/core/system/am/ActivityRecord;)Landroid/content/Intent;
    .registers 12

    new-instance v0, Lcom/vbox/proxy/record/ProxyActivityRecord;

    iget-object p4, p4, Lcom/vbox/core/system/am/ActivityRecord;->mBToken:Ljava/lang/String;

    invoke-direct {v0, p1, p3, p2, p4}, Lcom/vbox/proxy/record/ProxyActivityRecord;-><init>(ILandroid/content/pm/ActivityInfo;Landroid/content/Intent;Ljava/lang/String;)V

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    iget-object v2, p3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v3, p3, Landroid/content/pm/ActivityInfo;->processName:Ljava/lang/String;

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v6

    const/4 v5, -0x1

    move v4, p1

    invoke-virtual/range {v1 .. v6}, Lcom/vbox/core/system/BProcessManagerService;->startProcessLocked(Ljava/lang/String;Ljava/lang/String;III)Lcom/vbox/core/system/ProcessRecord;

    move-result-object p1

    if-eqz p1, :cond_0

    iget p1, p1, Lcom/vbox/core/system/ProcessRecord;->bpid:I

    invoke-direct {p0, p2, p1, v0, p3}, Lcom/vbox/core/system/am/ActivityStack;->getStartStubActivityIntentInner(Landroid/content/Intent;ILcom/vbox/proxy/record/ProxyActivityRecord;Landroid/content/pm/ActivityInfo;)Landroid/content/Intent;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/RuntimeException;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p4, "Unable to create process, name:"

    invoke-direct {p2, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, p3, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private synchronizeTasks()V
    .registers 7

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mAms:Landroid/app/ActivityManager;

    const/16 v1, 0x64

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/app/ActivityManager;->getRecentTasks(II)Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/LinkedHashMap;

    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    :goto_0
    if-ltz v2, :cond_1

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/app/ActivityManager$RecentTaskInfo;

    iget-object v4, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    iget v5, v3, Landroid/app/ActivityManager$RecentTaskInfo;->id:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/vbox/core/system/am/TaskRecord;

    if-nez v4, :cond_0

    goto :goto_1

    :cond_0
    iget v3, v3, Landroid/app/ActivityManager$RecentTaskInfo;->id:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    add-int/lit8 v2, v2, -0x1

    goto :goto_0

    :cond_1
    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-interface {v0, v1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    return-void
.end method


# virtual methods
.method public containsFlag(Landroid/content/Intent;I)Z
    .registers 3

    invoke-virtual {p1}, Landroid/content/Intent;->getFlags()I

    move-result p1

    and-int/2addr p1, p2

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getCallingActivity(Landroid/os/IBinder;I)Landroid/content/ComponentName;
    .registers 5

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    invoke-direct {p0, p2, p1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->resultTo:Landroid/os/IBinder;

    invoke-direct {p0, p2, p1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    monitor-exit v0

    return-object p1

    :cond_0
    new-instance p1, Landroid/content/ComponentName;

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object p2

    const-class v1, Lcom/vbox/proxy/ProxyActivity$P0;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, p2, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    monitor-exit v0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getCallingPackage(Landroid/os/IBinder;I)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    invoke-direct {p0, p2, p1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->resultTo:Landroid/os/IBinder;

    invoke-direct {p0, p2, p1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->info:Landroid/content/pm/ActivityInfo;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/pm/ActivityInfo;

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    monitor-exit v0

    return-object p1

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object p1

    monitor-exit v0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public newActivityRecord(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)Lcom/vbox/core/system/am/ActivityRecord;
    .registers 7

    invoke-static {p1, p2, p3, p4}, Lcom/vbox/core/system/am/ActivityRecord;->create(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    monitor-enter p2

    :try_start_0
    iget-object p3, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    iget-object p4, p1, Lcom/vbox/core/system/am/ActivityRecord;->mBToken:Ljava/lang/String;

    invoke-interface {p3, p4, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p3, p0, Lcom/vbox/core/system/am/ActivityStack;->mHandler:Landroid/os/Handler;

    iget-object p4, p1, Lcom/vbox/core/system/am/ActivityRecord;->mBToken:Ljava/lang/String;

    const/4 v0, 0x0

    invoke-static {p3, v0, p4}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p3

    iget-object p4, p0, Lcom/vbox/core/system/am/ActivityStack;->mHandler:Landroid/os/Handler;

    const-wide/16 v0, 0x7d0

    invoke-virtual {p4, p3, v0, v1}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    monitor-exit p2

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onActivityCreated(Lcom/vbox/core/system/ProcessRecord;ILandroid/os/IBinder;Ljava/lang/String;)V
    .registers 10

    const-string v0, "onActivityCreated : "

    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    invoke-interface {v1, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/am/ActivityRecord;

    if-nez v1, :cond_0

    return-void

    :cond_0
    iget-object v2, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    monitor-enter v2

    :try_start_0
    iget-object v3, p0, Lcom/vbox/core/system/am/ActivityStack;->mLaunchingActivities:Ljava/util/Map;

    invoke-interface {v3, p4}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, p0, Lcom/vbox/core/system/am/ActivityStack;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x0

    invoke-virtual {v3, v4, p4}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    iget-object p4, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter p4

    :try_start_1
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    iget-object v2, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/core/system/am/TaskRecord;

    if-nez v2, :cond_1

    new-instance v2, Lcom/vbox/core/system/am/TaskRecord;

    iget v3, v1, Lcom/vbox/core/system/am/ActivityRecord;->userId:I

    iget-object v4, v1, Lcom/vbox/core/system/am/ActivityRecord;->info:Landroid/content/pm/ActivityInfo;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/pm/ActivityInfo;

    invoke-static {v4}, Lcom/vbox/utils/ComponentUtils;->getTaskAffinity(Landroid/content/pm/ActivityInfo;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, p2, v3, v4}, Lcom/vbox/core/system/am/TaskRecord;-><init>(IILjava/lang/String;)V

    iget-object v3, v1, Lcom/vbox/core/system/am/ActivityRecord;->intent:Landroid/content/Intent;

    iput-object v3, v2, Lcom/vbox/core/system/am/TaskRecord;->rootIntent:Landroid/content/Intent;

    iget-object v3, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    invoke-interface {v3, p2, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    iput-object p3, v1, Lcom/vbox/core/system/am/ActivityRecord;->token:Landroid/os/IBinder;

    iput-object p1, v1, Lcom/vbox/core/system/am/ActivityRecord;->processRecord:Lcom/vbox/core/system/ProcessRecord;

    iput-object v2, v1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-virtual {v2, v1}, Lcom/vbox/core/system/am/TaskRecord;->addTopActivity(Lcom/vbox/core/system/am/ActivityRecord;)V

    const-string p1, "ActivityStack"

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p3, v1, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    monitor-exit p4

    return-void

    :catchall_0
    move-exception p1

    monitor-exit p4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw p1

    :catchall_1
    move-exception p1

    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw p1
.end method

.method public onActivityDestroyed(ILandroid/os/IBinder;)V
    .registers 6

    const-string v0, "onActivityDestroyed : "

    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-nez p1, :cond_0

    monitor-exit v1

    return-void

    :cond_0
    const/4 p2, 0x1

    iput-boolean p2, p1, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    const-string p2, "ActivityStack"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, v0}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p2, p1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/core/system/am/TaskRecord;

    iget-object p2, p2, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    monitor-enter p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-virtual {v0, p1}, Lcom/vbox/core/system/am/TaskRecord;->removeActivity(Lcom/vbox/core/system/am/ActivityRecord;)V

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    return-void

    :catchall_0
    move-exception p1

    :try_start_3
    monitor-exit p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw p1

    :catchall_1
    move-exception p1

    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p1
.end method

.method public onActivityResumed(ILandroid/os/IBinder;)V
    .registers 6

    const-string v0, "onActivityResumed : "

    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-nez p1, :cond_0

    monitor-exit v1

    return-void

    :cond_0
    const-string p2, "ActivityStack"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p2, v0}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p2, p1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/core/system/am/TaskRecord;

    iget-object p2, p2, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    monitor-enter p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-virtual {v0, p1}, Lcom/vbox/core/system/am/TaskRecord;->removeActivity(Lcom/vbox/core/system/am/ActivityRecord;)V

    iget-object v0, p1, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-virtual {v0, p1}, Lcom/vbox/core/system/am/TaskRecord;->addTopActivity(Lcom/vbox/core/system/am/ActivityRecord;)V

    monitor-exit p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    return-void

    :catchall_0
    move-exception p1

    :try_start_3
    monitor-exit p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    throw p1

    :catchall_1
    move-exception p1

    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    throw p1
.end method

.method public onFinishActivity(ILandroid/os/IBinder;)V
    .registers 6

    const-string v0, "onFinishActivity : "

    iget-object v1, p0, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-direct {p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object p1

    if-nez p1, :cond_0

    monitor-exit v1

    return-void

    :cond_0
    const/4 p2, 0x1

    iput-boolean p2, p1, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    const-string p2, "ActivityStack"

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public startActivitiesLocked(I[Landroid/content/Intent;[Ljava/lang/String;Landroid/os/IBinder;Landroid/os/Bundle;)I
    .registers 20

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    if-eqz v0, :cond_3

    if-eqz v1, :cond_2

    array-length v2, v0

    array-length v3, v1

    if-ne v2, v3, :cond_1

    const/4 v2, 0x0

    move v3, v2

    :goto_0
    array-length v4, v0

    if-ge v3, v4, :cond_0

    aget-object v7, v0, v3

    aget-object v8, v1, v3

    const/4 v10, 0x0

    const/4 v11, -0x1

    const/4 v12, 0x0

    move-object v5, p0

    move v6, p1

    move-object/from16 v9, p4

    move-object/from16 v13, p5

    invoke-virtual/range {v5 .. v13}, Lcom/vbox/core/system/am/ActivityStack;->startActivityLocked(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return v2

    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "intents are length different than resolvedTypes"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_2
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "resolvedTypes is null"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "intents is null"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public startActivityLocked(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I
    .registers 29

    move-object/from16 v13, p0

    move/from16 v0, p1

    move-object/from16 v2, p2

    iget-object v1, v13, Lcom/vbox/core/system/am/ActivityStack;->mTasks:Ljava/util/Map;

    monitor-enter v1

    :try_start_0
    invoke-direct/range {p0 .. p0}, Lcom/vbox/core/system/am/ActivityStack;->synchronizeTasks()V

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v1

    const/4 v3, 0x1

    move-object/from16 v4, p3

    invoke-virtual {v1, v2, v3, v4, v0}, Lcom/vbox/core/system/pm/BPackageManagerService;->resolveActivity(Landroid/content/Intent;ILjava/lang/String;I)Landroid/content/pm/ResolveInfo;

    move-result-object v1

    const/4 v5, 0x0

    if-eqz v1, :cond_19

    iget-object v6, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    if-nez v6, :cond_0

    goto/16 :goto_11

    :cond_0
    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "startActivityLocked : "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v7, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string v7, "ActivityStack"

    invoke-static {v7, v6}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v11, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    move-object/from16 v1, p4

    invoke-direct {v13, v0, v1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByToken(ILandroid/os/IBinder;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v6

    if-nez v6, :cond_1

    const/4 v1, 0x0

    :cond_1
    if-eqz v6, :cond_2

    iget-object v6, v6, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    :goto_0
    invoke-static {v11}, Lcom/vbox/utils/ComponentUtils;->getTaskAffinity(Landroid/content/pm/ActivityInfo;)Ljava/lang/String;

    move-result-object v8

    const/high16 v9, 0x20000000

    invoke-virtual {v13, v2, v9}, Lcom/vbox/core/system/am/ActivityStack;->containsFlag(Landroid/content/Intent;I)Z

    move-result v9

    if-nez v9, :cond_4

    iget v9, v11, Landroid/content/pm/ActivityInfo;->launchMode:I

    if-ne v9, v3, :cond_3

    goto :goto_1

    :cond_3
    move v9, v5

    goto :goto_2

    :cond_4
    :goto_1
    move v9, v3

    :goto_2
    const/high16 v10, 0x10000000

    invoke-virtual {v13, v2, v10}, Lcom/vbox/core/system/am/ActivityStack;->containsFlag(Landroid/content/Intent;I)Z

    move-result v10

    const/high16 v14, 0x4000000

    invoke-virtual {v13, v2, v14}, Lcom/vbox/core/system/am/ActivityStack;->containsFlag(Landroid/content/Intent;I)Z

    move-result v14

    const v15, 0x8000

    invoke-virtual {v13, v2, v15}, Lcom/vbox/core/system/am/ActivityStack;->containsFlag(Landroid/content/Intent;I)Z

    move-result v15

    iget v7, v11, Landroid/content/pm/ActivityInfo;->launchMode:I

    packed-switch v7, :pswitch_data_0

    const/4 v7, 0x0

    goto :goto_3

    :pswitch_0
    invoke-direct {v13, v0, v8}, Lcom/vbox/core/system/am/ActivityStack;->findTaskRecordByTaskAffinityLocked(ILjava/lang/String;)Lcom/vbox/core/system/am/TaskRecord;

    move-result-object v7

    goto :goto_3

    :pswitch_1
    invoke-direct {v13, v0, v8}, Lcom/vbox/core/system/am/ActivityStack;->findTaskRecordByTaskAffinityLocked(ILjava/lang/String;)Lcom/vbox/core/system/am/TaskRecord;

    move-result-object v7

    if-nez v7, :cond_5

    if-nez v10, :cond_5

    move-object v7, v6

    :cond_5
    :goto_3
    if-eqz v7, :cond_18

    invoke-virtual {v7}, Lcom/vbox/core/system/am/TaskRecord;->needNewTask()Z

    move-result v8

    if-eqz v8, :cond_6

    goto/16 :goto_10

    :cond_6
    iget-object v8, v13, Lcom/vbox/core/system/am/ActivityStack;->mAms:Landroid/app/ActivityManager;

    iget v12, v7, Lcom/vbox/core/system/am/TaskRecord;->id:I

    invoke-virtual {v8, v12, v5}, Landroid/app/ActivityManager;->moveTaskToFront(II)V

    if-nez v14, :cond_8

    if-nez v9, :cond_8

    if-eqz v15, :cond_7

    goto :goto_4

    :cond_7
    move v8, v5

    goto :goto_5

    :cond_8
    :goto_4
    move v8, v3

    :goto_5
    if-nez v8, :cond_9

    iget-object v8, v7, Lcom/vbox/core/system/am/TaskRecord;->rootIntent:Landroid/content/Intent;

    invoke-static {v8, v2}, Lcom/vbox/utils/ComponentUtils;->intentFilterEquals(Landroid/content/Intent;Landroid/content/Intent;)Z

    move-result v8

    if-eqz v8, :cond_9

    iget-object v8, v7, Lcom/vbox/core/system/am/TaskRecord;->rootIntent:Landroid/content/Intent;

    invoke-virtual {v8}, Landroid/content/Intent;->getFlags()I

    move-result v8

    invoke-virtual/range {p2 .. p2}, Landroid/content/Intent;->getFlags()I

    move-result v12

    if-ne v8, v12, :cond_9

    move v8, v3

    goto :goto_6

    :cond_9
    move v8, v5

    :goto_6
    if-eqz v8, :cond_a

    return v5

    :cond_a
    invoke-virtual {v7}, Lcom/vbox/core/system/am/TaskRecord;->getTopActivityRecord()Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v12

    invoke-static {v11}, Lcom/vbox/utils/ComponentUtils;->toComponentName(Landroid/content/pm/ComponentInfo;)Landroid/content/ComponentName;

    move-result-object v8

    invoke-direct {v13, v0, v8}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByComponentName(ILandroid/content/ComponentName;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v8

    if-eqz v14, :cond_e

    if-eqz v8, :cond_e

    iget-object v5, v8, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/vbox/core/system/am/TaskRecord;

    iget-object v5, v5, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    monitor-enter v5

    :try_start_1
    iget-object v3, v8, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    iget-object v3, v3, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/16 v16, 0x1

    add-int/lit8 v3, v3, -0x1

    :goto_7
    if-ltz v3, :cond_d

    iget-object v4, v8, Lcom/vbox/core/system/am/ActivityRecord;->task:Lcom/vbox/core/system/am/TaskRecord;

    iget-object v4, v4, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/vbox/core/system/am/ActivityRecord;

    if-eq v4, v8, :cond_b

    move-object/from16 v17, v6

    const/4 v6, 0x1

    iput-boolean v6, v4, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    const-string v6, "ActivityStack"

    move-object/from16 v18, v1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v19, v10

    const-string v10, "makerFinish: "

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v4, v4, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v6, v1}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    add-int/lit8 v3, v3, -0x1

    move-object/from16 v4, p3

    move-object/from16 v6, v17

    move-object/from16 v1, v18

    move/from16 v10, v19

    goto :goto_7

    :cond_b
    move-object/from16 v18, v1

    move-object/from16 v17, v6

    move/from16 v19, v10

    if-eqz v9, :cond_c

    goto :goto_9

    :cond_c
    const/4 v1, 0x1

    iput-boolean v1, v8, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    goto :goto_8

    :cond_d
    move-object/from16 v18, v1

    move-object/from16 v17, v6

    move/from16 v19, v10

    :goto_8
    const/4 v8, 0x0

    :goto_9
    monitor-exit v5

    goto :goto_a

    :catchall_0
    move-exception v0

    monitor-exit v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0

    :cond_e
    move-object/from16 v18, v1

    move-object/from16 v17, v6

    move/from16 v19, v10

    const/4 v8, 0x0

    :goto_a
    if-eqz v9, :cond_f

    if-nez v14, :cond_f

    iget-object v1, v12, Lcom/vbox/core/system/am/ActivityRecord;->intent:Landroid/content/Intent;

    invoke-static {v1, v2}, Lcom/vbox/utils/ComponentUtils;->intentFilterEquals(Landroid/content/Intent;Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_f

    move-object v8, v12

    :cond_f
    iget v1, v11, Landroid/content/pm/ActivityInfo;->launchMode:I

    const/4 v3, 0x2

    if-ne v1, v3, :cond_12

    if-nez v14, :cond_12

    iget-object v1, v12, Lcom/vbox/core/system/am/ActivityRecord;->intent:Landroid/content/Intent;

    invoke-static {v1, v2}, Lcom/vbox/utils/ComponentUtils;->intentFilterEquals(Landroid/content/Intent;Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_10

    move-object v8, v12

    goto :goto_c

    :cond_10
    invoke-static {v11}, Lcom/vbox/utils/ComponentUtils;->toComponentName(Landroid/content/pm/ComponentInfo;)Landroid/content/ComponentName;

    move-result-object v1

    invoke-direct {v13, v0, v1}, Lcom/vbox/core/system/am/ActivityStack;->findActivityRecordByComponentName(ILandroid/content/ComponentName;)Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v1

    if-eqz v1, :cond_12

    iget-object v3, v7, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    monitor-enter v3

    :try_start_2
    iget-object v4, v7, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    :goto_b
    if-ltz v4, :cond_11

    iget-object v6, v7, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/vbox/core/system/am/ActivityRecord;

    if-eq v6, v1, :cond_11

    iput-boolean v5, v6, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    add-int/lit8 v4, v4, -0x1

    const/4 v5, 0x1

    goto :goto_b

    :cond_11
    monitor-exit v3

    move-object v8, v1

    goto :goto_c

    :catchall_1
    move-exception v0

    monitor-exit v3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw v0

    :cond_12
    :goto_c
    iget v1, v11, Landroid/content/pm/ActivityInfo;->launchMode:I

    const/4 v3, 0x3

    if-ne v1, v3, :cond_13

    move-object v8, v12

    :cond_13
    if-eqz v15, :cond_14

    if-eqz v19, :cond_14

    iget-object v1, v7, Lcom/vbox/core/system/am/TaskRecord;->activities:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_14

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/vbox/core/system/am/ActivityRecord;

    const/4 v4, 0x1

    iput-boolean v4, v3, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    goto :goto_d

    :cond_14
    invoke-direct/range {p0 .. p1}, Lcom/vbox/core/system/am/ActivityStack;->finishAllActivity(I)V

    if-eqz v8, :cond_15

    invoke-direct {v13, v8, v2}, Lcom/vbox/core/system/am/ActivityStack;->deliverNewIntentLocked(Lcom/vbox/core/system/am/ActivityRecord;Landroid/content/Intent;)V

    const/4 v0, 0x0

    return v0

    :cond_15
    if-nez v18, :cond_16

    invoke-virtual {v7}, Lcom/vbox/core/system/am/TaskRecord;->getTopActivityRecord()Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v1

    if-eqz v1, :cond_17

    goto :goto_e

    :cond_16
    if-eqz v17, :cond_17

    invoke-virtual/range {v17 .. v17}, Lcom/vbox/core/system/am/TaskRecord;->getTopActivityRecord()Lcom/vbox/core/system/am/ActivityRecord;

    move-result-object v1

    if-eqz v1, :cond_17

    :goto_e
    iget-object v1, v1, Lcom/vbox/core/system/am/ActivityRecord;->token:Landroid/os/IBinder;

    move-object v4, v1

    goto :goto_f

    :cond_17
    move-object/from16 v4, v18

    :goto_f
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move-object/from16 v8, p8

    move/from16 v9, p1

    move-object v10, v12

    const/4 v0, 0x0

    move v12, v0

    invoke-direct/range {v1 .. v12}, Lcom/vbox/core/system/am/ActivityStack;->startActivityInSourceTask(Landroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;ILcom/vbox/core/system/am/ActivityRecord;Landroid/content/pm/ActivityInfo;I)I

    move-result v0

    return v0

    :cond_18
    :goto_10
    move-object/from16 v18, v1

    const/4 v1, 0x0

    move-object/from16 p3, p0

    move/from16 p4, p1

    move-object/from16 p5, p2

    move-object/from16 p6, v11

    move-object/from16 p7, v18

    move/from16 p8, v1

    invoke-direct/range {p3 .. p8}, Lcom/vbox/core/system/am/ActivityStack;->startActivityInNewTaskLocked(ILandroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)I

    move-result v0

    return v0

    :cond_19
    :goto_11
    move v0, v5

    return v0

    :catchall_2
    move-exception v0

    :try_start_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
