.class public Lcom/vbox/core/system/am/BActivityManagerService;
.super Lcom/vbox/core/system/am/IBActivityManagerService$Stub;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/ISystemService;


# static fields
.field public static final TAG:Ljava/lang/String; = "BActivityManagerService"

.field private static final sService:Lcom/vbox/core/system/am/BActivityManagerService;


# instance fields
.field private final mBroadcastManager:Lcom/vbox/core/system/am/BroadcastManager;

.field private final mPms:Lcom/vbox/core/system/pm/BPackageManagerService;

.field private final mUserSpace:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lcom/vbox/core/system/am/UserSpace;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/core/system/am/BActivityManagerService;

    invoke-direct {v0}, Lcom/vbox/core/system/am/BActivityManagerService;-><init>()V

    sput-object v0, Lcom/vbox/core/system/am/BActivityManagerService;->sService:Lcom/vbox/core/system/am/BActivityManagerService;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lcom/vbox/core/system/am/IBActivityManagerService$Stub;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mUserSpace:Ljava/util/Map;

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v0

    iput-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mPms:Lcom/vbox/core/system/pm/BPackageManagerService;

    invoke-static {p0, v0}, Lcom/vbox/core/system/am/BroadcastManager;->startSystem(Lcom/vbox/core/system/am/BActivityManagerService;Lcom/vbox/core/system/pm/BPackageManagerService;)Lcom/vbox/core/system/am/BroadcastManager;

    move-result-object v0

    iput-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mBroadcastManager:Lcom/vbox/core/system/am/BroadcastManager;

    return-void
.end method

.method public static get()Lcom/vbox/core/system/am/BActivityManagerService;
    .registers 1

    sget-object v0, Lcom/vbox/core/system/am/BActivityManagerService;->sService:Lcom/vbox/core/system/am/BActivityManagerService;

    return-object v0
.end method

.method private getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;
    .registers 5

    iget-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mUserSpace:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mUserSpace:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/am/UserSpace;

    if-eqz v1, :cond_0

    monitor-exit v0

    return-object v1

    :cond_0
    new-instance v1, Lcom/vbox/core/system/am/UserSpace;

    invoke-direct {v1}, Lcom/vbox/core/system/am/UserSpace;-><init>()V

    iget-object v2, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mUserSpace:Ljava/util/Map;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-interface {v2, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0

    return-object v1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method


# virtual methods
.method public acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;
    .registers 9

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    iget-object v2, p1, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    iget-object v3, p1, Landroid/content/pm/ProviderInfo;->processName:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v4

    invoke-virtual {v4, v0}, Lcom/vbox/core/system/BProcessManagerService;->getUserIdByCallingPid(I)I

    move-result v4

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v6

    const/4 v5, -0x1

    invoke-virtual/range {v1 .. v6}, Lcom/vbox/core/system/BProcessManagerService;->startProcessLocked(Ljava/lang/String;Ljava/lang/String;III)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-eqz v0, :cond_0

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/ProcessRecord;->bActivityThread:Lcom/vbox/core/IBActivityThread;

    invoke-interface {v0, p1}, Lcom/vbox/core/IBActivityThread;->acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object p1

    :catchall_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1

    :cond_0
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to create process "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p1, p1, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public bindService(Landroid/content/Intent;Landroid/os/IBinder;Ljava/lang/String;I)Landroid/content/Intent;
    .registers 7

    invoke-direct {p0, p4}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/vbox/core/system/am/ActiveServices;->bindService(Landroid/content/Intent;Landroid/os/IBinder;Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public checkPermission(Ljava/lang/String;IILjava/lang/String;)I
    .registers 7

    const/4 p2, -0x1

    if-nez p1, :cond_0

    return p2

    :cond_0
    const-string v0, "android.permission.ACCOUNT_MANAGER"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    return v1

    :cond_1
    const-string v0, "android.permission.RECEIVE_BOOT_COMPLETED"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    return v1

    :cond_2
    const-string v0, "android.permission.BACKUP"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3

    return v1

    :cond_3
    const-string v0, "android.permission.INTERACT_ACROSS_USERS"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6

    const-string v0, "android.permission.INTERACT_ACROSS_USERS_FULL"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_4

    goto :goto_0

    :cond_4
    if-nez p3, :cond_5

    return v1

    :cond_5
    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object p2

    invoke-virtual {p2, p1, p3, p4}, Lcom/vbox/core/system/pm/BPackageManagerService;->checkUidPermission(Ljava/lang/String;ILjava/lang/String;)I

    move-result p1

    return p1

    :cond_6
    :goto_0
    return p2
.end method

.method public finishBroadcast(Lcom/vbox/entity/am/PendingResultData;)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mBroadcastManager:Lcom/vbox/core/system/am/BroadcastManager;

    invoke-virtual {v0, p1}, Lcom/vbox/core/system/am/BroadcastManager;->finishBroadcast(Lcom/vbox/entity/am/PendingResultData;)V

    return-void
.end method

.method public getCallingActivity(Landroid/os/IBinder;I)Landroid/content/ComponentName;
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActivityStack;->getCallingActivity(Landroid/os/IBinder;I)Landroid/content/ComponentName;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getCallingPackage(Landroid/os/IBinder;I)Ljava/lang/String;
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActivityStack;->getCallingPackage(Landroid/os/IBinder;I)Ljava/lang/String;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getIntentSender(Landroid/os/IBinder;Ljava/lang/String;II)V
    .registers 7

    invoke-direct {p0, p4}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object p4

    iget-object v0, p4, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    new-instance v1, Lcom/vbox/core/system/am/PendingIntentRecord;

    invoke-direct {v1}, Lcom/vbox/core/system/am/PendingIntentRecord;-><init>()V

    iput p3, v1, Lcom/vbox/core/system/am/PendingIntentRecord;->uid:I

    iput-object p2, v1, Lcom/vbox/core/system/am/PendingIntentRecord;->packageName:Ljava/lang/String;

    iget-object p2, p4, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    invoke-interface {p2, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getPackageForIntentSender(Landroid/os/IBinder;I)Ljava/lang/String;
    .registers 4

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object p2

    iget-object v0, p2, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    iget-object p2, p2, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/core/system/am/PendingIntentRecord;

    if-eqz p1, :cond_0

    iget-object p1, p1, Lcom/vbox/core/system/am/PendingIntentRecord;->packageName:Ljava/lang/String;

    monitor-exit v0

    return-object p1

    :cond_0
    monitor-exit v0

    const/4 p1, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getRunningAppProcesses(Ljava/lang/String;I)Lcom/vbox/entity/am/RunningAppProcessInfo;
    .registers 7

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "activity"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/ActivityManager;

    invoke-virtual {v0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object v0

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget v3, v2, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/BProcessManagerService;->getPackageProcessAsUser(Ljava/lang/String;I)Ljava/util/List;

    move-result-object p1

    new-instance p2, Lcom/vbox/entity/am/RunningAppProcessInfo;

    invoke-direct {p2}, Lcom/vbox/entity/am/RunningAppProcessInfo;-><init>()V

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_1
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/ProcessRecord;

    iget v2, v0, Lcom/vbox/core/system/ProcessRecord;->pid:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/ActivityManager$RunningAppProcessInfo;

    if-eqz v2, :cond_1

    iget-object v0, v0, Lcom/vbox/core/system/ProcessRecord;->processName:Ljava/lang/String;

    iput-object v0, v2, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    iget-object v0, p2, Lcom/vbox/entity/am/RunningAppProcessInfo;->mAppProcessInfoList:Ljava/util/List;

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_2
    return-object p2
.end method

.method public getRunningServices(Ljava/lang/String;I)Lcom/vbox/entity/am/RunningServiceInfo;
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActiveServices;->getRunningServiceInfo(Ljava/lang/String;I)Lcom/vbox/entity/am/RunningServiceInfo;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public getUidForIntentSender(Landroid/os/IBinder;I)I
    .registers 4

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object p2

    iget-object v0, p2, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    monitor-enter v0

    :try_start_0
    iget-object p2, p2, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/core/system/am/PendingIntentRecord;

    if-eqz p1, :cond_0

    iget p1, p1, Lcom/vbox/core/system/am/PendingIntentRecord;->uid:I

    monitor-exit v0

    return p1

    :cond_0
    monitor-exit v0

    const/4 p1, -0x1

    return p1

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public initProcess(Ljava/lang/String;Ljava/lang/String;I)Lcom/vbox/entity/AppConfig;
    .registers 10

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v0

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v5

    const/4 v4, -0x1

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    invoke-virtual/range {v0 .. v5}, Lcom/vbox/core/system/BProcessManagerService;->startProcessLocked(Ljava/lang/String;Ljava/lang/String;III)Lcom/vbox/core/system/ProcessRecord;

    move-result-object p1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    invoke-virtual {p1}, Lcom/vbox/core/system/ProcessRecord;->getClientConfig()Lcom/vbox/entity/AppConfig;

    move-result-object p1

    return-object p1
.end method

.method public onActivityCreated(ILandroid/os/IBinder;Ljava/lang/String;)V
    .registers 7

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/core/system/BProcessManagerService;->findProcessByPid(I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v1, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-direct {p0, v1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v1

    iget-object v2, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v2

    :try_start_0
    iget-object v1, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    invoke-virtual {v1, v0, p1, p2, p3}, Lcom/vbox/core/system/am/ActivityStack;->onActivityCreated(Lcom/vbox/core/system/ProcessRecord;ILandroid/os/IBinder;Ljava/lang/String;)V

    monitor-exit v2

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onActivityDestroyed(Landroid/os/IBinder;)V
    .registers 5

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/core/system/BProcessManagerService;->findProcessByPid(I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v1, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-direct {p0, v1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v1

    iget-object v2, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v2

    :try_start_0
    iget-object v1, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    iget v0, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-virtual {v1, v0, p1}, Lcom/vbox/core/system/am/ActivityStack;->onActivityDestroyed(ILandroid/os/IBinder;)V

    monitor-exit v2

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onActivityResumed(Landroid/os/IBinder;)V
    .registers 5

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/core/system/BProcessManagerService;->findProcessByPid(I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v1, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-direct {p0, v1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v1

    iget-object v2, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v2

    :try_start_0
    iget-object v1, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    iget v0, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-virtual {v1, v0, p1}, Lcom/vbox/core/system/am/ActivityStack;->onActivityResumed(ILandroid/os/IBinder;)V

    monitor-exit v2

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onFinishActivity(Landroid/os/IBinder;)V
    .registers 5

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/core/system/BProcessManagerService;->findProcessByPid(I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    iget v1, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-direct {p0, v1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v1

    iget-object v2, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v2

    :try_start_0
    iget-object v1, v1, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    iget v0, v0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-virtual {v1, v0, p1}, Lcom/vbox/core/system/am/ActivityStack;->onFinishActivity(ILandroid/os/IBinder;)V

    monitor-exit v2

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onServiceDestroy(Landroid/content/Intent;I)V
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActiveServices;->onServiceDestroy(Landroid/content/Intent;I)V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onServiceUnbind(Landroid/content/Intent;I)Lcom/vbox/entity/UnbindRecord;
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActiveServices;->onServiceUnbind(Landroid/content/Intent;I)Lcom/vbox/entity/UnbindRecord;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public onStartCommand(Landroid/content/Intent;I)V
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActiveServices;->onStartCommand(Landroid/content/Intent;I)V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public peekService(Landroid/content/Intent;Ljava/lang/String;I)Landroid/os/IBinder;
    .registers 6

    invoke-direct {p0, p3}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2, p3}, Lcom/vbox/core/system/am/ActiveServices;->peekService(Landroid/content/Intent;Ljava/lang/String;I)Landroid/os/IBinder;

    move-result-object p1

    monitor-exit v1

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public restartProcess(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 5

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v0

    invoke-virtual {v0, p1, p2, p3}, Lcom/vbox/core/system/BProcessManagerService;->restartAppProcess(Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method

.method public scheduleBroadcastReceiver(Landroid/content/Intent;Lcom/vbox/entity/am/PendingResultData;I)V
    .registers 9

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v0

    const/16 v1, 0x80

    const/4 v2, 0x0

    invoke-virtual {v0, p1, v1, v2, p3}, Lcom/vbox/core/system/pm/BPackageManagerService;->queryBroadcastReceivers(Landroid/content/Intent;ILjava/lang/String;I)Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {p2}, Lcom/vbox/entity/am/PendingResultData;->build()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    const-string p1, "BActivityManagerService"

    const-string p2, "scheduleBroadcastReceiver empty"

    invoke-static {p1, p2}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-object v1, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mBroadcastManager:Lcom/vbox/core/system/am/BroadcastManager;

    invoke-virtual {v1, p2}, Lcom/vbox/core/system/am/BroadcastManager;->sendBroadcast(Lcom/vbox/entity/am/PendingResultData;)V

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/content/pm/ResolveInfo;

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v2

    iget-object v3, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v4, v3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->processName:Ljava/lang/String;

    invoke-virtual {v2, v4, v3, p3}, Lcom/vbox/core/system/BProcessManagerService;->findProcessRecord(Ljava/lang/String;Ljava/lang/String;I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v2

    if-eqz v2, :cond_1

    new-instance v3, Lcom/vbox/entity/am/ReceiverData;

    invoke-direct {v3}, Lcom/vbox/entity/am/ReceiverData;-><init>()V

    iput-object p1, v3, Lcom/vbox/entity/am/ReceiverData;->intent:Landroid/content/Intent;

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iput-object v1, v3, Lcom/vbox/entity/am/ReceiverData;->activityInfo:Landroid/content/pm/ActivityInfo;

    iput-object p2, v3, Lcom/vbox/entity/am/ReceiverData;->data:Lcom/vbox/entity/am/PendingResultData;

    iget-object v1, v2, Lcom/vbox/core/system/ProcessRecord;->bActivityThread:Lcom/vbox/core/IBActivityThread;

    invoke-interface {v1, v3}, Lcom/vbox/core/IBActivityThread;->scheduleReceiver(Lcom/vbox/entity/am/ReceiverData;)V

    goto :goto_0

    :cond_2
    return-void
.end method

.method public sendBroadcast(Landroid/content/Intent;Ljava/lang/String;I)Landroid/content/Intent;
    .registers 7

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v0

    const/16 v1, 0x80

    invoke-virtual {v0, p1, v1, p2, p3}, Lcom/vbox/core/system/pm/BPackageManagerService;->queryBroadcastReceivers(Landroid/content/Intent;ILjava/lang/String;I)Ljava/util/List;

    move-result-object p2

    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/pm/ResolveInfo;

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, v0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v0, v0, Landroid/content/pm/ActivityInfo;->processName:Ljava/lang/String;

    invoke-virtual {v1, v2, v0, p3}, Lcom/vbox/core/system/BProcessManagerService;->findProcessRecord(Ljava/lang/String;Ljava/lang/String;I)Lcom/vbox/core/system/ProcessRecord;

    move-result-object v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/ProcessRecord;->bActivityThread:Lcom/vbox/core/IBActivityThread;

    invoke-interface {v0}, Lcom/vbox/core/IBActivityThread;->bindApplication()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_0

    :cond_1
    new-instance p2, Landroid/content/Intent;

    invoke-direct {p2}, Landroid/content/Intent;-><init>()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {p2, p3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 p3, 0x0

    invoke-virtual {p2, p3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    return-object p2
.end method

.method public startActivities(I[Landroid/content/Intent;[Ljava/lang/String;Landroid/os/IBinder;Landroid/os/Bundle;)I
    .registers 14

    invoke-direct {p0, p1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v1

    :try_start_0
    iget-object v2, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    move v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    move-object v7, p5

    invoke-virtual/range {v2 .. v7}, Lcom/vbox/core/system/am/ActivityStack;->startActivitiesLocked(I[Landroid/content/Intent;[Ljava/lang/String;Landroid/os/IBinder;Landroid/os/Bundle;)I

    move-result p1

    monitor-exit v1

    return p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public startActivity(Landroid/content/Intent;I)V
    .registers 14

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v1

    :try_start_0
    iget-object v2, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, -0x1

    const/4 v9, -0x1

    const/4 v10, 0x0

    move v3, p2

    move-object v4, p1

    invoke-virtual/range {v2 .. v10}, Lcom/vbox/core/system/am/ActivityStack;->startActivityLocked(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public startActivityAms(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I
    .registers 20

    invoke-direct {p0, p1}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    monitor-enter v1

    :try_start_0
    iget-object v2, v0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    move v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    move-object/from16 v7, p5

    move/from16 v8, p6

    move/from16 v9, p7

    move-object/from16 v10, p8

    invoke-virtual/range {v2 .. v10}, Lcom/vbox/core/system/am/ActivityStack;->startActivityLocked(ILandroid/content/Intent;Ljava/lang/String;Landroid/os/IBinder;Ljava/lang/String;IILandroid/os/Bundle;)I

    move-result v0

    monitor-exit v1

    return v0

    :catchall_0
    move-exception v0

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public startService(Landroid/content/Intent;Ljava/lang/String;ZI)Landroid/content/ComponentName;
    .registers 7

    invoke-direct {p0, p4}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/vbox/core/system/am/ActiveServices;->startService(Landroid/content/Intent;Ljava/lang/String;ZI)V

    monitor-exit v1

    const/4 p1, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public stopService(Landroid/content/Intent;Ljava/lang/String;I)I
    .registers 6

    invoke-direct {p0, p3}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2, p3}, Lcom/vbox/core/system/am/ActiveServices;->stopService(Landroid/content/Intent;Ljava/lang/String;I)I

    move-result p1

    monitor-exit v1

    return p1

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public stopServiceToken(Landroid/content/ComponentName;Landroid/os/IBinder;I)V
    .registers 6

    invoke-direct {p0, p3}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2, p3}, Lcom/vbox/core/system/am/ActiveServices;->stopServiceToken(Landroid/content/ComponentName;Landroid/os/IBinder;I)V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public systemReady()V
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/am/BActivityManagerService;->mBroadcastManager:Lcom/vbox/core/system/am/BroadcastManager;

    invoke-virtual {v0}, Lcom/vbox/core/system/am/BroadcastManager;->startup()V

    return-void
.end method

.method public unbindService(Landroid/os/IBinder;I)V
    .registers 5

    invoke-direct {p0, p2}, Lcom/vbox/core/system/am/BActivityManagerService;->getOrCreateSpaceLocked(I)Lcom/vbox/core/system/am/UserSpace;

    move-result-object v0

    iget-object v1, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    invoke-virtual {v0, p1, p2}, Lcom/vbox/core/system/am/ActiveServices;->unbindService(Landroid/os/IBinder;I)V

    monitor-exit v1

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method
