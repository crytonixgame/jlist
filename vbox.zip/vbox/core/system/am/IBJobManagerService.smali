.class public interface abstract Lcom/vbox/core/system/am/IBJobManagerService;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/am/IBJobManagerService$_Parcel;,
        Lcom/vbox/core/system/am/IBJobManagerService$Stub;,
        Lcom/vbox/core/system/am/IBJobManagerService$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.system.am.IBJobManagerService"


# virtual methods
.method public abstract cancel(Ljava/lang/String;II)I
.end method

.method public abstract cancelAll(Ljava/lang/String;I)V
.end method

.method public abstract queryJobRecord(Ljava/lang/String;II)Lcom/vbox/entity/JobRecord;
.end method

.method public abstract schedule(Landroid/app/job/JobInfo;I)Landroid/app/job/JobInfo;
.end method
