.class public Lcom/vbox/core/system/am/UserSpace;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

.field public final mIntentSenderRecords:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/os/IBinder;",
            "Lcom/vbox/core/system/am/PendingIntentRecord;",
            ">;"
        }
    .end annotation
.end field

.field public final mStack:Lcom/vbox/core/system/am/ActivityStack;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/vbox/core/system/am/ActiveServices;

    invoke-direct {v0}, Lcom/vbox/core/system/am/ActiveServices;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/UserSpace;->mActiveServices:Lcom/vbox/core/system/am/ActiveServices;

    new-instance v0, Lcom/vbox/core/system/am/ActivityStack;

    invoke-direct {v0}, Lcom/vbox/core/system/am/ActivityStack;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/UserSpace;->mStack:Lcom/vbox/core/system/am/ActivityStack;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/am/UserSpace;->mIntentSenderRecords:Ljava/util/Map;

    return-void
.end method
