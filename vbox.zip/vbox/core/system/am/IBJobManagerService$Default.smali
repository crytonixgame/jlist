.class public Lcom/vbox/core/system/am/IBJobManagerService$Default;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/am/IBJobManagerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/am/IBJobManagerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public cancel(Ljava/lang/String;II)I
    .registers 4

    const/4 p1, 0x0

    return p1
.end method

.method public cancelAll(Ljava/lang/String;I)V
    .registers 3

    return-void
.end method

.method public queryJobRecord(Ljava/lang/String;II)Lcom/vbox/entity/JobRecord;
    .registers 4

    const/4 p1, 0x0

    return-object p1
.end method

.method public schedule(Landroid/app/job/JobInfo;I)Landroid/app/job/JobInfo;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method
