.class public Lcom/vbox/core/system/am/ActivityRecord;
.super Landroid/os/Binder;
.source "SourceFile"


# instance fields
.field public component:Landroid/content/ComponentName;

.field public finished:Z

.field public info:Landroid/content/pm/ActivityInfo;

.field public intent:Landroid/content/Intent;

.field public mBToken:Ljava/lang/String;

.field public processRecord:Lcom/vbox/core/system/ProcessRecord;

.field public resultTo:Landroid/os/IBinder;

.field public task:Lcom/vbox/core/system/am/TaskRecord;

.field public token:Landroid/os/IBinder;

.field public userId:I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/vbox/core/system/am/ActivityRecord;->finished:Z

    return-void
.end method

.method public static create(Landroid/content/Intent;Landroid/content/pm/ActivityInfo;Landroid/os/IBinder;I)Lcom/vbox/core/system/am/ActivityRecord;
    .registers 6

    new-instance v0, Lcom/vbox/core/system/am/ActivityRecord;

    invoke-direct {v0}, Lcom/vbox/core/system/am/ActivityRecord;-><init>()V

    iput-object p0, v0, Lcom/vbox/core/system/am/ActivityRecord;->intent:Landroid/content/Intent;

    iput-object p1, v0, Lcom/vbox/core/system/am/ActivityRecord;->info:Landroid/content/pm/ActivityInfo;

    new-instance p0, Landroid/content/ComponentName;

    iget-object v1, p1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {p0, v1, p1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    iput-object p0, v0, Lcom/vbox/core/system/am/ActivityRecord;->component:Landroid/content/ComponentName;

    iput-object p2, v0, Lcom/vbox/core/system/am/ActivityRecord;->resultTo:Landroid/os/IBinder;

    iput p3, v0, Lcom/vbox/core/system/am/ActivityRecord;->userId:I

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p0

    iput-object p0, v0, Lcom/vbox/core/system/am/ActivityRecord;->mBToken:Ljava/lang/String;

    return-object v0
.end method
