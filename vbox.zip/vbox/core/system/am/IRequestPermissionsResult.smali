.class public interface abstract Lcom/vbox/core/system/am/IRequestPermissionsResult;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/am/IRequestPermissionsResult$Stub;,
        Lcom/vbox/core/system/am/IRequestPermissionsResult$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.system.am.IRequestPermissionsResult"


# virtual methods
.method public abstract onResult(I[Ljava/lang/String;[I)Z
.end method
