.class public interface abstract Lcom/vbox/core/system/ISystemService;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract systemReady()V
.end method
