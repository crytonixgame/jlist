.class public Lcom/vbox/core/system/user/IBUserManagerService$Default;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/user/IBUserManagerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/user/IBUserManagerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public createUser(I)Lcom/vbox/core/system/user/BUserInfo;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public deleteUser(I)V
    .registers 2

    return-void
.end method

.method public exists(I)Z
    .registers 2

    const/4 p1, 0x0

    return p1
.end method

.method public getUserInfo(I)Lcom/vbox/core/system/user/BUserInfo;
    .registers 2

    const/4 p1, 0x0

    return-object p1
.end method

.method public getUsers()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/core/system/user/BUserInfo;",
            ">;"
        }
    .end annotation

    const/4 v0, 0x0

    return-object v0
.end method
