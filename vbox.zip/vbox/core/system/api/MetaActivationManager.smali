.class public Lcom/vbox/core/system/api/MetaActivationManager;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static activateSdk(Ljava/lang/String;)V
    .registers 2

    :try_start_0
    invoke-static {}, Landroid/MetaCore/RemoteControl;->getInstance()Landroid/MetaCore/RemoteControl;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/MetaCore/RemoteControl;->activateSdk(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method
