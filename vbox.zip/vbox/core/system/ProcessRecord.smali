.class public Lcom/vbox/core/system/ProcessRecord;
.super Landroid/os/Binder;
.source "SourceFile"


# instance fields
.field public appThread:Landroid/os/IInterface;

.field public bActivityThread:Lcom/vbox/core/IBActivityThread;

.field public bpid:I

.field public buid:I

.field public callingBUid:I

.field public final info:Landroid/content/pm/ApplicationInfo;

.field public initLock:Landroid/os/ConditionVariable;

.field public pid:I

.field public final processName:Ljava/lang/String;

.field public uid:I

.field public userId:I


# direct methods
.method public constructor <init>(Landroid/content/pm/ApplicationInfo;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    new-instance v0, Landroid/os/ConditionVariable;

    invoke-direct {v0}, Landroid/os/ConditionVariable;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/ProcessRecord;->initLock:Landroid/os/ConditionVariable;

    iput-object p1, p0, Lcom/vbox/core/system/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iput-object p2, p0, Lcom/vbox/core/system/ProcessRecord;->processName:Ljava/lang/String;

    return-void
.end method

.method private handleErrno(Landroid/system/ErrnoException;)V
    .registers 4

    iget v0, p1, Landroid/system/ErrnoException;->errno:I

    sget v1, Landroid/system/OsConstants;->ENOENT:I

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/system/ErrnoException;->printStackTrace()V

    :goto_0
    return-void
.end method


# virtual methods
.method public getCallingBUid()I
    .registers 2

    iget v0, p0, Lcom/vbox/core/system/ProcessRecord;->callingBUid:I

    return v0
.end method

.method public getClientConfig()Lcom/vbox/entity/AppConfig;
    .registers 3

    new-instance v0, Lcom/vbox/entity/AppConfig;

    invoke-direct {v0}, Lcom/vbox/entity/AppConfig;-><init>()V

    iget-object v1, p0, Lcom/vbox/core/system/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iput-object v1, v0, Lcom/vbox/entity/AppConfig;->packageName:Ljava/lang/String;

    iget-object v1, p0, Lcom/vbox/core/system/ProcessRecord;->processName:Ljava/lang/String;

    iput-object v1, v0, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->bpid:I

    iput v1, v0, Lcom/vbox/entity/AppConfig;->bpid:I

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->buid:I

    iput v1, v0, Lcom/vbox/entity/AppConfig;->buid:I

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->uid:I

    iput v1, v0, Lcom/vbox/entity/AppConfig;->uid:I

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->callingBUid:I

    iput v1, v0, Lcom/vbox/entity/AppConfig;->callingBUid:I

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    iput v1, v0, Lcom/vbox/entity/AppConfig;->userId:I

    iput-object p0, v0, Lcom/vbox/entity/AppConfig;->token:Landroid/os/IBinder;

    return-object v0
.end method

.method public getPackageName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/ProcessRecord;->info:Landroid/content/pm/ApplicationInfo;

    iget-object v0, v0, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    return-object v0
.end method

.method public getProviderAuthority()Ljava/lang/String;
    .registers 2

    iget v0, p0, Lcom/vbox/core/system/ProcessRecord;->bpid:I

    invoke-static {v0}, Lcom/vbox/proxy/ProxyManifest;->getProxyAuthorities(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public hashCode()I
    .registers 8

    iget-object v0, p0, Lcom/vbox/core/system/ProcessRecord;->processName:Ljava/lang/String;

    iget v1, p0, Lcom/vbox/core/system/ProcessRecord;->pid:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iget v2, p0, Lcom/vbox/core/system/ProcessRecord;->buid:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iget v3, p0, Lcom/vbox/core/system/ProcessRecord;->bpid:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget v4, p0, Lcom/vbox/core/system/ProcessRecord;->uid:I

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget v5, p0, Lcom/vbox/core/system/ProcessRecord;->pid:I

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget v6, p0, Lcom/vbox/core/system/ProcessRecord;->userId:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method public kill()V
    .registers 2

    iget v0, p0, Lcom/vbox/core/system/ProcessRecord;->pid:I

    if-lez v0, :cond_0

    :try_start_0
    invoke-static {v0}, Landroid/os/Process;->killProcess(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    return-void
.end method
