.class public Lcom/vbox/core/system/VBoxSystem;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/VBoxSystem$VBoxSystemHolder;
    }
.end annotation


# static fields
.field private static final isStartup:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static sVBoxSystem:Lcom/vbox/core/system/VBoxSystem;


# instance fields
.field private final mServices:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/vbox/core/system/ISystemService;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    sput-object v0, Lcom/vbox/core/system/VBoxSystem;->isStartup:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    return-void
.end method

.method public static getSystem()Lcom/vbox/core/system/VBoxSystem;
    .registers 1

    sget-object v0, Lcom/vbox/core/system/VBoxSystem$VBoxSystemHolder;->VBoxSystem:Lcom/vbox/core/system/VBoxSystem;

    return-object v0
.end method


# virtual methods
.method public startup()V
    .registers 6

    sget-object v0, Lcom/vbox/core/system/VBoxSystem;->isStartup:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    if-nez v0, :cond_2

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->load()V

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/user/BUserManagerService;->get()Lcom/vbox/core/system/user/BUserManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/am/BActivityManagerService;->get()Lcom/vbox/core/system/am/BActivityManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/am/BJobManagerService;->get()Lcom/vbox/core/system/am/BJobManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/os/BStorageManagerService;->get()Lcom/vbox/core/system/os/BStorageManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageInstallerService;->get()Lcom/vbox/core/system/pm/BPackageInstallerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/pm/BXposedManagerService;->get()Lcom/vbox/core/system/pm/BXposedManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/BProcessManagerService;->get()Lcom/vbox/core/system/BProcessManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/accounts/BAccountManagerService;->get()Lcom/vbox/core/system/accounts/BAccountManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/location/BLocationManagerService;->get()Lcom/vbox/core/system/location/BLocationManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-static {}, Lcom/vbox/core/system/notification/BNotificationManagerService;->get()Lcom/vbox/core/system/notification/BNotificationManagerService;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v0, p0, Lcom/vbox/core/system/VBoxSystem;->mServices:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/core/system/ISystemService;

    invoke-interface {v1}, Lcom/vbox/core/system/ISystemService;->systemReady()V

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/core/env/AppSystemEnv;->getPreInstallPackages()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_1
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    :try_start_0
    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v2

    const/4 v3, -0x1

    invoke-virtual {v2, v1, v3}, Lcom/vbox/core/system/pm/BPackageManagerService;->isInstalled(Ljava/lang/String;I)Z

    move-result v2

    if-nez v2, :cond_1

    invoke-static {}, Lcom/vbox/VBoxCore;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v4, 0x0

    invoke-virtual {v2, v1, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v1

    invoke-static {}, Lcom/vbox/core/system/pm/BPackageManagerService;->get()Lcom/vbox/core/system/pm/BPackageManagerService;

    move-result-object v2

    iget-object v1, v1, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installBySystem()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v4

    invoke-virtual {v2, v1, v4, v3}, Lcom/vbox/core/system/pm/BPackageManagerService;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v1

    goto :goto_1

    :cond_2
    return-void
.end method
