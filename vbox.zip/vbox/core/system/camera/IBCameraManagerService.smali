.class public interface abstract Lcom/vbox/core/system/camera/IBCameraManagerService;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/camera/IBCameraManagerService$_Parcel;,
        Lcom/vbox/core/system/camera/IBCameraManagerService$Stub;,
        Lcom/vbox/core/system/camera/IBCameraManagerService$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.system.camera.IBCameraManagerService"


# virtual methods
.method public abstract getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;
.end method

.method public abstract getCameraMethod(ILjava/lang/String;)I
.end method

.method public abstract getCameraVideo(ILjava/lang/String;)Ljava/lang/String;
.end method

.method public abstract getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;
.end method

.method public abstract getGlobalCameraMethod()I
.end method

.method public abstract getGlobalCameraVideo()Ljava/lang/String;
.end method

.method public abstract isAudioEnabled(ILjava/lang/String;)Z
.end method

.method public abstract isGlobalAudioEnabled()Z
.end method

.method public abstract setAudioEnabled(ILjava/lang/String;Z)V
.end method

.method public abstract setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V
.end method

.method public abstract setCameraMethod(ILjava/lang/String;I)V
.end method

.method public abstract setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract setGlobalAudioEnabled(Z)V
.end method

.method public abstract setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V
.end method

.method public abstract setGlobalCameraMethod(I)V
.end method

.method public abstract setGlobalCameraVideo(Ljava/lang/String;)V
.end method
