.class public abstract Lcom/vbox/core/system/camera/IBCameraManagerService$Stub;
.super Landroid/os/Binder;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/camera/IBCameraManagerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/camera/IBCameraManagerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/system/camera/IBCameraManagerService$Stub$Proxy;
    }
.end annotation


# static fields
.field static final TRANSACTION_getCameraConfig:I = 0x8

.field static final TRANSACTION_getCameraMethod:I = 0x2

.field static final TRANSACTION_getCameraVideo:I = 0x4

.field static final TRANSACTION_getGlobalCameraConfig:I = 0x10

.field static final TRANSACTION_getGlobalCameraMethod:I = 0xa

.field static final TRANSACTION_getGlobalCameraVideo:I = 0xc

.field static final TRANSACTION_isAudioEnabled:I = 0x6

.field static final TRANSACTION_isGlobalAudioEnabled:I = 0xe

.field static final TRANSACTION_setAudioEnabled:I = 0x5

.field static final TRANSACTION_setCameraConfig:I = 0x7

.field static final TRANSACTION_setCameraMethod:I = 0x1

.field static final TRANSACTION_setCameraVideo:I = 0x3

.field static final TRANSACTION_setGlobalAudioEnabled:I = 0xd

.field static final TRANSACTION_setGlobalCameraConfig:I = 0xf

.field static final TRANSACTION_setGlobalCameraMethod:I = 0x9

.field static final TRANSACTION_setGlobalCameraVideo:I = 0xb


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const-string v0, "com.vbox.core.system.camera.IBCameraManagerService"

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/vbox/core/system/camera/IBCameraManagerService;
    .registers 3

    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    const-string v0, "com.vbox.core.system.camera.IBCameraManagerService"

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    if-eqz v0, :cond_1

    instance-of v1, v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    if-eqz v1, :cond_1

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    return-object v0

    :cond_1
    new-instance v0, Lcom/vbox/core/system/camera/IBCameraManagerService$Stub$Proxy;

    invoke-direct {v0, p0}, Lcom/vbox/core/system/camera/IBCameraManagerService$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 1

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .registers 8

    const-string v0, "com.vbox.core.system.camera.IBCameraManagerService"

    const/4 v1, 0x1

    if-lt p1, v1, :cond_0

    const v2, 0xffffff

    if-gt p1, v2, :cond_0

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    :cond_0
    const v2, 0x5f4e5446

    if-ne p1, v2, :cond_1

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    return v1

    :cond_1
    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    return p1

    :pswitch_0
    invoke-interface {p0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;

    move-result-object p1

    goto :goto_0

    :pswitch_1
    sget-object p1, Lcom/vbox/entity/camera/BCameraConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p2, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService$_Parcel;->access$000(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-interface {p0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V

    goto/16 :goto_3

    :pswitch_2
    invoke-interface {p0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->isGlobalAudioEnabled()Z

    move-result p1

    goto/16 :goto_2

    :pswitch_3
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    if-eqz p1, :cond_2

    move v0, v1

    :cond_2
    invoke-interface {p0, v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalAudioEnabled(Z)V

    goto/16 :goto_3

    :pswitch_4
    invoke-interface {p0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraVideo()Ljava/lang/String;

    move-result-object p1

    goto :goto_1

    :pswitch_5
    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    invoke-interface {p0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraVideo(Ljava/lang/String;)V

    goto/16 :goto_3

    :pswitch_6
    invoke-interface {p0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraMethod()I

    move-result p1

    goto/16 :goto_2

    :pswitch_7
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-interface {p0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraMethod(I)V

    goto/16 :goto_3

    :pswitch_8
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;

    move-result-object p1

    :goto_0
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-static {p3, p1, v1}, Lcom/vbox/core/system/camera/IBCameraManagerService$_Parcel;->access$100(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    goto/16 :goto_4

    :pswitch_9
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p4

    sget-object v0, Lcom/vbox/entity/camera/BCameraConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p2, v0}, Lcom/vbox/core/system/camera/IBCameraManagerService$_Parcel;->access$000(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-interface {p0, p1, p4, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V

    goto :goto_3

    :pswitch_a
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->isAudioEnabled(ILjava/lang/String;)Z

    move-result p1

    goto :goto_2

    :pswitch_b
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    if-eqz p2, :cond_3

    move v0, v1

    :cond_3
    invoke-interface {p0, p1, p4, v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setAudioEnabled(ILjava/lang/String;Z)V

    goto :goto_3

    :pswitch_c
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraVideo(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :goto_1
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    goto :goto_4

    :pswitch_d
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p4, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :pswitch_e
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraMethod(ILjava/lang/String;)I

    move-result p1

    :goto_2
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    goto :goto_4

    :pswitch_f
    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p4

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    invoke-interface {p0, p1, p4, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraMethod(ILjava/lang/String;I)V

    :goto_3
    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    :goto_4
    return v1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
