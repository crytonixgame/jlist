.class public Lcom/vbox/core/system/camera/BCameraManagerService;
.super Lcom/vbox/core/system/camera/IBCameraManagerService$Stub;
.source "SourceFile"


# static fields
.field private static sInstance:Lcom/vbox/core/system/camera/BCameraManagerService;


# instance fields
.field private mCameraConfigs:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/vbox/entity/camera/BCameraConfig;",
            ">;"
        }
    .end annotation
.end field

.field private mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lcom/vbox/core/system/camera/IBCameraManagerService$Stub;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    new-instance v0, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {v0}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    iput-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    return-void
.end method

.method public static get()Lcom/vbox/core/system/camera/BCameraManagerService;
    .registers 2

    sget-object v0, Lcom/vbox/core/system/camera/BCameraManagerService;->sInstance:Lcom/vbox/core/system/camera/BCameraManagerService;

    if-nez v0, :cond_1

    const-class v0, Lcom/vbox/core/system/camera/BCameraManagerService;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/vbox/core/system/camera/BCameraManagerService;->sInstance:Lcom/vbox/core/system/camera/BCameraManagerService;

    if-nez v1, :cond_0

    new-instance v1, Lcom/vbox/core/system/camera/BCameraManagerService;

    invoke-direct {v1}, Lcom/vbox/core/system/camera/BCameraManagerService;-><init>()V

    sput-object v1, Lcom/vbox/core/system/camera/BCameraManagerService;->sInstance:Lcom/vbox/core/system/camera/BCameraManagerService;

    :cond_0
    monitor-exit v0

    goto :goto_0

    :catchall_0
    move-exception v1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v1

    :cond_1
    :goto_0
    sget-object v0, Lcom/vbox/core/system/camera/BCameraManagerService;->sInstance:Lcom/vbox/core/system/camera/BCameraManagerService;

    return-object v0
.end method

.method private getKey(ILjava/lang/String;)Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v0, "_"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method


# virtual methods
.method public destroy()V
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    return-void
.end method

.method public getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/camera/BCameraConfig;

    if-eqz p1, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {p1}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    :goto_0
    return-object p1
.end method

.method public getCameraMethod(ILjava/lang/String;)I
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/camera/BCameraConfig;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/vbox/entity/camera/BCameraConfig;->getMethodType()I

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public getCameraVideo(ILjava/lang/String;)Ljava/lang/String;
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/camera/BCameraConfig;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/vbox/entity/camera/BCameraConfig;->getVideoPath()Ljava/lang/String;

    move-result-object p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return-object p1
.end method

.method public getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    return-object v0
.end method

.method public getGlobalCameraMethod()I
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0}, Lcom/vbox/entity/camera/BCameraConfig;->getMethodType()I

    move-result v0

    return v0
.end method

.method public getGlobalCameraVideo()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0}, Lcom/vbox/entity/camera/BCameraConfig;->getVideoPath()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public isAudioEnabled(ILjava/lang/String;)Z
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/vbox/entity/camera/BCameraConfig;

    if-eqz p1, :cond_0

    invoke-virtual {p1}, Lcom/vbox/entity/camera/BCameraConfig;->isAudioEnabled()Z

    move-result p1

    goto :goto_0

    :cond_0
    const/4 p1, 0x1

    :goto_0
    return p1
.end method

.method public isGlobalAudioEnabled()Z
    .registers 2

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0}, Lcom/vbox/entity/camera/BCameraConfig;->isAudioEnabled()Z

    move-result v0

    return v0
.end method

.method public setAudioEnabled(ILjava/lang/String;Z)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/entity/camera/BCameraConfig;

    if-nez p2, :cond_0

    new-instance p2, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {p2}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-virtual {p2, p3}, Lcom/vbox/entity/camera/BCameraConfig;->setAudioEnabled(Z)V

    return-void
.end method

.method public setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public setCameraMethod(ILjava/lang/String;I)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/entity/camera/BCameraConfig;

    if-nez p2, :cond_0

    new-instance p2, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {p2}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-virtual {p2, p3}, Lcom/vbox/entity/camera/BCameraConfig;->setMethodType(I)V

    return-void
.end method

.method public setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0, p1, p2}, Lcom/vbox/core/system/camera/BCameraManagerService;->getKey(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p2, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/vbox/entity/camera/BCameraConfig;

    if-nez p2, :cond_0

    new-instance p2, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {p2}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mCameraConfigs:Ljava/util/Map;

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    invoke-virtual {p2, p3}, Lcom/vbox/entity/camera/BCameraConfig;->setVideoPath(Ljava/lang/String;)V

    return-void
.end method

.method public setGlobalAudioEnabled(Z)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0, p1}, Lcom/vbox/entity/camera/BCameraConfig;->setAudioEnabled(Z)V

    return-void
.end method

.method public setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 2

    iput-object p1, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    return-void
.end method

.method public setGlobalCameraMethod(I)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0, p1}, Lcom/vbox/entity/camera/BCameraConfig;->setMethodType(I)V

    return-void
.end method

.method public setGlobalCameraVideo(Ljava/lang/String;)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/core/system/camera/BCameraManagerService;->mGlobalConfig:Lcom/vbox/entity/camera/BCameraConfig;

    invoke-virtual {v0, p1}, Lcom/vbox/entity/camera/BCameraConfig;->setVideoPath(Ljava/lang/String;)V

    return-void
.end method
