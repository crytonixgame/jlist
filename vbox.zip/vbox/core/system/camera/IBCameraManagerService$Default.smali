.class public Lcom/vbox/core/system/camera/IBCameraManagerService$Default;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/core/system/camera/IBCameraManagerService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/core/system/camera/IBCameraManagerService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Default"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getCameraMethod(ILjava/lang/String;)I
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public getCameraVideo(ILjava/lang/String;)Ljava/lang/String;
    .registers 3

    const/4 p1, 0x0

    return-object p1
.end method

.method public getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public getGlobalCameraMethod()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getGlobalCameraVideo()Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public isAudioEnabled(ILjava/lang/String;)Z
    .registers 3

    const/4 p1, 0x0

    return p1
.end method

.method public isGlobalAudioEnabled()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public setAudioEnabled(ILjava/lang/String;Z)V
    .registers 4

    return-void
.end method

.method public setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 4

    return-void
.end method

.method public setCameraMethod(ILjava/lang/String;I)V
    .registers 4

    return-void
.end method

.method public setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    return-void
.end method

.method public setGlobalAudioEnabled(Z)V
    .registers 2

    return-void
.end method

.method public setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 2

    return-void
.end method

.method public setGlobalCameraMethod(I)V
    .registers 2

    return-void
.end method

.method public setGlobalCameraVideo(Ljava/lang/String;)V
    .registers 2

    return-void
.end method
