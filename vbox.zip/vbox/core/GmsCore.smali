.class public Lcom/vbox/core/GmsCore;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final GMS_PKG:Ljava/lang/String;

.field private static final GOOGLE_APP:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final GOOGLE_SERVICE:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public static final GSF_PKG:Ljava/lang/String;

.field public static final VENDING_PKG:Ljava/lang/String;

.field public static final WEBVIEW_PKG:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .registers 5

    .line 1
    sget-object v0, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0862e7971532L    # -3.9504936046018795E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    sput-object v1, Lcom/vbox/core/GmsCore;->GMS_PKG:Ljava/lang/String;

    .line 3
    const-wide v1, -0x41cf0879e7971532L    # -3.950411892187267E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 4
    sput-object v1, Lcom/vbox/core/GmsCore;->GSF_PKG:Ljava/lang/String;

    .line 5
    const-wide v1, -0x41cf0890e7971532L    # -3.950330179772655E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    sput-object v1, Lcom/vbox/core/GmsCore;->VENDING_PKG:Ljava/lang/String;

    .line 7
    const-wide v1, -0x41cf08a4e7971532L    # -3.950259125499079E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 8
    sput-object v1, Lcom/vbox/core/GmsCore;->WEBVIEW_PKG:Ljava/lang/String;

    new-instance v1, Ljava/util/HashSet;

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    sput-object v1, Lcom/vbox/core/GmsCore;->GOOGLE_APP:Ljava/util/HashSet;

    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    sput-object v2, Lcom/vbox/core/GmsCore;->GOOGLE_SERVICE:Ljava/util/HashSet;

    .line 9
    const-wide v3, -0x41cf08bfe7971532L    # -3.950163202229751E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 10
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 11
    const-wide v3, -0x41cf08d3e7971532L    # -3.950092147956175E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 12
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 13
    const-wide v3, -0x41cf08f1e7971532L    # -3.949985566545811E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 14
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 15
    const-wide v3, -0x41cf0911e7971532L    # -3.9498718797080894E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 16
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 17
    const-wide v3, -0x41cf0934e7971532L    # -3.9497475347293314E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 18
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 19
    const-wide v3, -0x41cf094ae7971532L    # -3.949669375028398E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 20
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 21
    const-wide v3, -0x41cf0961e7971532L    # -3.949587662613785E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 22
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 23
    const-wide v3, -0x41cf0978e7971532L    # -3.949505950199173E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 24
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 25
    const-wide v3, -0x41cf0993e7971532L    # -3.949410026929845E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 26
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 27
    const-wide v3, -0x41cf09b0e7971532L    # -3.94930699823316E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 28
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 29
    const-wide v3, -0x41cf09d3e7971532L    # -3.949182653254402E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 30
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 31
    const-wide v3, -0x41cf09ede7971532L    # -3.949090282698753E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 32
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 33
    const-wide v3, -0x41cf0a0ee7971532L    # -3.948973043147353E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 34
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 35
    const-wide v3, -0x41cf0a37e7971532L    # -3.948827381886522E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 36
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 37
    const-wide v3, -0x41cf0a53e7971532L    # -3.948727905903516E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 38
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 39
    const-wide v3, -0x41cf0a79e7971532L    # -3.948592902783721E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 40
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 41
    const-wide v3, -0x41cf0a99e7971532L    # -3.948479215946E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 42
    invoke-virtual {v2, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 43
    const-wide v3, -0x41cf0ab8e7971532L    # -3.948369081821957E-9

    invoke-static {v3, v4, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 44
    invoke-virtual {v2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static installGApps(I)Lcom/vbox/entity/pm/InstallResult;
    .registers 3

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sget-object v1, Lcom/vbox/core/GmsCore;->GOOGLE_SERVICE:Ljava/util/HashSet;

    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    sget-object v1, Lcom/vbox/core/GmsCore;->GOOGLE_APP:Ljava/util/HashSet;

    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    invoke-static {v0, p0}, Lcom/vbox/core/GmsCore;->installPackages(Ljava/util/Set;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object v0

    iget-boolean v1, v0, Lcom/vbox/entity/pm/InstallResult;->success:Z

    if-nez v1, :cond_0

    invoke-static {p0}, Lcom/vbox/core/GmsCore;->uninstallGApps(I)V

    :cond_0
    return-object v0
.end method

.method private static installPackages(Ljava/util/Set;I)Lcom/vbox/entity/pm/InstallResult;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;I)",
            "Lcom/vbox/entity/pm/InstallResult;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/vbox/VBoxCore;->isInstalled(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v2, v1, v3}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    invoke-virtual {v0, v1, p1}, Lcom/vbox/VBoxCore;->installPackageAsUser(Ljava/lang/String;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object v1

    iget-boolean v2, v1, Lcom/vbox/entity/pm/InstallResult;->success:Z

    if-nez v2, :cond_0

    return-object v1

    :catch_0
    move-exception v1

    goto :goto_0

    :cond_2
    new-instance p0, Lcom/vbox/entity/pm/InstallResult;

    invoke-direct {p0}, Lcom/vbox/entity/pm/InstallResult;-><init>()V

    return-object p0
.end method

.method public static isGoogleAppOrService(Ljava/lang/String;)Z
    .registers 2

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_APP:Ljava/util/HashSet;

    invoke-virtual {v0, p0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_SERVICE:Ljava/util/HashSet;

    invoke-virtual {v0, p0}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 p0, 0x1

    :goto_1
    return p0
.end method

.method public static isInstalledGoogleService(I)Z
    .registers 5

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf084be7971532L    # -3.950575317016492E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-virtual {v0, v1, p0}, Lcom/vbox/VBoxCore;->isInstalled(Ljava/lang/String;I)Z

    move-result p0

    return p0
.end method

.method public static isSupportGms()Z
    .registers 5

    const/4 v0, 0x0

    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0834e7971532L    # -3.950657029431104E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-virtual {v1, v2, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v0, 0x1

    return v0

    :catch_0
    move-exception v1

    return v0
.end method

.method public static remove(Ljava/lang/String;)V
    .registers 2

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_SERVICE:Ljava/util/HashSet;

    invoke-virtual {v0, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_APP:Ljava/util/HashSet;

    invoke-virtual {v0, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public static uninstallGApps(I)V
    .registers 2

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_SERVICE:Ljava/util/HashSet;

    invoke-static {v0, p0}, Lcom/vbox/core/GmsCore;->uninstallPackages(Ljava/util/Set;I)V

    sget-object v0, Lcom/vbox/core/GmsCore;->GOOGLE_APP:Ljava/util/HashSet;

    invoke-static {v0, p0}, Lcom/vbox/core/GmsCore;->uninstallPackages(Ljava/util/Set;I)V

    return-void
.end method

.method private static uninstallPackages(Ljava/util/Set;I)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;I)V"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1, p1}, Lcom/vbox/VBoxCore;->uninstallPackageAsUser(Ljava/lang/String;I)V

    goto :goto_0

    :cond_0
    return-void
.end method
