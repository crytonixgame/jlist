.class public Lcom/vbox/core/VNative;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final TAG:Ljava/lang/String; = "VNative"

.field private static isInjected:Z = false

.field public static libtarget:Ljava/lang/String; = "libbgmi.so"


# direct methods
.method public static constructor <clinit>()V
    .registers 4

    const-string v0, "vbox"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "loader/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Lcom/vbox/core/VNative;->libtarget:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/System;->load(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native addIORule(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public static native enableIO()V
.end method

.method public static getCallingUid(I)I
    .registers 2

    if-lez p0, :cond_0

    const/16 v0, 0x2710

    if-ge p0, v0, :cond_0

    return p0

    :cond_0
    const/16 v0, 0x4e1f

    if-le p0, v0, :cond_1

    return p0

    :cond_1
    invoke-static {}, Lcom/vbox/VBoxCore;->getHostUid()I

    move-result v0

    if-ne p0, v0, :cond_4

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "com.google.android.gms"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_2

    const/4 p0, 0x0

    return p0

    :cond_2
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object p0

    const-string v0, "com.google.android.webview"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result p0

    return p0

    :cond_3
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getCallingBUid()I

    move-result p0

    :cond_4
    return p0
.end method

.method public static redirectPath(Ljava/io/File;)Ljava/io/File;
    .registers 2

    .line 1
    invoke-static {}, Lcom/vbox/core/VCore;->get()Lcom/vbox/core/VCore;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/vbox/core/VCore;->redirectPath(Ljava/io/File;)Ljava/io/File;

    move-result-object p0

    return-object p0
.end method

.method public static redirectPath(Ljava/lang/String;)Ljava/lang/String;
    .registers 2

    .line 2
    invoke-static {}, Lcom/vbox/core/VCore;->get()Lcom/vbox/core/VCore;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/vbox/core/VCore;->redirectPath(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
