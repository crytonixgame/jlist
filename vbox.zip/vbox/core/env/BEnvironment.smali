.class public Lcom/vbox/core/env/BEnvironment;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final ExternalDirectory:Ljava/io/File;

.field private static final InternalDirectory:Ljava/io/File;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v0

    sput-object v0, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v0

    sput-object v0, Lcom/vbox/core/env/BEnvironment;->ExternalDirectory:Ljava/io/File;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static getAccountsConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf071ee7971532L    # -3.951644683833811E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getAppDir(Ljava/lang/String;)Ljava/io/File;
    .registers 7

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf0812e7971532L    # -3.9507778216961836E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getAppLibDir(Ljava/lang/String;)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0}, Lcom/vbox/core/env/BEnvironment;->getAppDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf0830e7971532L    # -3.9506712402858196E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getAppRootDir()Ljava/io/File;
    .registers 3

    .line 1
    sget-object v0, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0811e7971532L    # -3.950781374409862E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-static {v0}, Lcom/vbox/core/env/BEnvironment;->getAppDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v0

    return-object v0
.end method

.method public static getBaseApkDir(Ljava/lang/String;)Ljava/io/File;
    .registers 6

    sget-object v0, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf081ce7971532L    # -3.9507422945593956E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    .line 3
    const-wide v3, -0x41cf0826e7971532L    # -3.9507067674226076E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 4
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/io/File;

    invoke-direct {v1, v0, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v1
.end method

.method public static getCacheDir()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf070ee7971532L    # -3.951701527252672E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDataCacheDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0, p1}, Lcom/vbox/core/env/BEnvironment;->getDataDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object p1, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf07fde7971532L    # -3.950852428683438E-9

    invoke-static {v1, v2, p1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDataDatabasesDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0, p1}, Lcom/vbox/core/env/BEnvironment;->getDataDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object p1, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0807e7971532L    # -3.95081690154665E-9

    invoke-static {v1, v2, p1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDataDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 8

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf07d8e7971532L    # -3.950983879089554E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDataFilesDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0, p1}, Lcom/vbox/core/env/BEnvironment;->getDataDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object p1, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf07f1e7971532L    # -3.950895061247584E-9

    invoke-static {v1, v2, p1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDataLibDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0, p1}, Lcom/vbox/core/env/BEnvironment;->getDataDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object p1, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0803e7971532L    # -3.9508311124013656E-9

    invoke-static {v1, v2, p1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 2
    invoke-direct {v0, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getDeDataDir(Ljava/lang/String;I)Ljava/io/File;
    .registers 8

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf07a5e7971532L    # -3.951165067487173E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1, p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getExternalDataCacheDir(Ljava/lang/String;)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0}, Lcom/vbox/core/env/BEnvironment;->getExternalDataDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf07f7e7971532L    # -3.950873744965511E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getExternalDataDir(Ljava/lang/String;)Ljava/io/File;
    .registers 7

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf07b8e7971532L    # -3.951097565927276E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getExternalDataFilesDir(Ljava/lang/String;)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0}, Lcom/vbox/core/env/BEnvironment;->getExternalDataDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf07ebe7971532L    # -3.950916377529657E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getExternalObbDir(Ljava/lang/String;)Ljava/io/File;
    .registers 7

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf07c8e7971532L    # -3.951040722508415E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getExternalStorageDirectory()Ljava/io/File;
    .registers 5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1d

    if-ne v0, v1, :cond_0

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->ExternalDirectory:Ljava/io/File;

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf078ae7971532L    # -3.9512609907565004E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0

    :cond_0
    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->ExternalDirectory:Ljava/io/File;

    .line 3
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0791e7971532L    # -3.951236121760749E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getFakeDeviceConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf076ce7971532L    # -3.9513675721668645E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getFakeLocationConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0759e7971532L    # -3.951435073726762E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getPackageConf(Ljava/lang/String;)Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {p0}, Lcom/vbox/core/env/BEnvironment;->getAppDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf077de7971532L    # -3.951307176034325E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2
    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getProcDir()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0709e7971532L    # -3.951719290821066E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getProcDir(I)Ljava/io/File;
    .registers 7

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getProcDir()Ljava/io/File;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 3
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf07e8e7971532L    # -3.950927035670693E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 4
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    return-object v0
.end method

.method public static getSharedUserConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0735e7971532L    # -3.9515629714191985E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getSystemDir()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0702e7971532L    # -3.951744159816817E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getUidConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf072ce7971532L    # -3.951594945842308E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getUserDir(I)Ljava/io/File;
    .registers 7

    new-instance v0, Ljava/io/File;

    sget-object v1, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    sget-object v2, Ljava/util/Locale;->CHINA:Ljava/util/Locale;

    .line 1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf0798e7971532L    # -3.951211252764997E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    invoke-static {v2, v3, p0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getUserInfoConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0714e7971532L    # -3.951680210970599E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static getXPModuleConf()Ljava/io/File;
    .registers 5

    new-instance v0, Ljava/io/File;

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v1

    .line 1
    sget-object v2, La/a;->a:[Ljava/lang/String;

    const-wide v3, -0x41cf0746e7971532L    # -3.951502575286659E-9

    invoke-static {v3, v4, v2}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    return-object v0
.end method

.method public static load()V
    .registers 1

    sget-object v0, Lcom/vbox/core/env/BEnvironment;->InternalDirectory:Ljava/io/File;

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    sget-object v0, Lcom/vbox/core/env/BEnvironment;->ExternalDirectory:Ljava/io/File;

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getSystemDir()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getCacheDir()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->getProcDir()Ljava/io/File;

    move-result-object v0

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->mkdirs(Ljava/io/File;)V

    return-void
.end method
