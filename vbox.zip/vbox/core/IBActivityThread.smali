.class public interface abstract Lcom/vbox/core/IBActivityThread;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/core/IBActivityThread$_Parcel;,
        Lcom/vbox/core/IBActivityThread$Stub;,
        Lcom/vbox/core/IBActivityThread$Default;
    }
.end annotation


# static fields
.field public static final DESCRIPTOR:Ljava/lang/String; = "com.vbox.core.IBActivityThread"


# virtual methods
.method public abstract acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;
.end method

.method public abstract bindApplication()V
.end method

.method public abstract finishActivity(Landroid/os/IBinder;)V
.end method

.method public abstract getActivityThread()Landroid/os/IBinder;
.end method

.method public abstract handleNewIntent(Landroid/os/IBinder;Landroid/content/Intent;)V
.end method

.method public abstract peekService(Landroid/content/Intent;)Landroid/os/IBinder;
.end method

.method public abstract restartJobService(Ljava/lang/String;)V
.end method

.method public abstract scheduleReceiver(Lcom/vbox/entity/am/ReceiverData;)V
.end method

.method public abstract stopService(Landroid/content/Intent;)V
.end method
