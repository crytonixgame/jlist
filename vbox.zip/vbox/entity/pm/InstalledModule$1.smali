.class Lcom/vbox/entity/pm/InstalledModule$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/entity/pm/InstalledModule;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/vbox/entity/pm/InstalledModule;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createFromParcel(Landroid/os/Parcel;)Lcom/vbox/entity/pm/InstalledModule;
    .registers 3

    .line 1
    new-instance v0, Lcom/vbox/entity/pm/InstalledModule;

    invoke-direct {v0, p1}, Lcom/vbox/entity/pm/InstalledModule;-><init>(Landroid/os/Parcel;)V

    return-object v0
.end method

.method public bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, Lcom/vbox/entity/pm/InstalledModule$1;->createFromParcel(Landroid/os/Parcel;)Lcom/vbox/entity/pm/InstalledModule;

    move-result-object p1

    return-object p1
.end method

.method public newArray(I)[Lcom/vbox/entity/pm/InstalledModule;
    .registers 2

    .line 1
    new-array p1, p1, [Lcom/vbox/entity/pm/InstalledModule;

    return-object p1
.end method

.method public bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 2

    .line 2
    invoke-virtual {p0, p1}, Lcom/vbox/entity/pm/InstalledModule$1;->newArray(I)[Lcom/vbox/entity/pm/InstalledModule;

    move-result-object p1

    return-object p1
.end method
