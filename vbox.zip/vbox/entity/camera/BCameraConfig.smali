.class public Lcom/vbox/entity/camera/BCameraConfig;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/vbox/entity/camera/BCameraConfig;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private audioEnabled:Z

.field private cameraId:I

.field private methodType:I

.field private resolutionHeight:I

.field private resolutionWidth:I

.field private videoPath:Ljava/lang/String;

.field private videoQuality:I


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/entity/camera/BCameraConfig$1;

    invoke-direct {v0}, Lcom/vbox/entity/camera/BCameraConfig$1;-><init>()V

    sput-object v0, Lcom/vbox/entity/camera/BCameraConfig;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->methodType:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoPath:Ljava/lang/String;

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iput-boolean v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->audioEnabled:Z

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->cameraId:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoQuality:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionWidth:I

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result p1

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionHeight:I

    return-void
.end method


# virtual methods
.method public describeContents()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public getCameraId()I
    .registers 2

    iget v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->cameraId:I

    return v0
.end method

.method public getMethodType()I
    .registers 2

    iget v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->methodType:I

    return v0
.end method

.method public getResolutionHeight()I
    .registers 2

    iget v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionHeight:I

    return v0
.end method

.method public getResolutionWidth()I
    .registers 2

    iget v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionWidth:I

    return v0
.end method

.method public getVideoPath()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoPath:Ljava/lang/String;

    return-object v0
.end method

.method public getVideoQuality()I
    .registers 2

    iget v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoQuality:I

    return v0
.end method

.method public isAudioEnabled()Z
    .registers 2

    iget-boolean v0, p0, Lcom/vbox/entity/camera/BCameraConfig;->audioEnabled:Z

    return v0
.end method

.method public setAudioEnabled(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->audioEnabled:Z

    return-void
.end method

.method public setCameraId(I)V
    .registers 2

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->cameraId:I

    return-void
.end method

.method public setMethodType(I)V
    .registers 2

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->methodType:I

    return-void
.end method

.method public setResolutionHeight(I)V
    .registers 2

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionHeight:I

    return-void
.end method

.method public setResolutionWidth(I)V
    .registers 2

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionWidth:I

    return-void
.end method

.method public setVideoPath(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoPath:Ljava/lang/String;

    return-void
.end method

.method public setVideoQuality(I)V
    .registers 2

    iput p1, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoQuality:I

    return-void
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 3

    iget p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->methodType:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget-object p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoPath:Ljava/lang/String;

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    iget-boolean p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->audioEnabled:Z

    int-to-byte p2, p2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    iget p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->cameraId:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->videoQuality:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionWidth:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    iget p2, p0, Lcom/vbox/entity/camera/BCameraConfig;->resolutionHeight:I

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    return-void
.end method
