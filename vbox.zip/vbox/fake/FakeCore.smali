.class public Lcom/vbox/fake/FakeCore;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static init()V
    .registers 1

    const-class v0, Landroid/app/ActivityThread;

    invoke-static {v0}, Lcom/vbox/jnihook/ReflectCore;->set(Ljava/lang/Class;)V

    return-void
.end method
