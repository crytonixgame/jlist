.class public Lcom/vbox/fake/hook/HookManager;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final TAG:Ljava/lang/String; = "HookManager"

.field private static final sHookManager:Lcom/vbox/fake/hook/HookManager;


# instance fields
.field private mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;

.field private final mInjectors:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Class<",
            "*>;",
            "Lcom/vbox/fake/hook/IInjectHook;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/fake/hook/HookManager;

    invoke-direct {v0}, Lcom/vbox/fake/hook/HookManager;-><init>()V

    sput-object v0, Lcom/vbox/fake/hook/HookManager;->sHookManager:Lcom/vbox/fake/hook/HookManager;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    return-void
.end method

.method public static get()Lcom/vbox/fake/hook/HookManager;
    .registers 1

    sget-object v0, Lcom/vbox/fake/hook/HookManager;->sHookManager:Lcom/vbox/fake/hook/HookManager;

    return-object v0
.end method


# virtual methods
.method public addInjector(Lcom/vbox/fake/hook/IInjectHook;)V
    .registers 4

    iget-object v0, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public checkAll()V
    .registers 6

    iget-object v0, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Class;

    iget-object v2, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/fake/hook/IInjectHook;

    if-eqz v2, :cond_0

    invoke-interface {v2}, Lcom/vbox/fake/hook/IInjectHook;->isBadEnv()Z

    move-result v3

    if-eqz v3, :cond_0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "checkEnv: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " is bad env"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v3, "HookManager"

    invoke-static {v3, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v2}, Lcom/vbox/fake/hook/IInjectHook;->injectHook()V

    goto :goto_0

    :cond_1
    return-void
.end method

.method public checkEnv(Ljava/lang/Class;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    iget-object v0, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vbox/fake/hook/IInjectHook;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Lcom/vbox/fake/hook/IInjectHook;->isBadEnv()Z

    move-result v1

    if-eqz v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "checkEnv: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    const-string v1, " is bad env"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "HookManager"

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v0}, Lcom/vbox/fake/hook/IInjectHook;->injectHook()V

    :cond_0
    return-void
.end method

.method public cleanup()V
    .registers 5

    const-string v0, "HookManager"

    const-string v1, "BoxHookAdapter deactivated: "

    :try_start_0
    iget-object v2, p0, Lcom/vbox/fake/hook/HookManager;->mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;

    if-eqz v2, :cond_0

    invoke-virtual {v2}, Lcom/vbox/fake/hook/BoxHookAdapter;->deactivate()Z

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    iput-object v1, p0, Lcom/vbox/fake/hook/HookManager;->mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "BoxHookAdapter deactivate failed: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vbox/utils/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    return-void
.end method

.method public init()V
    .registers 5

    const-string v0, "HookManager"

    const-string v1, "BoxHookAdapter activated: "

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v2

    invoke-virtual {v2}, Lcom/vbox/VBoxCore;->isBlackProcess()Z

    move-result v2

    if-nez v2, :cond_0

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v2

    invoke-virtual {v2}, Lcom/vbox/VBoxCore;->isServerProcess()Z

    move-result v2

    if-eqz v2, :cond_9

    :cond_0
    new-instance v2, Lcom/vbox/fake/service/libcore/OsStub;

    invoke-direct {v2}, Lcom/vbox/fake/service/libcore/OsStub;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/BuildProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/BuildProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IDisplayManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IDisplayManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IDropBoxManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IDropBoxManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IInputMethodManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IInputMethodManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IJobServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IJobServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ITelephonyManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ITelephonyManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IActivityManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IActivityManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IPackageManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IPackageManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/HCallbackStub;

    invoke-direct {v2}, Lcom/vbox/fake/service/HCallbackStub;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IWifiManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IWifiManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IWifiScannerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IWifiScannerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ISubProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ISubProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAppOpsManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAppOpsManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/INotificationManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/INotificationManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAlarmManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAlarmManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAppWidgetManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAppWidgetManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAudioManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAudioManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IBackupManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IBackupManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IBluetoothManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IBluetoothManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/context/ContentServiceStub;

    invoke-direct {v2}, Lcom/vbox/fake/service/context/ContentServiceStub;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IWindowManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IWindowManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IUserManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IUserManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/context/RestrictionsManagerStub;

    invoke-direct {v2}, Lcom/vbox/fake/service/context/RestrictionsManagerStub;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IMediaSessionManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IMediaSessionManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ILocationManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ILocationManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ISmsProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ISmsProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IStorageManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IStorageManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ILauncherAppsProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ILauncherAppsProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAccessibilityManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAccessibilityManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ITelephonyRegistryProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ITelephonyRegistryProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IDevicePolicyManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IDevicePolicyManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IAccountManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAccountManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IConnectivityManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IConnectivityManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IClipboardManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IClipboardManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IPhoneSubInfoProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IPhoneSubInfoProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IMediaRouterServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IMediaRouterServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/INetworkManagementServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/INetworkManagementServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IPowerManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IPowerManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ICrossProfileAppsProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ICrossProfileAppsProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IVibratorServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IVibratorServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    invoke-static {}, Lcom/vbox/fake/delegate/AppInstrumentation;->get()Lcom/vbox/fake/delegate/AppInstrumentation;

    move-result-object v2

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isVivo()Z

    move-result v2

    if-eqz v2, :cond_1

    new-instance v2, Lcom/vbox/fake/service/vivo/IVivoPermissionServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/vivo/IVivoPermissionServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_1
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isBaklava()Z

    move-result v2

    if-eqz v2, :cond_2

    new-instance v2, Lcom/vbox/fake/service/IPersistentDataBlockServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IPersistentDataBlockServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_2
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isUpsideDownCake()Z

    move-result v2

    if-eqz v2, :cond_3

    new-instance v2, Lcom/vbox/fake/service/IAppIntegrityManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAppIntegrityManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IMiuiCameraCoveredManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IMiuiCameraCoveredManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ILocaleManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ILocaleManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_3
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isS()Z

    move-result v2

    if-eqz v2, :cond_4

    new-instance v2, Lcom/vbox/fake/service/IActivityClientProxy;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lcom/vbox/fake/service/IActivityClientProxy;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IVpnManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IVpnManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_4
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isR()Z

    move-result v2

    if-eqz v2, :cond_5

    new-instance v2, Lcom/vbox/fake/service/IActivityTaskManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IActivityTaskManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IPermissionManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IPermissionManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_5
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isQ()Z

    move-result v2

    if-eqz v2, :cond_6

    new-instance v2, Lcom/vbox/fake/service/IDeviceIdentifiersPolicyProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IDeviceIdentifiersPolicyProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_6
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo_MR1()Z

    move-result v2

    if-eqz v2, :cond_7

    new-instance v2, Lcom/vbox/fake/service/IAutofillManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IAutofillManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IContextHubServiceProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IContextHubServiceProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IStorageStatsManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IStorageStatsManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/ISystemUpdateProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/ISystemUpdateProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_7
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo()Z

    move-result v2

    if-eqz v2, :cond_8

    new-instance v2, Lcom/vbox/fake/service/IShortcutManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IShortcutManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_8
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isN()Z

    move-result v2

    if-eqz v2, :cond_9

    new-instance v2, Lcom/vbox/fake/service/IFingerprintManagerProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IFingerprintManagerProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    new-instance v2, Lcom/vbox/fake/service/IGraphicsStatsProxy;

    invoke-direct {v2}, Lcom/vbox/fake/service/IGraphicsStatsProxy;-><init>()V

    invoke-virtual {p0, v2}, Lcom/vbox/fake/hook/HookManager;->addInjector(Lcom/vbox/fake/hook/IInjectHook;)V

    :cond_9
    invoke-virtual {p0}, Lcom/vbox/fake/hook/HookManager;->injectAll()V

    :try_start_0
    new-instance v2, Lcom/vbox/fake/hook/BoxHookAdapter;

    invoke-direct {v2}, Lcom/vbox/fake/hook/BoxHookAdapter;-><init>()V

    iput-object v2, p0, Lcom/vbox/fake/hook/HookManager;->mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v2, v3}, Lcom/vbox/fake/hook/BoxHookAdapter;->initialize(Landroid/content/Context;)V

    iget-object v2, p0, Lcom/vbox/fake/hook/HookManager;->mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;

    invoke-virtual {v2}, Lcom/vbox/fake/hook/BoxHookAdapter;->activate()Z

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " | status="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/vbox/fake/hook/HookManager;->mBoxHookAdapter:Lcom/vbox/fake/hook/BoxHookAdapter;

    invoke-virtual {v2}, Lcom/vbox/fake/hook/BoxHookAdapter;->status()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "BoxHookAdapter activation failed: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/vbox/utils/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method

.method public injectAll()V
    .registers 6

    const-string v0, "HookManager"

    iget-object v1, p0, Lcom/vbox/fake/hook/HookManager;->mInjectors:Ljava/util/Map;

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/vbox/fake/hook/IInjectHook;

    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "hook: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v0, v3}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-interface {v2}, Lcom/vbox/fake/hook/IInjectHook;->injectHook()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v3

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "hook error: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    return-void
.end method
