.class public interface abstract Lcom/vbox/fake/hook/HookControllerHelper$HookManagerAdapter;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/hook/HookControllerHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "HookManagerAdapter"
.end annotation


# virtual methods
.method public abstract activate()Z
.end method

.method public abstract deactivate()Z
.end method

.method public abstract initialize(Landroid/content/Context;)V
.end method

.method public abstract status()Ljava/lang/String;
.end method
