.class public Lcom/vbox/fake/hook/MethodHook$Unhook;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/hook/MethodHook;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "Unhook"
.end annotation


# instance fields
.field private final hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

.field final synthetic this$0:Lcom/vbox/fake/hook/MethodHook;


# direct methods
.method public constructor <init>(Lcom/vbox/fake/hook/MethodHook;Lcom/vbox/fake/hook/MethodHook$HookRecord;)V
    .registers 3

    iput-object p1, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->this$0:Lcom/vbox/fake/hook/MethodHook;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    return-void
.end method


# virtual methods
.method public getCallback()Lcom/vbox/fake/hook/MethodHook;
    .registers 2

    iget-object v0, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->this$0:Lcom/vbox/fake/hook/MethodHook;

    return-object v0
.end method

.method public getTarget()Ljava/lang/reflect/Member;
    .registers 2

    iget-object v0, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    iget-object v0, v0, Lcom/vbox/fake/hook/MethodHook$HookRecord;->target:Ljava/lang/reflect/Member;

    return-object v0
.end method

.method public unhook()V
    .registers 4

    invoke-static {}, Lcom/vbox/fake/hook/MethodHook;->getHookHandler()Lcom/vbox/fake/hook/MethodHook$HookHandler;

    move-result-object v0

    iget-object v1, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    iget-object v2, p0, Lcom/vbox/fake/hook/MethodHook$Unhook;->this$0:Lcom/vbox/fake/hook/MethodHook;

    invoke-interface {v0, v1, v2}, Lcom/vbox/fake/hook/MethodHook$HookHandler;->handleUnhook(Lcom/vbox/fake/hook/MethodHook$HookRecord;Lcom/vbox/fake/hook/MethodHook;)V

    return-void
.end method
