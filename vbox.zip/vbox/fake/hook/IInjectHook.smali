.class public interface abstract Lcom/vbox/fake/hook/IInjectHook;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract injectHook()V
.end method

.method public abstract isBadEnv()Z
.end method
