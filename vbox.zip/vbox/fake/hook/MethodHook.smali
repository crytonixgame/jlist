.class public abstract Lcom/vbox/fake/hook/MethodHook;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/hook/MethodHook$HookHandler;,
        Lcom/vbox/fake/hook/MethodHook$HookRecord;,
        Lcom/vbox/fake/hook/MethodHook$Unhook;,
        Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;
    }
.end annotation


# static fields
.field private static sHookHandler:Lcom/vbox/fake/hook/MethodHook$HookHandler;

.field private static final sHookRecords:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Lcom/vbox/fake/hook/MethodHook$HookRecord;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    sput-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookRecords:Ljava/util/Map;

    new-instance v0, Lcom/vbox/fake/hook/MethodHook$1;

    invoke-direct {v0}, Lcom/vbox/fake/hook/MethodHook$1;-><init>()V

    sput-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookHandler:Lcom/vbox/fake/hook/MethodHook$HookHandler;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static addHookRecord(JLcom/vbox/fake/hook/MethodHook$HookRecord;)V
    .registers 4

    sget-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookRecords:Ljava/util/Map;

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-interface {v0, p0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static getHookHandler()Lcom/vbox/fake/hook/MethodHook$HookHandler;
    .registers 1

    sget-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookHandler:Lcom/vbox/fake/hook/MethodHook$HookHandler;

    return-object v0
.end method

.method public static getHookRecord(J)Lcom/vbox/fake/hook/MethodHook$HookRecord;
    .registers 5

    sget-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookRecords:Ljava/util/Map;

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/vbox/fake/hook/MethodHook$HookRecord;

    if-eqz v0, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Ljava/lang/AssertionError;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "No HookRecord found for ArtMethod pointer 0x"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0, p1}, Ljava/lang/Long;->toHexString(J)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0
.end method

.method public static hasHookRecord(J)Z
    .registers 3

    sget-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookRecords:Ljava/util/Map;

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p0

    return p0
.end method

.method public static removeHookRecord(J)V
    .registers 3

    sget-object v0, Lcom/vbox/fake/hook/MethodHook;->sHookRecords:Ljava/util/Map;

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public afterHook(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    return-object p1
.end method

.method public beforeHook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    const/4 p1, 0x0

    return-object p1
.end method

.method public getMethodName()Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    return-object v0
.end method

.method public abstract hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public isEnable()Z
    .registers 2

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->isBlackProcess()Z

    move-result v0

    return v0
.end method
