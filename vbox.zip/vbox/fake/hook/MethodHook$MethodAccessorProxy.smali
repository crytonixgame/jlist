.class Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/hook/MethodHook;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "MethodAccessorProxy"
.end annotation


# instance fields
.field private final hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

.field private final original:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;Lcom/vbox/fake/hook/MethodHook$HookRecord;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->original:Ljava/lang/reflect/Method;

    iput-object p2, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    iget-object p1, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    iget-boolean p1, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->isStatic:Z

    const/4 p2, 0x0

    if-nez p1, :cond_0

    aget-object p1, p3, p2

    array-length v0, p3

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    new-array v2, v0, [Ljava/lang/Object;

    invoke-static {p3, v1, v2, p2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p3, v2

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iget-object v0, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    invoke-virtual {v0}, Lcom/vbox/fake/hook/MethodHook$HookRecord;->getCallbacks()[Lcom/vbox/fake/hook/MethodHook;

    move-result-object v0

    array-length v1, v0

    move v2, p2

    :goto_1
    if-ge v2, v1, :cond_2

    aget-object v3, v0, v2

    iget-object v4, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->original:Ljava/lang/reflect/Method;

    invoke-virtual {v3, p1, v4, p3}, Lcom/vbox/fake/hook/MethodHook;->beforeHook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_1

    invoke-virtual {v3, v4}, Lcom/vbox/fake/hook/MethodHook;->afterHook(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_1

    :cond_2
    :try_start_0
    iget-object v0, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->original:Ljava/lang/reflect/Method;

    invoke-virtual {v0, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    iget-object p3, p0, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;->hookRecord:Lcom/vbox/fake/hook/MethodHook$HookRecord;

    invoke-virtual {p3}, Lcom/vbox/fake/hook/MethodHook$HookRecord;->getCallbacks()[Lcom/vbox/fake/hook/MethodHook;

    move-result-object p3

    array-length v0, p3

    :goto_2
    if-ge p2, v0, :cond_3

    aget-object v1, p3, p2

    invoke-virtual {v1, p1}, Lcom/vbox/fake/hook/MethodHook;->afterHook(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    add-int/lit8 p2, p2, 0x1

    goto :goto_2

    :cond_3
    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getTargetException()Ljava/lang/Throwable;

    move-result-object p1

    throw p1
.end method
