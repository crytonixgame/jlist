.class public interface abstract Lcom/vbox/fake/hook/MethodHook$HookHandler;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/hook/MethodHook;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "HookHandler"
.end annotation


# virtual methods
.method public abstract handleHook(Lcom/vbox/fake/hook/MethodHook$HookRecord;Lcom/vbox/fake/hook/MethodHook;IZZ)Lcom/vbox/fake/hook/MethodHook$Unhook;
.end method

.method public abstract handleUnhook(Lcom/vbox/fake/hook/MethodHook$HookRecord;Lcom/vbox/fake/hook/MethodHook;)V
.end method
