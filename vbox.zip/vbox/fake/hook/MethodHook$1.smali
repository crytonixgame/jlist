.class Lcom/vbox/fake/hook/MethodHook$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lcom/vbox/fake/hook/MethodHook$HookHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/hook/MethodHook;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private hookNewMethod(Lcom/vbox/fake/hook/MethodHook$HookRecord;IZ)V
    .registers 7

    :try_start_0
    iget-object v0, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->target:Ljava/lang/reflect/Member;

    invoke-interface {v0}, Ljava/lang/reflect/Member;->getDeclaringClass()Ljava/lang/Class;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    if-eqz p3, :cond_0

    :try_start_1
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v1

    invoke-static {p3, v2, v1}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception p3

    :cond_0
    :goto_0
    :try_start_2
    instance-of p3, v0, Ljava/lang/reflect/Method;

    if-eqz p3, :cond_1

    check-cast v0, Ljava/lang/reflect/Method;

    iput-object v0, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->backup:Ljava/lang/reflect/Method;

    invoke-static {p2}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result p2

    iput-boolean p2, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->isStatic:Z

    invoke-static {v0}, Lcom/vbox/fake/hook/MethodHook$1$$ExternalSyntheticBackport0;->m(Ljava/lang/reflect/Method;)I

    move-result p2

    iput p2, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->paramNumber:I

    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object p2

    iput-object p2, p1, Lcom/vbox/fake/hook/MethodHook$HookRecord;->paramTypes:[Ljava/lang/Class;

    const-class p2, Ljava/lang/reflect/Method;

    const-string p3, "methodAccessor"

    invoke-virtual {p2, p3}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p2

    invoke-virtual {p2, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    new-instance p3, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;

    invoke-direct {p3, v0, p1}, Lcom/vbox/fake/hook/MethodHook$MethodAccessorProxy;-><init>(Ljava/lang/reflect/Method;Lcom/vbox/fake/hook/MethodHook$HookRecord;)V

    invoke-virtual {p2, v0, p3}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_1
    return-void

    :catchall_0
    move-exception p1

    new-instance p2, Ljava/lang/RuntimeException;

    const-string p3, "Failed to hook method"

    invoke-direct {p2, p3, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method


# virtual methods
.method public handleHook(Lcom/vbox/fake/hook/MethodHook$HookRecord;Lcom/vbox/fake/hook/MethodHook;IZZ)Lcom/vbox/fake/hook/MethodHook$Unhook;
    .registers 6

    if-eqz p4, :cond_0

    invoke-direct {p0, p1, p3, p5}, Lcom/vbox/fake/hook/MethodHook$1;->hookNewMethod(Lcom/vbox/fake/hook/MethodHook$HookRecord;IZ)V

    :cond_0
    if-nez p2, :cond_1

    const/4 p1, 0x0

    return-object p1

    :cond_1
    invoke-virtual {p1, p2}, Lcom/vbox/fake/hook/MethodHook$HookRecord;->addCallback(Lcom/vbox/fake/hook/MethodHook;)V

    new-instance p3, Lcom/vbox/fake/hook/MethodHook$Unhook;

    invoke-direct {p3, p2, p1}, Lcom/vbox/fake/hook/MethodHook$Unhook;-><init>(Lcom/vbox/fake/hook/MethodHook;Lcom/vbox/fake/hook/MethodHook$HookRecord;)V

    return-object p3
.end method

.method public handleUnhook(Lcom/vbox/fake/hook/MethodHook$HookRecord;Lcom/vbox/fake/hook/MethodHook;)V
    .registers 3

    invoke-virtual {p1, p2}, Lcom/vbox/fake/hook/MethodHook$HookRecord;->removeCallback(Lcom/vbox/fake/hook/MethodHook;)V

    return-void
.end method
