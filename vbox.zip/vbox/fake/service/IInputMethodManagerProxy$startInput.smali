.class public Lcom/vbox/fake/service/IInputMethodManagerProxy$startInput;
.super Lcom/vbox/fake/service/IInputMethodManagerProxy$startInputOrWindowGainedFocus;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "startInput"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IInputMethodManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "startInput"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/service/IInputMethodManagerProxy$startInputOrWindowGainedFocus;-><init>()V

    return-void
.end method
