.class public Lcom/vbox/fake/service/ILocaleManagerProxy;
.super Lcom/vbox/fake/hook/BinderInvocationStub;
.source "SourceFile"


# static fields
.field public static final TAG:Ljava/lang/String; = "ILocaleManagerProxy"


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v0

    const-string v1, "locale"

    invoke-interface {v0, v1}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/vbox/fake/hook/BinderInvocationStub;-><init>(Landroid/os/IBinder;)V

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 4

    invoke-static {}, Lblack/android/app/BRILocaleManagerStub;->get()Lblack/android/app/ILocaleManagerStubStatic;

    move-result-object v0

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v1

    const-string v2, "locale"

    invoke-interface {v1, v2}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    invoke-interface {v0, v1}, Lblack/android/app/ILocaleManagerStubStatic;->asInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    const-string p1, "locale"

    invoke-virtual {p0, p1}, Lcom/vbox/fake/hook/BinderInvocationStub;->replaceSystemService(Ljava/lang/String;)V

    return-void
.end method

.method public isBadEnv()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public onBindMethod()V
    .registers 3

    invoke-super {p0}, Lcom/vbox/fake/hook/BinderInvocationStub;->onBindMethod()V

    new-instance v0, Lcom/vbox/fake/service/base/PkgMethodProxy;

    const-string v1, "setApplicationLocales"

    invoke-direct {v0, v1}, Lcom/vbox/fake/service/base/PkgMethodProxy;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/vbox/fake/hook/ClassInvocationStub;->addMethodHook(Lcom/vbox/fake/hook/MethodHook;)V

    new-instance v0, Lcom/vbox/fake/service/base/PkgMethodProxy;

    const-string v1, "getApplicationLocales"

    invoke-direct {v0, v1}, Lcom/vbox/fake/service/base/PkgMethodProxy;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/vbox/fake/hook/ClassInvocationStub;->addMethodHook(Lcom/vbox/fake/hook/MethodHook;)V

    return-void
.end method
