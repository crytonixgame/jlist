.class public Lcom/vbox/fake/service/IAppIntegrityManagerProxy$getCurrentRules;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "getCurrentRules"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IAppIntegrityManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "getCurrentRules"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-static {p1}, Lcom/vbox/utils/compat/ParceledListSliceCompat;->create(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
