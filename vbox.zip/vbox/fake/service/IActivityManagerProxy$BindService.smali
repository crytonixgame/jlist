.class public Lcom/vbox/fake/service/IActivityManagerProxy$BindService;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "bindService"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IActivityManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BindService"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    const/4 v0, 0x2

    aget-object v1, p3, v0

    check-cast v1, Landroid/content/Intent;

    const/4 v2, 0x3

    aget-object v2, p3, v2

    check-cast v2, Ljava/lang/String;

    const/4 v3, 0x4

    aget-object v4, p3, v3

    check-cast v4, Landroid/app/IServiceConnection;

    .line 1
    sget-object v5, La/a;->a:[Ljava/lang/String;

    const-wide v6, -0x41cf0e9ae7971532L    # -3.944837684425229E-9

    invoke-static {v6, v7, v5}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 2
    const/4 v6, -0x1

    invoke-virtual {v1, v5, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v5

    if-ne v5, v6, :cond_0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v5

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v6

    const/4 v7, 0x0

    invoke-virtual {v6, v1, v7, v2, v5}, Lcom/vbox/fake/frameworks/BPackageManager;->resolveService(Landroid/content/Intent;ILjava/lang/String;I)Landroid/content/pm/ResolveInfo;

    move-result-object v6

    if-nez v6, :cond_1

    invoke-virtual {v1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v8

    invoke-static {v8}, Lcom/vbox/core/env/AppSystemEnv;->isOpenPackage(Landroid/content/ComponentName;)Z

    move-result v8

    if-eqz v8, :cond_5

    :cond_1
    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v8

    if-nez v4, :cond_2

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    invoke-interface {v4}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v9

    :goto_0
    invoke-virtual {v8, v1, v9, v2, v5}, Lcom/vbox/fake/frameworks/BActivityManager;->bindService(Landroid/content/Intent;Landroid/os/IBinder;Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v2

    if-eqz v4, :cond_4

    invoke-virtual {v1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v5

    if-nez v5, :cond_3

    if-eqz v6, :cond_3

    new-instance v5, Landroid/content/ComponentName;

    iget-object v6, v6, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    iget-object v8, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    iget-object v6, v6, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    invoke-direct {v5, v8, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v5}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    :cond_3
    invoke-static {v4, v1}, Lcom/vbox/fake/delegate/ServiceConnectionDelegate;->createProxy(Landroid/app/IServiceConnection;Landroid/content/Intent;)Landroid/app/IServiceConnection;

    move-result-object v1

    aput-object v1, p3, v3

    invoke-static {v4}, Lblack/android/app/BRLoadedApkServiceDispatcherInnerConnection;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkServiceDispatcherInnerConnectionContext;

    move-result-object v3

    invoke-interface {v3}, Lblack/android/app/LoadedApkServiceDispatcherInnerConnectionContext;->mDispatcher()Ljava/lang/ref/WeakReference;

    move-result-object v3

    if-eqz v3, :cond_4

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Lblack/android/app/BRLoadedApkServiceDispatcher;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkServiceDispatcherContext;

    move-result-object v3

    invoke-interface {v3, v1}, Lblack/android/app/LoadedApkServiceDispatcherContext;->_set_mConnection(Ljava/lang/Object;)V

    :cond_4
    if-eqz v2, :cond_5

    aput-object v2, p3, v0

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_5
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1
.end method

.method public isEnable()Z
    .registers 2

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->isBlackProcess()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->isServerProcess()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    :goto_1
    return v0
.end method
