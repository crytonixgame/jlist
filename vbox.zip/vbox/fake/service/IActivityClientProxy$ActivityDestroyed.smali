.class public Lcom/vbox/fake/service/IActivityClientProxy$ActivityDestroyed;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "activityDestroyed"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IActivityClientProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ActivityDestroyed"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    const/4 v0, 0x0

    aget-object v0, p3, v0

    check-cast v0, Landroid/os/IBinder;

    invoke-static {}, Lcom/vbox/fake/frameworks/BActivityManager;->get()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/vbox/fake/frameworks/BActivityManager;->onActivityDestroyed(Landroid/os/IBinder;)V

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
