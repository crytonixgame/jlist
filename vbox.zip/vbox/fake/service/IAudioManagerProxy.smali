.class public Lcom/vbox/fake/service/IAudioManagerProxy;
.super Lcom/vbox/fake/hook/BinderInvocationStub;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/service/IAudioManagerProxy$setMicrophoneMute;,
        Lcom/vbox/fake/service/IAudioManagerProxy$isHardwareDetected;,
        Lcom/vbox/fake/service/IAudioManagerProxy$adjustVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$adjustLocalOrRemoteStreamVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$adjustSuggestedStreamVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$adjustStreamVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$adjustMasterVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setStreamVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setMasterVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setRingerModeExternal;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setRingerModeInternal;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setMode;,
        Lcom/vbox/fake/service/IAudioManagerProxy$avrcpSupportsAbsoluteVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$abandonAudioFocus;,
        Lcom/vbox/fake/service/IAudioManagerProxy$requestAudioFocus;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setWiredDeviceConnectionState;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setSpeakerphoneOn;,
        Lcom/vbox/fake/service/IAudioManagerProxy$setBluetoothScoOn;,
        Lcom/vbox/fake/service/IAudioManagerProxy$stopBluetoothSco;,
        Lcom/vbox/fake/service/IAudioManagerProxy$startBluetoothSco;,
        Lcom/vbox/fake/service/IAudioManagerProxy$disableSafeMediaVolume;,
        Lcom/vbox/fake/service/IAudioManagerProxy$registerRemoteControlClient;,
        Lcom/vbox/fake/service/IAudioManagerProxy$unregisterAudioFocusClient;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v0

    const-string v1, "audio"

    invoke-interface {v0, v1}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/vbox/fake/hook/BinderInvocationStub;-><init>(Landroid/os/IBinder;)V

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 4

    invoke-static {}, Lblack/android/media/BRIAudioServiceStub;->get()Lblack/android/media/IAudioServiceStubStatic;

    move-result-object v0

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v1

    const-string v2, "audio"

    invoke-interface {v1, v2}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    invoke-interface {v0, v1}, Lblack/android/media/IAudioServiceStubStatic;->asInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    const-string p1, "audio"

    invoke-virtual {p0, p1}, Lcom/vbox/fake/hook/BinderInvocationStub;->replaceSystemService(Ljava/lang/String;)V

    return-void
.end method

.method public isBadEnv()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
