.class public Lcom/vbox/fake/service/IActivityManagerProxy$GetContentProvider;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "getContentProvider"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IActivityManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "GetContentProvider"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method

.method private getAuthIndex()I
    .registers 2

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isQ()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x2

    return v0

    :cond_0
    const/4 v0, 0x1

    return v0
.end method

.method private getUserIndex()I
    .registers 2

    invoke-direct {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$GetContentProvider;->getAuthIndex()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    return v0
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    invoke-direct {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$GetContentProvider;->getAuthIndex()I

    move-result v0

    aget-object v1, p3, v0

    instance-of v2, v1, Ljava/lang/String;

    if-eqz v2, :cond_8

    move-object v2, v1

    check-cast v2, Ljava/lang/String;

    invoke-static {v2}, Lcom/vbox/proxy/ProxyManifest;->isProxy(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :cond_0
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isQ()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostPkg()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    aput-object v3, p3, v4

    .line 1
    :cond_1
    sget-object v3, La/a;->a:[Ljava/lang/String;

    const-wide v4, -0x41cf0e45e7971532L    # -3.945139665087927E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2
    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_7

    .line 3
    const-wide v4, -0x41cf0e4ee7971532L    # -3.945107690664818E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 4
    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_7

    .line 5
    const-wide v4, -0x41cf0e54e7971532L    # -3.945086374382745E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 6
    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2

    goto/16 :goto_2

    .line 7
    :cond_2
    const-wide v4, -0x41cf0e5ee7971532L    # -3.945050847245957E-9

    invoke-static {v4, v5, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 8
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 9
    const-wide v6, -0x41cf0e72e7971532L    # -3.944979792972381E-9

    invoke-static {v6, v7, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 10
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v4

    const/16 v5, 0x80

    invoke-virtual {v1, v2, v5, v4}, Lcom/vbox/fake/frameworks/BPackageManager;->resolveContentProvider(Ljava/lang/String;II)Landroid/content/pm/ProviderInfo;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_3

    return-object v2

    :cond_3
    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPid()I

    move-result v4

    const/4 v5, -0x1

    if-eq v4, v5, :cond_5

    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v4

    iget-object v5, v1, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    iget-object v6, v1, Landroid/content/pm/ProviderInfo;->processName:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v7

    invoke-virtual {v4, v5, v6, v7}, Lcom/vbox/fake/frameworks/BActivityManager;->initProcess(Ljava/lang/String;Ljava/lang/String;I)Lcom/vbox/entity/AppConfig;

    move-result-object v4

    iget v5, v4, Lcom/vbox/entity/AppConfig;->bpid:I

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPid()I

    move-result v6

    if-eq v5, v6, :cond_4

    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v5

    invoke-virtual {v5, v1}, Lcom/vbox/fake/frameworks/BActivityManager;->acquireContentProviderClient(Landroid/content/pm/ProviderInfo;)Landroid/os/IBinder;

    move-result-object v5

    goto :goto_0

    :cond_4
    move-object v5, v2

    :goto_0
    iget v4, v4, Lcom/vbox/entity/AppConfig;->bpid:I

    invoke-static {v4}, Lcom/vbox/proxy/ProxyManifest;->getProxyAuthorities(I)Ljava/lang/String;

    move-result-object v4

    aput-object v4, p3, v0

    invoke-direct {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$GetContentProvider;->getUserIndex()I

    move-result v0

    invoke-static {}, Lcom/vbox/VBoxCore;->getHostUserId()I

    move-result v4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, p3, v0

    goto :goto_1

    :cond_5
    move-object v5, v2

    :goto_1
    if-nez v5, :cond_6

    return-object v2

    :cond_6
    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1}, Lcom/vbox/utils/Reflector;->with(Ljava/lang/Object;)Lcom/vbox/utils/Reflector;

    move-result-object p2

    .line 11
    const-wide v6, -0x41cf0e8ce7971532L    # -3.944887422416732E-9

    invoke-static {v6, v7, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    .line 12
    invoke-virtual {p2, p3}, Lcom/vbox/utils/Reflector;->field(Ljava/lang/String;)Lcom/vbox/utils/Reflector;

    move-result-object p2

    invoke-virtual {p2, v1}, Lcom/vbox/utils/Reflector;->set(Ljava/lang/Object;)Lcom/vbox/utils/Reflector;

    invoke-static {p1}, Lcom/vbox/utils/Reflector;->with(Ljava/lang/Object;)Lcom/vbox/utils/Reflector;

    move-result-object p2

    .line 13
    const-wide v0, -0x41cf0e91e7971532L    # -3.944869658848338E-9

    invoke-static {v0, v1, v3}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    .line 14
    invoke-virtual {p2, p3}, Lcom/vbox/utils/Reflector;->field(Ljava/lang/String;)Lcom/vbox/utils/Reflector;

    move-result-object p2

    new-instance p3, Lcom/vbox/fake/service/context/providers/ContentProviderStub;

    invoke-direct {p3}, Lcom/vbox/fake/service/context/providers/ContentProviderStub;-><init>()V

    invoke-static {}, Lblack/android/content/BRContentProviderNative;->get()Lblack/android/content/ContentProviderNativeStatic;

    move-result-object v0

    invoke-interface {v0, v5}, Lblack/android/content/ContentProviderNativeStatic;->asInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p3, v0, v1}, Lcom/vbox/fake/service/context/providers/ContentProviderStub;->wrapper(Landroid/os/IInterface;Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object p3

    invoke-virtual {p2, p3}, Lcom/vbox/utils/Reflector;->set(Ljava/lang/Object;)Lcom/vbox/utils/Reflector;

    return-object p1

    :cond_7
    :goto_2
    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-static {p1, v2}, Lcom/vbox/fake/delegate/ContentProviderDelegate;->update(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1

    :cond_8
    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
