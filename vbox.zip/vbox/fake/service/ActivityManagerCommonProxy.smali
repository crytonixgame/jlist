.class public Lcom/vbox/fake/service/ActivityManagerCommonProxy;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$startNextMatchingActivity;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$startActivityWithConfig;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$getPersistedUriPermissions;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$GetCurrentUserId;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$getCallingActivity;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$getCallingPackage;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$GetAppTasks;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$FinishActivity;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$ActivityDestroyed;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$ActivityResumed;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$StartIntentSenderForResult;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$StartActivities;,
        Lcom/vbox/fake/service/ActivityManagerCommonProxy$StartActivity;
    }
.end annotation


# static fields
.field public static final TAG:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    .line 1
    sget-object v0, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0e08e7971532L    # -3.945356380622334E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    sput-object v0, Lcom/vbox/fake/service/ActivityManagerCommonProxy;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
