.class public Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiver;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "registerReceiver"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IActivityManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "RegisterReceiver"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public getPermissionIndex()I
    .registers 2

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isS()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x6

    return v0

    :cond_0
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isR()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x5

    return v0

    :cond_1
    const/4 v0, 0x4

    return v0
.end method

.method public getReceiverIndex()I
    .registers 2

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isS()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x4

    return v0

    :cond_0
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isR()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x3

    return v0

    :cond_1
    const/4 v0, 0x2

    return v0
.end method

.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    invoke-static {p3}, Lcom/vbox/utils/MethodParameterUtils;->replaceFirstAppPkg([Ljava/lang/Object;)Ljava/lang/String;

    invoke-virtual {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiver;->getReceiverIndex()I

    move-result v0

    aget-object v1, p3, v0

    if-eqz v1, :cond_1

    check-cast v1, Landroid/content/IIntentReceiver;

    invoke-static {v1}, Lcom/vbox/fake/delegate/InnerReceiverDelegate;->createProxy(Landroid/content/IIntentReceiver;)Landroid/content/IIntentReceiver;

    move-result-object v2

    invoke-static {v1}, Lblack/android/app/BRLoadedApkReceiverDispatcherInnerReceiver;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkReceiverDispatcherInnerReceiverContext;

    move-result-object v1

    invoke-interface {v1}, Lblack/android/app/LoadedApkReceiverDispatcherInnerReceiverContext;->mDispatcher()Ljava/lang/ref/WeakReference;

    move-result-object v1

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Lblack/android/app/BRLoadedApkReceiverDispatcher;->get(Ljava/lang/Object;)Lblack/android/app/LoadedApkReceiverDispatcherContext;

    move-result-object v1

    invoke-interface {v1, v2}, Lblack/android/app/LoadedApkReceiverDispatcherContext;->_set_mIIntentReceiver(Ljava/lang/Object;)V

    :cond_0
    aput-object v2, p3, v0

    :cond_1
    invoke-virtual {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiver;->getPermissionIndex()I

    move-result v0

    aget-object v0, p3, v0

    if-eqz v0, :cond_2

    invoke-virtual {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiver;->getPermissionIndex()I

    move-result v0

    const/4 v1, 0x0

    aput-object v1, p3, v0

    :cond_2
    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
