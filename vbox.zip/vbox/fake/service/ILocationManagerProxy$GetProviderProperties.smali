.class public Lcom/vbox/fake/service/ILocationManagerProxy$GetProviderProperties;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "getProviderProperties"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/ILocationManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "GetProviderProperties"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {}, Lcom/vbox/fake/frameworks/BLocationManager;->isFakeLocationEnable()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-static {v0}, Lblack/android/location/provider/BRProviderProperties;->get(Ljava/lang/Object;)Lblack/android/location/provider/ProviderPropertiesContext;

    move-result-object v1

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-interface {v1, v2}, Lblack/android/location/provider/ProviderPropertiesContext;->_set_mHasNetworkRequirement(Ljava/lang/Object;)V

    invoke-static {}, Lcom/vbox/fake/frameworks/BLocationManager;->get()Lcom/vbox/fake/frameworks/BLocationManager;

    move-result-object v1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v3

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lcom/vbox/fake/frameworks/BLocationManager;->getCell(ILjava/lang/String;)Lcom/vbox/entity/location/BCell;

    move-result-object v1

    if-nez v1, :cond_0

    invoke-static {v0}, Lblack/android/location/provider/BRProviderProperties;->get(Ljava/lang/Object;)Lblack/android/location/provider/ProviderPropertiesContext;

    move-result-object v0

    invoke-interface {v0, v2}, Lblack/android/location/provider/ProviderPropertiesContext;->_set_mHasCellRequirement(Ljava/lang/Object;)V

    :cond_0
    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
