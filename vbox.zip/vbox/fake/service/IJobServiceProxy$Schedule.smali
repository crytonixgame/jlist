.class public Lcom/vbox/fake/service/IJobServiceProxy$Schedule;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "schedule"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IJobServiceProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Schedule"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    const-string v0, "JobServiceStub"

    const/4 v1, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    if-eqz p3, :cond_3

    :try_start_0
    array-length v3, p3

    if-eqz v3, :cond_3

    aget-object v3, p3, v1

    instance-of v4, v3, Landroid/app/job/JobInfo;

    if-nez v4, :cond_0

    goto :goto_0

    :cond_0
    check-cast v3, Landroid/app/job/JobInfo;

    if-nez v3, :cond_1

    const-string p1, "schedule called with null JobInfo, returning 0"

    invoke-static {v0, p1}, Lcom/vbox/utils/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v2

    :cond_1
    invoke-static {}, Lcom/vbox/VBoxCore;->getBJobManager()Lcom/vbox/fake/frameworks/BJobManager;

    move-result-object v4

    invoke-virtual {v4, v3}, Lcom/vbox/fake/frameworks/BJobManager;->schedule(Landroid/app/job/JobInfo;)Landroid/app/job/JobInfo;

    move-result-object v4

    if-eqz v4, :cond_2

    move-object v3, v4

    :cond_2
    aput-object v3, p3, v1

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :catchall_0
    move-exception p1

    goto :goto_1

    :cond_3
    :goto_0
    const-string p1, "schedule called with invalid JobInfo, returning 0"

    invoke-static {v0, p1}, Lcom/vbox/utils/Slog;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-object v2

    :goto_1
    const-string p2, "schedule failed, returning 0"

    invoke-static {v0, p2, p1}, Lcom/vbox/utils/Slog;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-object v2
.end method
