.class public Lcom/vbox/fake/service/IAccountManagerProxy;
.super Lcom/vbox/fake/hook/BinderInvocationStub;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/service/IAccountManagerProxy$unregisterAccountListener;,
        Lcom/vbox/fake/service/IAccountManagerProxy$registerAccountListener;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountsAndVisibilityForPackage;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountVisibility;,
        Lcom/vbox/fake/service/IAccountManagerProxy$setAccountVisibility;,
        Lcom/vbox/fake/service/IAccountManagerProxy$addAccountExplicitlyWithVisibility;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getPackagesAndVisibilityForAccount;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAuthTokenLabel;,
        Lcom/vbox/fake/service/IAccountManagerProxy$accountAuthenticated;,
        Lcom/vbox/fake/service/IAccountManagerProxy$confirmCredentialsAsUser;,
        Lcom/vbox/fake/service/IAccountManagerProxy$editProperties;,
        Lcom/vbox/fake/service/IAccountManagerProxy$updateCredentials;,
        Lcom/vbox/fake/service/IAccountManagerProxy$addAccountAsUser;,
        Lcom/vbox/fake/service/IAccountManagerProxy$addAccount;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAuthToken;,
        Lcom/vbox/fake/service/IAccountManagerProxy$updateAppPermission;,
        Lcom/vbox/fake/service/IAccountManagerProxy$setUserData;,
        Lcom/vbox/fake/service/IAccountManagerProxy$clearPassword;,
        Lcom/vbox/fake/service/IAccountManagerProxy$setPassword;,
        Lcom/vbox/fake/service/IAccountManagerProxy$setAuthToken;,
        Lcom/vbox/fake/service/IAccountManagerProxy$peekAuthToken;,
        Lcom/vbox/fake/service/IAccountManagerProxy$invalidateAuthToken;,
        Lcom/vbox/fake/service/IAccountManagerProxy$copyAccountToUser;,
        Lcom/vbox/fake/service/IAccountManagerProxy$removeAccountExplicitly;,
        Lcom/vbox/fake/service/IAccountManagerProxy$removeAccountAsUser;,
        Lcom/vbox/fake/service/IAccountManagerProxy$addAccountExplicitly;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountsAsUser;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountsByFeatures;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountByTypeAndFeatures;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountsByTypeForPackage;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAccountsForPackage;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getAuthenticatorTypes;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getUserData;,
        Lcom/vbox/fake/service/IAccountManagerProxy$getPassword;
    }
.end annotation


# static fields
.field public static final TAG:Ljava/lang/String; = "IAccountManagerProxy"


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v0

    const-string v1, "account"

    invoke-interface {v0, v1}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/vbox/fake/hook/BinderInvocationStub;-><init>(Landroid/os/IBinder;)V

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 4

    invoke-static {}, Lblack/android/accounts/BRIAccountManagerStub;->get()Lblack/android/accounts/IAccountManagerStubStatic;

    move-result-object v0

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v1

    const-string v2, "account"

    invoke-interface {v1, v2}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    invoke-interface {v0, v1}, Lblack/android/accounts/IAccountManagerStubStatic;->asInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    const-string p1, "account"

    invoke-virtual {p0, p1}, Lcom/vbox/fake/hook/BinderInvocationStub;->replaceSystemService(Ljava/lang/String;)V

    return-void
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "call "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "IAccountManagerProxy"

    invoke-static {v1, v0}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-super {p0, p1, p2, p3}, Lcom/vbox/fake/hook/ClassInvocationStub;->invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public isBadEnv()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method

.method public onBindMethod()V
    .registers 1

    invoke-super {p0}, Lcom/vbox/fake/hook/BinderInvocationStub;->onBindMethod()V

    return-void
.end method
