.class public Lcom/vbox/fake/service/BuildProxy;
.super Lcom/vbox/fake/hook/ClassInvocationStub;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/ClassInvocationStub;-><init>()V

    return-void
.end method

.method private logSpoofedProperties()V
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "BOARD: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v1, "ro.board"

    invoke-static {v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "BuildProxy"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "BRAND: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.brand"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "DEVICE: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.device"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "DISPLAY: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.display"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "HOST: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.host"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "ID: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.id"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "MANUFACTURER: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.manufacturer"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "MODEL: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.model"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "PRODUCT: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.product"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "TAGS: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.tags"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "TYPE: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.type"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "USER: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v2, "ro.user"

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 2

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string p2, "umi"

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_BOARD(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string v0, "Xiaomi"

    invoke-interface {p1, v0}, Lblack/android/os/BuildStatic;->_set_BRAND(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_DEVICE(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string v1, "QKQ1.191117.002 test-keys"

    invoke-interface {p1, v1}, Lblack/android/os/BuildStatic;->_set_DISPLAY(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string v1, "c5-miui-ota-bd074.bj"

    invoke-interface {p1, v1}, Lblack/android/os/BuildStatic;->_set_HOST(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string v1, "QKQ1.191117.002"

    invoke-interface {p1, v1}, Lblack/android/os/BuildStatic;->_set_ID(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    invoke-interface {p1, v0}, Lblack/android/os/BuildStatic;->_set_MANUFACTURER(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string v0, "Mi 10"

    invoke-interface {p1, v0}, Lblack/android/os/BuildStatic;->_set_MODEL(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_PRODUCT(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string p2, "release-keys"

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_TAGS(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string p2, "user"

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_TYPE(Ljava/lang/Object;)V

    invoke-static {}, Lblack/android/os/BRBuild;->get()Lblack/android/os/BuildStatic;

    move-result-object p1

    const-string p2, "builder"

    invoke-interface {p1, p2}, Lblack/android/os/BuildStatic;->_set_USER(Ljava/lang/Object;)V

    invoke-direct {p0}, Lcom/vbox/fake/service/BuildProxy;->logSpoofedProperties()V

    return-void
.end method

.method public isBadEnv()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
