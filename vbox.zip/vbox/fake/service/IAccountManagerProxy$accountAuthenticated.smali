.class public Lcom/vbox/fake/service/IAccountManagerProxy$accountAuthenticated;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "accountAuthenticated"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IAccountManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "accountAuthenticated"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BAccountManager;->get()Lcom/vbox/fake/frameworks/BAccountManager;

    move-result-object p1

    const/4 p2, 0x0

    aget-object p3, p3, p2

    check-cast p3, Landroid/accounts/Account;

    invoke-virtual {p1, p3}, Lcom/vbox/fake/frameworks/BAccountManager;->accountAuthenticated(Landroid/accounts/Account;)Z

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    return-object p1
.end method
