.class public Lcom/vbox/fake/service/IActivityManagerProxy$BindServiceInstance;
.super Lcom/vbox/fake/service/IActivityManagerProxy$BindIsolatedService;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "bindServiceInstance"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IActivityManagerProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "BindServiceInstance"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/service/IActivityManagerProxy$BindIsolatedService;-><init>()V

    return-void
.end method
