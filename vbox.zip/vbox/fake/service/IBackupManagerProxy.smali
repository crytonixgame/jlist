.class public Lcom/vbox/fake/service/IBackupManagerProxy;
.super Lcom/vbox/fake/hook/BinderInvocationStub;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/service/IBackupManagerProxy$dataChanged;,
        Lcom/vbox/fake/service/IBackupManagerProxy$clearBackupData;,
        Lcom/vbox/fake/service/IBackupManagerProxy$agentConnected;,
        Lcom/vbox/fake/service/IBackupManagerProxy$agentDisconnected;,
        Lcom/vbox/fake/service/IBackupManagerProxy$restoreAtInstall;,
        Lcom/vbox/fake/service/IBackupManagerProxy$setBackupEnabled;,
        Lcom/vbox/fake/service/IBackupManagerProxy$setBackupProvisioned;,
        Lcom/vbox/fake/service/IBackupManagerProxy$backupNow;,
        Lcom/vbox/fake/service/IBackupManagerProxy$fullBackup;,
        Lcom/vbox/fake/service/IBackupManagerProxy$fullTransportBackup;,
        Lcom/vbox/fake/service/IBackupManagerProxy$fullRestore;,
        Lcom/vbox/fake/service/IBackupManagerProxy$acknowledgeFullBackupOrRestore;,
        Lcom/vbox/fake/service/IBackupManagerProxy$getCurrentTransport;,
        Lcom/vbox/fake/service/IBackupManagerProxy$listAllTransports;,
        Lcom/vbox/fake/service/IBackupManagerProxy$selectBackupTransport;,
        Lcom/vbox/fake/service/IBackupManagerProxy$isBackupEnabled;,
        Lcom/vbox/fake/service/IBackupManagerProxy$setBackupPassword;,
        Lcom/vbox/fake/service/IBackupManagerProxy$hasBackupPassword;,
        Lcom/vbox/fake/service/IBackupManagerProxy$beginRestoreSession;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v0

    const-string v1, "backup"

    invoke-interface {v0, v1}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v0

    invoke-direct {p0, v0}, Lcom/vbox/fake/hook/BinderInvocationStub;-><init>(Landroid/os/IBinder;)V

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 4

    invoke-static {}, Lblack/android/app/backup/BRIBackupManagerStub;->get()Lblack/android/app/backup/IBackupManagerStubStatic;

    move-result-object v0

    invoke-static {}, Lblack/android/os/BRServiceManager;->get()Lblack/android/os/ServiceManagerStatic;

    move-result-object v1

    const-string v2, "backup"

    invoke-interface {v1, v2}, Lblack/android/os/ServiceManagerStatic;->getService(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    invoke-interface {v0, v1}, Lblack/android/app/backup/IBackupManagerStubStatic;->asInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    const-string p1, "backup"

    invoke-virtual {p0, p1}, Lcom/vbox/fake/hook/BinderInvocationStub;->replaceSystemService(Ljava/lang/String;)V

    return-void
.end method

.method public isBadEnv()Z
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
