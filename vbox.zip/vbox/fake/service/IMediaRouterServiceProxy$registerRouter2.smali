.class public Lcom/vbox/fake/service/IMediaRouterServiceProxy$registerRouter2;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "registerRouter2"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IMediaRouterServiceProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "registerRouter2"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-static {p3}, Lcom/vbox/utils/MethodParameterUtils;->replaceFirstAppPkg([Ljava/lang/Object;)Ljava/lang/String;

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
