.class public Lcom/vbox/fake/service/IActivityManagerProxy;
.super Lcom/vbox/fake/hook/ClassInvocationStub;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ScanClass;
    value = {
        Lcom/vbox/fake/service/ActivityManagerCommonProxy;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/fake/service/IActivityManagerProxy$updateConfiguration;,
        Lcom/vbox/fake/service/IActivityManagerProxy$unregisterUidObserver;,
        Lcom/vbox/fake/service/IActivityManagerProxy$registerUidObserver;,
        Lcom/vbox/fake/service/IActivityManagerProxy$setRequestedOrientation;,
        Lcom/vbox/fake/service/IActivityManagerProxy$SetTaskDescription;,
        Lcom/vbox/fake/service/IActivityManagerProxy$checkUriPermission;,
        Lcom/vbox/fake/service/IActivityManagerProxy$checkPermission;,
        Lcom/vbox/fake/service/IActivityManagerProxy$getCurrentUser;,
        Lcom/vbox/fake/service/IActivityManagerProxy$getHistoricalProcessExitReasons;,
        Lcom/vbox/fake/service/IActivityManagerProxy$setServiceForeground;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GrantUriPermission;,
        Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiver;,
        Lcom/vbox/fake/service/IActivityManagerProxy$RegisterReceiverWithFeature;,
        Lcom/vbox/fake/service/IActivityManagerProxy$SendIntentSender;,
        Lcom/vbox/fake/service/IActivityManagerProxy$PeekService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$PublishService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$finishReceiver;,
        Lcom/vbox/fake/service/IActivityManagerProxy$unregisterReceiver;,
        Lcom/vbox/fake/service/IActivityManagerProxy$BroadcastIntent;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetIntentSenderWithFeature;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetIntentSenderWithSourceToken;,
        Lcom/vbox/fake/service/IActivityManagerProxy$getUidForIntentSender;,
        Lcom/vbox/fake/service/IActivityManagerProxy$getPackageForIntentSender;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetIntentSender;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetServices;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetRunningAppProcesses;,
        Lcom/vbox/fake/service/IActivityManagerProxy$UnbindService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$BindIsolatedService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$BindServiceInstance;,
        Lcom/vbox/fake/service/IActivityManagerProxy$BindService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$StopServiceToken;,
        Lcom/vbox/fake/service/IActivityManagerProxy$StopService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$StartService;,
        Lcom/vbox/fake/service/IActivityManagerProxy$GetContentProvider;
    }
.end annotation


# static fields
.field public static final TAG:Ljava/lang/String;


# direct methods
.method public static constructor <clinit>()V
    .registers 3

    .line 1
    sget-object v0, La/a;->a:[Ljava/lang/String;

    const-wide v1, -0x41cf0edee7971532L    # -3.944596099895071E-9

    invoke-static {v1, v2, v0}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 2
    sput-object v0, Lcom/vbox/fake/service/IActivityManagerProxy;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/ClassInvocationStub;-><init>()V

    return-void
.end method


# virtual methods
.method public getWho()Ljava/lang/Object;
    .registers 2

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lblack/android/app/BRActivityManagerOreo;->get()Lblack/android/app/ActivityManagerOreoStatic;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityManagerOreoStatic;->IActivityManagerSingleton()Ljava/lang/Object;

    move-result-object v0

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isL()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-static {}, Lblack/android/app/BRActivityManagerNative;->get()Lblack/android/app/ActivityManagerNativeStatic;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityManagerNativeStatic;->gDefault()Ljava/lang/Object;

    move-result-object v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, Lblack/android/util/BRSingleton;->get(Ljava/lang/Object;)Lblack/android/util/SingletonContext;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/util/SingletonContext;->get()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public inject(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo()Z

    move-result p1

    if-eqz p1, :cond_0

    invoke-static {}, Lblack/android/app/BRActivityManagerOreo;->get()Lblack/android/app/ActivityManagerOreoStatic;

    move-result-object p1

    invoke-interface {p1}, Lblack/android/app/ActivityManagerOreoStatic;->IActivityManagerSingleton()Ljava/lang/Object;

    move-result-object p1

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isL()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-static {}, Lblack/android/app/BRActivityManagerNative;->get()Lblack/android/app/ActivityManagerNativeStatic;

    move-result-object p1

    invoke-interface {p1}, Lblack/android/app/ActivityManagerNativeStatic;->gDefault()Ljava/lang/Object;

    move-result-object p1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :goto_0
    invoke-static {p1}, Lblack/android/util/BRSingleton;->get(Ljava/lang/Object;)Lblack/android/util/SingletonContext;

    move-result-object p1

    invoke-interface {p1, p2}, Lblack/android/util/SingletonContext;->_set_mInstance(Ljava/lang/Object;)V

    return-void
.end method

.method public isBadEnv()Z
    .registers 3

    invoke-virtual {p0}, Lcom/vbox/fake/hook/ClassInvocationStub;->getProxyInvocation()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0}, Lcom/vbox/fake/service/IActivityManagerProxy;->getWho()Ljava/lang/Object;

    move-result-object v1

    if-eq v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public onBindMethod()V
    .registers 5

    invoke-super {p0}, Lcom/vbox/fake/hook/ClassInvocationStub;->onBindMethod()V

    new-instance v0, Lcom/vbox/fake/service/base/PkgMethodProxy;

    .line 1
    sget-object v1, La/a;->a:[Ljava/lang/String;

    const-wide v2, -0x41cf0ea6e7971532L    # -3.9447950518610835E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2
    invoke-direct {v0, v2}, Lcom/vbox/fake/service/base/PkgMethodProxy;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/vbox/fake/hook/ClassInvocationStub;->addMethodHook(Lcom/vbox/fake/hook/MethodHook;)V

    new-instance v0, Lcom/vbox/fake/service/base/PkgMethodProxy;

    .line 3
    const-wide v2, -0x41cf0eb6e7971532L    # -3.944738208442223E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 4
    invoke-direct {v0, v2}, Lcom/vbox/fake/service/base/PkgMethodProxy;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/vbox/fake/hook/ClassInvocationStub;->addMethodHook(Lcom/vbox/fake/hook/MethodHook;)V

    new-instance v0, Lcom/vbox/fake/service/base/PkgMethodProxy;

    .line 5
    const-wide v2, -0x41cf0ecce7971532L    # -3.944660048741289E-9

    invoke-static {v2, v3, v1}, Lorg/lsposed/lsparanoid/DeobfuscatorHelper;->getString(J[Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 6
    invoke-direct {v0, v1}, Lcom/vbox/fake/service/base/PkgMethodProxy;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lcom/vbox/fake/hook/ClassInvocationStub;->addMethodHook(Lcom/vbox/fake/hook/MethodHook;)V

    return-void
.end method
