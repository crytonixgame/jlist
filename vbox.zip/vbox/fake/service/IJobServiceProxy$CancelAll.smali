.class public Lcom/vbox/fake/service/IJobServiceProxy$CancelAll;
.super Lcom/vbox/fake/hook/MethodHook;
.source "SourceFile"


# annotations
.annotation runtime Lcom/vbox/fake/hook/ProxyMethod;
    value = "cancelAll"
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/vbox/fake/service/IJobServiceProxy;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "CancelAll"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/hook/MethodHook;-><init>()V

    return-void
.end method


# virtual methods
.method public hook(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    invoke-static {}, Lcom/vbox/VBoxCore;->getBJobManager()Lcom/vbox/fake/frameworks/BJobManager;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppConfig()Lcom/vbox/entity/AppConfig;

    move-result-object v1

    iget-object v1, v1, Lcom/vbox/entity/AppConfig;->processName:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/vbox/fake/frameworks/BJobManager;->cancelAll(Ljava/lang/String;)V

    invoke-virtual {p2, p1, p3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
