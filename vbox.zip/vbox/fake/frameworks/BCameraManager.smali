.class public Lcom/vbox/fake/frameworks/BCameraManager;
.super Lcom/vbox/fake/frameworks/BlackManager;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/vbox/fake/frameworks/BlackManager<",
        "Lcom/vbox/core/system/camera/IBCameraManagerService;",
        ">;"
    }
.end annotation


# static fields
.field public static final CLOSE_MODE:I = 0x0

.field public static final GLOBAL_MODE:I = 0x1

.field public static final METHOD_DISABLE_CAMERA:I = 0x0

.field public static final METHOD_LOCAL_VIDEO:I = 0x1

.field public static final METHOD_NETWORK_VIDEO:I = 0x2

.field public static final METHOD_VIRTUAL_CAMERA:I = 0x3

.field public static final OWN_MODE:I = 0x2

.field private static final sCameraManager:Lcom/vbox/fake/frameworks/BCameraManager;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/fake/frameworks/BCameraManager;

    invoke-direct {v0}, Lcom/vbox/fake/frameworks/BCameraManager;-><init>()V

    sput-object v0, Lcom/vbox/fake/frameworks/BCameraManager;->sCameraManager:Lcom/vbox/fake/frameworks/BCameraManager;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/frameworks/BlackManager;-><init>()V

    return-void
.end method

.method public static disableFakeCamera(ILjava/lang/String;)V
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p0, p1, v1}, Lcom/vbox/fake/frameworks/BCameraManager;->setCameraMethod(ILjava/lang/String;I)V

    return-void
.end method

.method public static get()Lcom/vbox/fake/frameworks/BCameraManager;
    .registers 1

    sget-object v0, Lcom/vbox/fake/frameworks/BCameraManager;->sCameraManager:Lcom/vbox/fake/frameworks/BCameraManager;

    return-object v0
.end method

.method public static getCurrentAudioState(ILjava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->isAudioEnabled(ILjava/lang/String;)Z

    move-result p0

    return p0
.end method

.method public static getCurrentVideoPath(ILjava/lang/String;)Ljava/lang/String;
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraVideo(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static isCameraDisabled(ILjava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraMethod(ILjava/lang/String;)I

    move-result p0

    if-nez p0, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static isFakeCameraEnable()Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getUserId()I

    move-result v1

    invoke-static {}, Lcom/vbox/app/BActivityThread;->getAppPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraMethod(ILjava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static isLocalVideoMode(ILjava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraMethod(ILjava/lang/String;)I

    move-result p0

    const/4 p1, 0x1

    if-ne p0, p1, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public static isNetworkVideoMode(ILjava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraMethod(ILjava/lang/String;)I

    move-result p0

    const/4 p1, 0x2

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method

.method public static isVirtualCameraMode(ILjava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BCameraManager;->get()Lcom/vbox/fake/frameworks/BCameraManager;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lcom/vbox/fake/frameworks/BCameraManager;->getCameraMethod(ILjava/lang/String;)I

    move-result p0

    const/4 p1, 0x3

    if-ne p0, p1, :cond_0

    const/4 p0, 0x1

    goto :goto_0

    :cond_0
    const/4 p0, 0x0

    :goto_0
    return p0
.end method


# virtual methods
.method public getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraConfig(ILjava/lang/String;)Lcom/vbox/entity/camera/BCameraConfig;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p1, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {p1}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    return-object p1
.end method

.method public getCameraMethod(ILjava/lang/String;)I
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraMethod(ILjava/lang/String;)I

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1
.end method

.method public getCameraVideo(ILjava/lang/String;)Ljava/lang/String;
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getCameraVideo(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1
.end method

.method public getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;
    .registers 2

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraConfig()Lcom/vbox/entity/camera/BCameraConfig;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v0, Lcom/vbox/entity/camera/BCameraConfig;

    invoke-direct {v0}, Lcom/vbox/entity/camera/BCameraConfig;-><init>()V

    return-object v0
.end method

.method public getGlobalCameraMethod()I
    .registers 2

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraMethod()I

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public getGlobalCameraVideo()Ljava/lang/String;
    .registers 2

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->getGlobalCameraVideo()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v0, 0x0

    return-object v0
.end method

.method public getServiceName()Ljava/lang/String;
    .registers 2

    const-string v0, "camera_manager"

    return-object v0
.end method

.method public isAudioEnabled(ILjava/lang/String;)Z
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/system/camera/IBCameraManagerService;->isAudioEnabled(ILjava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x1

    return p1
.end method

.method public isGlobalAudioEnabled()Z
    .registers 2

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/camera/IBCameraManagerService;->isGlobalAudioEnabled()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v0, 0x1

    return v0
.end method

.method public setAudioEnabled(ILjava/lang/String;Z)V
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2, p3}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setAudioEnabled(ILjava/lang/String;Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2, p3}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraConfig(ILjava/lang/String;Lcom/vbox/entity/camera/BCameraConfig;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setCameraMethod(ILjava/lang/String;I)V
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2, p3}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraMethod(ILjava/lang/String;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V
    .registers 5

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1, p2, p3}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setCameraVideo(ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setGlobalAudioEnabled(Z)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalAudioEnabled(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraConfig(Lcom/vbox/entity/camera/BCameraConfig;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setGlobalCameraMethod(I)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraMethod(I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setGlobalCameraVideo(Ljava/lang/String;)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/camera/IBCameraManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/camera/IBCameraManagerService;->setGlobalCameraVideo(Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method
