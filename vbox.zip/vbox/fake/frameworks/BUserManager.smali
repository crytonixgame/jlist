.class public Lcom/vbox/fake/frameworks/BUserManager;
.super Lcom/vbox/fake/frameworks/BlackManager;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/vbox/fake/frameworks/BlackManager<",
        "Lcom/vbox/core/system/user/IBUserManagerService;",
        ">;"
    }
.end annotation


# static fields
.field private static final sUserManager:Lcom/vbox/fake/frameworks/BUserManager;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/fake/frameworks/BUserManager;

    invoke-direct {v0}, Lcom/vbox/fake/frameworks/BUserManager;-><init>()V

    sput-object v0, Lcom/vbox/fake/frameworks/BUserManager;->sUserManager:Lcom/vbox/fake/frameworks/BUserManager;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/frameworks/BlackManager;-><init>()V

    return-void
.end method

.method public static get()Lcom/vbox/fake/frameworks/BUserManager;
    .registers 1

    sget-object v0, Lcom/vbox/fake/frameworks/BUserManager;->sUserManager:Lcom/vbox/fake/frameworks/BUserManager;

    return-object v0
.end method


# virtual methods
.method public createUser(I)Lcom/vbox/core/system/user/BUserInfo;
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/user/IBUserManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/user/IBUserManagerService;->createUser(I)Lcom/vbox/core/system/user/BUserInfo;

    move-result-object p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return-object p1
.end method

.method public deleteUser(I)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/user/IBUserManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/user/IBUserManagerService;->deleteUser(I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public getServiceName()Ljava/lang/String;
    .registers 2

    const-string v0, "user_manager"

    return-object v0
.end method

.method public getUsers()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/core/system/user/BUserInfo;",
            ">;"
        }
    .end annotation

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/user/IBUserManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/user/IBUserManagerService;->getUsers()Ljava/util/List;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method
