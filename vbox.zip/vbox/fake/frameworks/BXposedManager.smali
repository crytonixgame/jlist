.class public Lcom/vbox/fake/frameworks/BXposedManager;
.super Lcom/vbox/fake/frameworks/BlackManager;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/vbox/fake/frameworks/BlackManager<",
        "Lcom/vbox/core/system/pm/IBXposedManagerService;",
        ">;"
    }
.end annotation


# static fields
.field private static final sXposedManager:Lcom/vbox/fake/frameworks/BXposedManager;


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/fake/frameworks/BXposedManager;

    invoke-direct {v0}, Lcom/vbox/fake/frameworks/BXposedManager;-><init>()V

    sput-object v0, Lcom/vbox/fake/frameworks/BXposedManager;->sXposedManager:Lcom/vbox/fake/frameworks/BXposedManager;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/vbox/fake/frameworks/BlackManager;-><init>()V

    return-void
.end method

.method public static get()Lcom/vbox/fake/frameworks/BXposedManager;
    .registers 1

    sget-object v0, Lcom/vbox/fake/frameworks/BXposedManager;->sXposedManager:Lcom/vbox/fake/frameworks/BXposedManager;

    return-object v0
.end method


# virtual methods
.method public getInstalledModules()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/entity/pm/InstalledModule;",
            ">;"
        }
    .end annotation

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/pm/IBXposedManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/pm/IBXposedManagerService;->getInstalledModules()Ljava/util/List;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return-object v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getServiceName()Ljava/lang/String;
    .registers 2

    const-string v0, "xposed_manager"

    return-object v0
.end method

.method public isModuleEnable(Ljava/lang/String;)Z
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/pm/IBXposedManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/pm/IBXposedManagerService;->isModuleEnable(Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 p1, 0x0

    return p1
.end method

.method public isXPEnable()Z
    .registers 2

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/pm/IBXposedManagerService;

    invoke-interface {v0}, Lcom/vbox/core/system/pm/IBXposedManagerService;->isXPEnable()Z

    move-result v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    return v0

    :catch_0
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v0, 0x0

    return v0
.end method

.method public setModuleEnable(Ljava/lang/String;Z)V
    .registers 4

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/pm/IBXposedManagerService;

    invoke-interface {v0, p1, p2}, Lcom/vbox/core/system/pm/IBXposedManagerService;->setModuleEnable(Ljava/lang/String;Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method

.method public setXPEnable(Z)V
    .registers 3

    :try_start_0
    invoke-virtual {p0}, Lcom/vbox/fake/frameworks/BlackManager;->getService()Landroid/os/IInterface;

    move-result-object v0

    check-cast v0, Lcom/vbox/core/system/pm/IBXposedManagerService;

    invoke-interface {v0, p1}, Lcom/vbox/core/system/pm/IBXposedManagerService;->setXPEnable(Z)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    return-void
.end method
