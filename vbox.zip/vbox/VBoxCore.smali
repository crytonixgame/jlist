.class public Lcom/vbox/VBoxCore;
.super Lcom/vbox/app/configuration/ClientConfiguration;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/vbox/VBoxCore$ProcessType;
    }
.end annotation


# static fields
.field public static final TAG:Ljava/lang/String; = "VBoxCore"

.field private static sContext:Landroid/content/Context;

.field private static sEnableDaemonService:Z

.field private static sHideRoot:Z

.field private static sHideXposed:Z

.field private static sHostPackageName:Ljava/lang/String;

.field private static final sVBoxCore:Lcom/vbox/VBoxCore;


# instance fields
.field private appConfig:Lcom/vbox/entity/AppConfig;

.field private final mAppLifecycleCallbacks:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/vbox/app/configuration/AppLifecycleCallback;",
            ">;"
        }
    .end annotation
.end field

.field private mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

.field private mExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private final mHandler:Landroid/os/Handler;

.field private final mHostUid:I

.field private final mHostUserId:I

.field private mProcessType:Lcom/vbox/VBoxCore$ProcessType;

.field private final mServices:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/os/IBinder;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/vbox/VBoxCore;

    invoke-direct {v0}, Lcom/vbox/VBoxCore;-><init>()V

    sput-object v0, Lcom/vbox/VBoxCore;->sVBoxCore:Lcom/vbox/VBoxCore;

    const/4 v0, 0x1

    sput-boolean v0, Lcom/vbox/VBoxCore;->sHideRoot:Z

    sput-boolean v0, Lcom/vbox/VBoxCore;->sHideXposed:Z

    const/4 v0, 0x0

    sput-boolean v0, Lcom/vbox/VBoxCore;->sEnableDaemonService:Z

    const/4 v0, 0x0

    sput-object v0, Lcom/vbox/VBoxCore;->sHostPackageName:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lcom/vbox/app/configuration/ClientConfiguration;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/vbox/VBoxCore;->mServices:Ljava/util/Map;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/vbox/VBoxCore;->mAppLifecycleCallbacks:Ljava/util/List;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/vbox/VBoxCore;->mHandler:Landroid/os/Handler;

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v0

    iput v0, p0, Lcom/vbox/VBoxCore;->mHostUid:I

    invoke-static {}, Lblack/android/os/BRUserHandle;->get()Lblack/android/os/UserHandleStatic;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/os/UserHandleStatic;->myUserId()Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iput v0, p0, Lcom/vbox/VBoxCore;->mHostUserId:I

    return-void
.end method

.method public static autoConfigure(Landroid/content/Context;)V
    .registers 2

    sget-object v0, Lcom/vbox/VBoxCore;->sHostPackageName:Ljava/lang/String;

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/vbox/VBoxCore;->sHostPackageName:Ljava/lang/String;

    :cond_0
    new-instance p0, Ljava/lang/StringBuilder;

    const-string v0, "Auto-configured with package: "

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v0, Lcom/vbox/VBoxCore;->sHostPackageName:Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "VBoxCore"

    invoke-static {v0, p0}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public static get()Lcom/vbox/VBoxCore;
    .registers 1

    sget-object v0, Lcom/vbox/VBoxCore;->sVBoxCore:Lcom/vbox/VBoxCore;

    return-object v0
.end method

.method public static getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;
    .registers 1

    invoke-static {}, Lcom/vbox/fake/frameworks/BActivityManager;->get()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v0

    return-object v0
.end method

.method public static getBJobManager()Lcom/vbox/fake/frameworks/BJobManager;
    .registers 1

    invoke-static {}, Lcom/vbox/fake/frameworks/BJobManager;->get()Lcom/vbox/fake/frameworks/BJobManager;

    move-result-object v0

    return-object v0
.end method

.method public static getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;
    .registers 1

    invoke-static {}, Lcom/vbox/fake/frameworks/BPackageManager;->get()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    return-object v0
.end method

.method public static getBStorageManager()Lcom/vbox/fake/frameworks/BStorageManager;
    .registers 1

    invoke-static {}, Lcom/vbox/fake/frameworks/BStorageManager;->get()Lcom/vbox/fake/frameworks/BStorageManager;

    move-result-object v0

    return-object v0
.end method

.method public static getContext()Landroid/content/Context;
    .registers 1

    sget-object v0, Lcom/vbox/VBoxCore;->sContext:Landroid/content/Context;

    return-object v0
.end method

.method public static getHostPkg()Ljava/lang/String;
    .registers 1

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getHostPackageName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getHostUid()I
    .registers 1

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    iget v0, v0, Lcom/vbox/VBoxCore;->mHostUid:I

    return v0
.end method

.method public static getHostUserId()I
    .registers 1

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    iget v0, v0, Lcom/vbox/VBoxCore;->mHostUserId:I

    return v0
.end method

.method public static getPackageManager()Landroid/content/pm/PackageManager;
    .registers 1

    sget-object v0, Lcom/vbox/VBoxCore;->sContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    return-object v0
.end method

.method private static getProcessName(Landroid/content/Context;)Ljava/lang/String;
    .registers 4

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const-string v1, "activity"

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/ActivityManager;

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget v2, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->pid:I

    if-ne v2, v0, :cond_0

    iget-object p0, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    goto :goto_0

    :cond_1
    const/4 p0, 0x0

    :goto_0
    if-eqz p0, :cond_2

    return-object p0

    :cond_2
    new-instance p0, Ljava/lang/RuntimeException;

    const-string v0, "processName = null"

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private initNotificationManager()V
    .registers 6

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ".VBOX_CORE"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo_MR1()Z

    move-result v2

    if-eqz v2, :cond_0

    new-instance v2, Landroid/app/NotificationChannel;

    const/4 v3, 0x4

    const-string v4, "VBOX_CORE"

    invoke-direct {v2, v1, v4, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const/4 v1, 0x1

    invoke-virtual {v2, v1}, Landroid/app/NotificationChannel;->enableLights(Z)V

    const/high16 v3, -0x10000

    invoke-virtual {v2, v3}, Landroid/app/NotificationChannel;->setLightColor(I)V

    invoke-virtual {v2, v1}, Landroid/app/NotificationChannel;->setShowBadge(Z)V

    invoke-virtual {v2, v1}, Landroid/app/NotificationChannel;->setLockscreenVisibility(I)V

    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    :cond_0
    return-void
.end method

.method public static is64Bit()Z
    .registers 2

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isM()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Landroid/os/Process;->is64Bit()Z

    move-result v0

    return v0

    :cond_0
    sget-object v0, Landroid/os/Build;->CPU_ABI:Ljava/lang/String;

    const-string v1, "arm64-v8a"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method static synthetic lambda$startLogcat$0()V
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/io/File;

    sget-object v1, Landroid/os/Environment;->DIRECTORY_DOCUMENTS:Ljava/lang/String;

    invoke-static {v1}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "_logcat.txt"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-static {v0}, Lcom/vbox/utils/FileUtils;->deleteDir(Ljava/io/File;)I

    const-string v1, "logcat -c"

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/vbox/utils/ShellUtils;->execCommand(Ljava/lang/String;Z)Lcom/vbox/utils/ShellUtils$CommandResult;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "logcat -f "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v2}, Lcom/vbox/utils/ShellUtils;->execCommand(Ljava/lang/String;Z)Lcom/vbox/utils/ShellUtils$CommandResult;

    return-void
.end method

.method public static mainThread()Ljava/lang/Object;
    .registers 1

    invoke-static {}, Lblack/android/app/BRActivityThread;->get()Lblack/android/app/ActivityThreadStatic;

    move-result-object v0

    invoke-interface {v0}, Lblack/android/app/ActivityThreadStatic;->currentActivityThread()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public static setEnableDaemonService(Z)V
    .registers 1

    sput-boolean p0, Lcom/vbox/VBoxCore;->sEnableDaemonService:Z

    return-void
.end method

.method public static setHideRoot(Z)V
    .registers 1

    .line 1
    sput-boolean p0, Lcom/vbox/VBoxCore;->sHideRoot:Z

    return-void
.end method

.method public static setHideXposed(Z)V
    .registers 1

    sput-boolean p0, Lcom/vbox/VBoxCore;->sHideXposed:Z

    return-void
.end method

.method public static setHostPackageName(Ljava/lang/String;)V
    .registers 1

    sput-object p0, Lcom/vbox/VBoxCore;->sHostPackageName:Ljava/lang/String;

    return-void
.end method

.method private startLogcat()V
    .registers 3

    new-instance v0, Ljava/lang/Thread;

    new-instance v1, Lcom/vbox/VBoxCore$$ExternalSyntheticLambda0;

    invoke-direct {v1}, Lcom/vbox/VBoxCore$$ExternalSyntheticLambda0;-><init>()V

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method


# virtual methods
.method public addAppLifecycleCallback(Lcom/vbox/app/configuration/AppLifecycleCallback;)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mAppLifecycleCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public checkSelfPermission(Ljava/lang/String;)Z
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    invoke-virtual {p0}, Lcom/vbox/VBoxCore;->getHostPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public clearPackage(Ljava/lang/String;I)V
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BPackageManager;->get()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->clearPackage(Ljava/lang/String;I)V

    return-void
.end method

.method public createUser(I)Lcom/vbox/core/system/user/BUserInfo;
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BUserManager;->get()Lcom/vbox/fake/frameworks/BUserManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/fake/frameworks/BUserManager;->createUser(I)Lcom/vbox/core/system/user/BUserInfo;

    move-result-object p1

    return-object p1
.end method

.method public deleteUser(I)V
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BUserManager;->get()Lcom/vbox/fake/frameworks/BUserManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/fake/frameworks/BUserManager;->deleteUser(I)V

    return-void
.end method

.method public doAttachBaseContext(Landroid/content/Context;)V
    .registers 3

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/vbox/VBoxCore;->doAttachBaseContext(Landroid/content/Context;Lcom/vbox/app/configuration/ClientConfiguration;)V

    return-void
.end method

.method public doAttachBaseContext(Landroid/content/Context;Lcom/vbox/app/configuration/ClientConfiguration;)V
    .registers 4

    .line 2
    if-eqz p2, :cond_6

    invoke-static {p1}, Lcom/vbox/VBoxCore;->autoConfigure(Landroid/content/Context;)V

    iput-object p2, p0, Lcom/vbox/VBoxCore;->mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

    invoke-static {p1}, Lme/weishu/reflection/Reflection;->unseal(Landroid/content/Context;)I

    sput-object p1, Lcom/vbox/VBoxCore;->sContext:Landroid/content/Context;

    invoke-direct {p0}, Lcom/vbox/VBoxCore;->initNotificationManager()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Lcom/vbox/VBoxCore;->getProcessName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lcom/vbox/VBoxCore;->getHostPackageName()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    sget-object p1, Lcom/vbox/VBoxCore$ProcessType;->Main:Lcom/vbox/VBoxCore$ProcessType;

    iput-object p1, p0, Lcom/vbox/VBoxCore;->mProcessType:Lcom/vbox/VBoxCore$ProcessType;

    invoke-direct {p0}, Lcom/vbox/VBoxCore;->startLogcat()V

    goto :goto_1

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p2

    sget v0, Lcom/vbox/R$string;->black_box_service_name:I

    invoke-virtual {p2, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_1

    sget-object p1, Lcom/vbox/VBoxCore$ProcessType;->Server:Lcom/vbox/VBoxCore$ProcessType;

    goto :goto_0

    :cond_1
    sget-object p1, Lcom/vbox/VBoxCore$ProcessType;->BAppClient:Lcom/vbox/VBoxCore$ProcessType;

    :goto_0
    iput-object p1, p0, Lcom/vbox/VBoxCore;->mProcessType:Lcom/vbox/VBoxCore$ProcessType;

    :goto_1
    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object p1

    invoke-virtual {p1}, Lcom/vbox/VBoxCore;->isBlackProcess()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-static {}, Lcom/vbox/core/env/BEnvironment;->load()V

    :cond_2
    invoke-virtual {p0}, Lcom/vbox/VBoxCore;->isServerProcess()Z

    move-result p1

    if-eqz p1, :cond_5

    sget-boolean p1, Lcom/vbox/VBoxCore;->sEnableDaemonService:Z

    if-eqz p1, :cond_5

    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p2

    const-class v0, Lcom/vbox/core/system/DaemonService;

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isUpsideDownCake()Z

    move-result p2

    if-nez p2, :cond_4

    invoke-static {}, Lcom/vbox/utils/compat/BuildCompat;->isOreo()Z

    move-result p2

    if-eqz p2, :cond_3

    goto :goto_2

    :cond_3
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_3

    :cond_4
    :goto_2
    invoke-static {}, Lcom/vbox/VBoxCore;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-virtual {p2, p1}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :cond_5
    :goto_3
    invoke-static {}, Lcom/vbox/fake/hook/HookManager;->get()Lcom/vbox/fake/hook/HookManager;

    move-result-object p1

    invoke-virtual {p1}, Lcom/vbox/fake/hook/HookManager;->init()V

    return-void

    :cond_6
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "ClientConfiguration is null!"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public doCreate()V
    .registers 2

    invoke-virtual {p0}, Lcom/vbox/VBoxCore;->isBlackProcess()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {}, Lcom/vbox/fake/delegate/ContentProviderDelegate;->init()V

    :cond_0
    invoke-virtual {p0}, Lcom/vbox/VBoxCore;->isServerProcess()Z

    move-result v0

    if-nez v0, :cond_1

    invoke-static {}, Lcom/vbox/core/system/ServiceManager;->initBlackManager()V

    :cond_1
    return-void
.end method

.method public getAppConfig()Lcom/vbox/entity/AppConfig;
    .registers 2

    iget-object v0, p0, Lcom/vbox/VBoxCore;->appConfig:Lcom/vbox/entity/AppConfig;

    return-object v0
.end method

.method public getAppLifecycleCallbacks()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/app/configuration/AppLifecycleCallback;",
            ">;"
        }
    .end annotation

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mAppLifecycleCallbacks:Ljava/util/List;

    return-object v0
.end method

.method public getApplicationInfo(Ljava/lang/String;)Landroid/content/pm/ApplicationInfo;
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BPackageManager;->get()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1, v1}, Lcom/vbox/fake/frameworks/BPackageManager;->getApplicationInfo(Ljava/lang/String;II)Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    return-object p1
.end method

.method public getExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;
    .registers 2

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-object v0
.end method

.method public getHandler()Landroid/os/Handler;
    .registers 2

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mHandler:Landroid/os/Handler;

    return-object v0
.end method

.method public getHostPackageName()Ljava/lang/String;
    .registers 2

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

    invoke-virtual {v0}, Lcom/vbox/app/configuration/ClientConfiguration;->getHostPackageName()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getInstalledApplications(II)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/List<",
            "Landroid/content/pm/ApplicationInfo;",
            ">;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->getInstalledApplications(II)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public getInstalledPackages(II)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)",
            "Ljava/util/List<",
            "Landroid/content/pm/PackageInfo;",
            ">;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->getInstalledPackages(II)Ljava/util/List;

    move-result-object p1

    return-object p1
.end method

.method public getInstalledXPModules()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/entity/pm/InstalledModule;",
            ">;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/fake/frameworks/BXposedManager;->get()Lcom/vbox/fake/frameworks/BXposedManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/fake/frameworks/BXposedManager;->getInstalledModules()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public getService(Ljava/lang/String;)Landroid/os/IBinder;
    .registers 6

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mServices:Ljava/util/Map;

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/IBinder;

    if-eqz v0, :cond_0

    invoke-interface {v0}, Landroid/os/IBinder;->isBinderAlive()Z

    move-result v1

    if-eqz v1, :cond_0

    return-object v0

    :cond_0
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "_V_|_server_name_"

    invoke-virtual {v0, v1, p1}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/vbox/proxy/ProxyManifest;->getBindProvider()Ljava/lang/String;

    move-result-object v1

    const-string v2, "VM"

    const/4 v3, 0x0

    invoke-static {v1, v2, v3, v0}, Lcom/vbox/utils/provider/ProviderCall;->callSafely(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v0

    if-eqz v0, :cond_1

    const-string v1, "_V_|_server_"

    invoke-static {v0, v1}, Lcom/vbox/utils/compat/BundleCompat;->getBinder(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v3

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "getService: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "VBoxCore"

    invoke-static {v1, v0}, Lcom/vbox/utils/Slog;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v3, :cond_2

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mServices:Ljava/util/Map;

    invoke-interface {v0, p1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-object v3
.end method

.method public getUsers()Ljava/util/List;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/vbox/core/system/user/BUserInfo;",
            ">;"
        }
    .end annotation

    invoke-static {}, Lcom/vbox/fake/frameworks/BUserManager;->get()Lcom/vbox/fake/frameworks/BUserManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/fake/frameworks/BUserManager;->getUsers()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public installGms(I)Lcom/vbox/entity/pm/InstallResult;
    .registers 2

    invoke-static {p1}, Lcom/vbox/core/GmsCore;->installGApps(I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installPackageAsUser(Landroid/net/Uri;I)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 1
    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installByStorage()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vbox/entity/pm/InstallOption;->makeUriFile()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v0, p1, v1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installPackageAsUser(Ljava/io/File;I)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 2
    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installByStorage()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v0, p1, v1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installPackageAsUser(Ljava/lang/String;I)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 3
    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    iget-object p1, p1, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object p1, p1, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installBySystem()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v0, p1, v1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance p2, Lcom/vbox/entity/pm/InstallResult;

    invoke-direct {p2}, Lcom/vbox/entity/pm/InstallResult;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Lcom/vbox/entity/pm/InstallResult;->installError(Ljava/lang/String;)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installXPModule(Landroid/net/Uri;)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 1
    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installByStorage()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vbox/entity/pm/InstallOption;->makeXposed()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vbox/entity/pm/InstallOption;->makeUriFile()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    const/4 v2, -0x4

    invoke-virtual {v0, p1, v1, v2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installXPModule(Ljava/io/File;)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 2
    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installByStorage()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vbox/entity/pm/InstallOption;->makeXposed()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    const/4 v2, -0x4

    invoke-virtual {v0, p1, v1, v2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public installXPModule(Ljava/lang/String;)Lcom/vbox/entity/pm/InstallResult;
    .registers 5

    .line 3
    :try_start_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    iget-object p1, p1, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object p1, p1, Landroid/content/pm/ApplicationInfo;->sourceDir:Ljava/lang/String;

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-static {}, Lcom/vbox/entity/pm/InstallOption;->installBySystem()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    invoke-virtual {v1}, Lcom/vbox/entity/pm/InstallOption;->makeXposed()Lcom/vbox/entity/pm/InstallOption;

    move-result-object v1

    const/4 v2, -0x4

    invoke-virtual {v0, p1, v1, v2}, Lcom/vbox/fake/frameworks/BPackageManager;->installPackageAsUser(Ljava/lang/String;Lcom/vbox/entity/pm/InstallOption;I)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    new-instance v0, Lcom/vbox/entity/pm/InstallResult;

    invoke-direct {v0}, Lcom/vbox/entity/pm/InstallResult;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/vbox/entity/pm/InstallResult;->installError(Ljava/lang/String;)Lcom/vbox/entity/pm/InstallResult;

    move-result-object p1

    return-object p1
.end method

.method public isAppRunning(Ljava/lang/String;I)Z
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->isAppRunning(Ljava/lang/String;I)Z

    move-result p1

    return p1
.end method

.method public isBlackProcess()Z
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mProcessType:Lcom/vbox/VBoxCore$ProcessType;

    sget-object v1, Lcom/vbox/VBoxCore$ProcessType;->BAppClient:Lcom/vbox/VBoxCore$ProcessType;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isInstallGms(I)Z
    .registers 2

    invoke-static {p1}, Lcom/vbox/core/GmsCore;->isInstalledGoogleService(I)Z

    move-result p1

    return p1
.end method

.method public isInstalled(Ljava/lang/String;I)Z
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->isInstalled(Ljava/lang/String;I)Z

    move-result p1

    return p1
.end method

.method public isInstalledXposedModule(Ljava/lang/String;)Z
    .registers 3

    const/4 v0, -0x4

    invoke-virtual {p0, p1, v0}, Lcom/vbox/VBoxCore;->isInstalled(Ljava/lang/String;I)Z

    move-result p1

    return p1
.end method

.method public isMainProcess()Z
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mProcessType:Lcom/vbox/VBoxCore$ProcessType;

    sget-object v1, Lcom/vbox/VBoxCore$ProcessType;->Main:Lcom/vbox/VBoxCore$ProcessType;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isModuleEnable(Ljava/lang/String;)Z
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BXposedManager;->get()Lcom/vbox/fake/frameworks/BXposedManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/fake/frameworks/BXposedManager;->isModuleEnable(Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public isServerProcess()Z
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mProcessType:Lcom/vbox/VBoxCore$ProcessType;

    sget-object v1, Lcom/vbox/VBoxCore$ProcessType;->Server:Lcom/vbox/VBoxCore$ProcessType;

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public isSupportGms()Z
    .registers 2

    invoke-static {}, Lcom/vbox/core/GmsCore;->isSupportGms()Z

    move-result v0

    return v0
.end method

.method public isXPEnable()Z
    .registers 2

    invoke-static {}, Lcom/vbox/fake/frameworks/BXposedManager;->get()Lcom/vbox/fake/frameworks/BXposedManager;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/fake/frameworks/BXposedManager;->isXPEnable()Z

    move-result v0

    return v0
.end method

.method public isXposedModule(Ljava/io/File;)Z
    .registers 2

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/vbox/utils/compat/XposedParserCompat;->isXPModule(Ljava/lang/String;)Z

    move-result p1

    return p1
.end method

.method public launchApk(Ljava/lang/String;I)Z
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->getLaunchIntentForPackage(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    if-nez p1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0, p1, p2}, Lcom/vbox/VBoxCore;->startActivity(Landroid/content/Intent;I)V

    const/4 p1, 0x1

    return p1
.end method

.method public onBeforeMainLaunchApk(Ljava/lang/String;I)V
    .registers 5

    invoke-static {}, Lcom/vbox/VBoxCore;->get()Lcom/vbox/VBoxCore;

    move-result-object v0

    invoke-virtual {v0}, Lcom/vbox/VBoxCore;->getAppLifecycleCallbacks()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/vbox/app/configuration/AppLifecycleCallback;

    invoke-virtual {v1, p1, p2}, Lcom/vbox/app/configuration/AppLifecycleCallback;->beforeMainLaunchApk(Ljava/lang/String;I)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public removeAppLifecycleCallback(Lcom/vbox/app/configuration/AppLifecycleCallback;)V
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mAppLifecycleCallbacks:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    return-void
.end method

.method public requestInstallPackage(Ljava/io/File;)Z
    .registers 3

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

    invoke-virtual {v0, p1}, Lcom/vbox/app/configuration/ClientConfiguration;->requestInstallPackage(Ljava/io/File;)Z

    move-result p1

    return p1
.end method

.method public setExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .registers 2

    iput-object p1, p0, Lcom/vbox/VBoxCore;->mExceptionHandler:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-void
.end method

.method public setHideRoot()Z
    .registers 2

    .line 2
    iget-object v0, p0, Lcom/vbox/VBoxCore;->mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

    invoke-virtual {v0}, Lcom/vbox/app/configuration/ClientConfiguration;->setHideRoot()Z

    move-result v0

    return v0
.end method

.method public setModuleEnable(Ljava/lang/String;Z)V
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BXposedManager;->get()Lcom/vbox/fake/frameworks/BXposedManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BXposedManager;->setModuleEnable(Ljava/lang/String;Z)V

    return-void
.end method

.method public setXPEnable(Z)V
    .registers 3

    invoke-static {}, Lcom/vbox/fake/frameworks/BXposedManager;->get()Lcom/vbox/fake/frameworks/BXposedManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/fake/frameworks/BXposedManager;->setXPEnable(Z)V

    return-void
.end method

.method public startActivity(Landroid/content/Intent;I)V
    .registers 4

    iget-object v0, p0, Lcom/vbox/VBoxCore;->mClientConfiguration:Lcom/vbox/app/configuration/ClientConfiguration;

    invoke-virtual {v0}, Lcom/vbox/app/configuration/ClientConfiguration;->isEnableLauncherActivity()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-static {p1, p2}, Lcom/vbox/app/LauncherActivity;->launch(Landroid/content/Intent;I)V

    goto :goto_0

    :cond_0
    invoke-static {}, Lcom/vbox/VBoxCore;->getBActivityManager()Lcom/vbox/fake/frameworks/BActivityManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BActivityManager;->startActivity(Landroid/content/Intent;I)V

    :goto_0
    return-void
.end method

.method public stopPackage(Ljava/lang/String;I)V
    .registers 4

    invoke-static {}, Lcom/vbox/fake/frameworks/BPackageManager;->get()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->stopPackage(Ljava/lang/String;I)V

    return-void
.end method

.method public uninstallGms(I)Z
    .registers 2

    invoke-static {p1}, Lcom/vbox/core/GmsCore;->uninstallGApps(I)V

    invoke-static {p1}, Lcom/vbox/core/GmsCore;->isInstalledGoogleService(I)Z

    move-result p1

    xor-int/lit8 p1, p1, 0x1

    return p1
.end method

.method public uninstallPackage(Ljava/lang/String;)V
    .registers 3

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/vbox/fake/frameworks/BPackageManager;->uninstallPackage(Ljava/lang/String;)V

    return-void
.end method

.method public uninstallPackageAsUser(Ljava/lang/String;I)V
    .registers 4

    invoke-static {}, Lcom/vbox/VBoxCore;->getBPackageManager()Lcom/vbox/fake/frameworks/BPackageManager;

    move-result-object v0

    invoke-virtual {v0, p1, p2}, Lcom/vbox/fake/frameworks/BPackageManager;->uninstallPackageAsUser(Ljava/lang/String;I)V

    return-void
.end method

.method public uninstallXPModule(Ljava/lang/String;)V
    .registers 2

    invoke-virtual {p0, p1}, Lcom/vbox/VBoxCore;->uninstallPackage(Ljava/lang/String;)V

    return-void
.end method
